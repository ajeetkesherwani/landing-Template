<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Ecom\Category;
use App\Models\Ecom\Fields;
use App\Models\Ecom\Supplier;
use App\Models\Ecom\ProductDescription;
use App\Models\Ecom\Brand;
use App\Models\Ecom\ProductsFeature;
use App\Models\Language;
use App\Models\Images;
use App\Models\SeoMeta;
use App\Models\Ecom\Services\ProductService;
use App\Models\Ecom\Scopes\ProductStatus;
use App\Models\Ecom\FeatureProducts;
use Illuminate\Http\Request;


class Product extends Model
{
    use HasFactory;
    protected $connection= 'mysql';
    protected $table = 'ecm_products';
    protected $primaryKey = 'product_id';
    protected $guarded = ['product_id'];
}