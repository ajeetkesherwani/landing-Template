<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Pcapi\Models\product;

class PcProductToCategory extends Model
{
    use HasFactory;
    
    protected $connection= 'mysqlSuper';
    protected $table = 'ecm_pc_products_to_categories';
    protected $fillable = [
        'products_id',
        'categories_id',
    ];
    public $timestamps = false;

    public function product(){
        return $this->belongsTo(PcProduct::class, 'products_id', 'products_id');
    }

}
