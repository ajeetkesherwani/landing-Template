<?php
return [
    'authenticateToken' => 'https://e-nnovation.net/backend/public/api/authenticatetoken',
    'globalsetting' => 'https://e-nnovation.net/backend/public/api/super/settingIndex',
];
