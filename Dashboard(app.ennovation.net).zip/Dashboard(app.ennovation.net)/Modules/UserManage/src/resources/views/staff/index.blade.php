<x-app-layout>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500"> 
            <li class="breadcrumb-item"><a href="#" class="text-dark tx-16">Dashboard</a></li>
        </ol>
    </nav>
    <div class="card">
        <div class="tab-content">
            <div class="card-header d-flex align-items-center justify-content-between py-2 px-3">
                <h5 class="tx-15 mb-0">{{__('user-manager.employee_list')}}</h5>
                <a href="{{ route('staff.create') }}">
                    <button class="btn btn-md  btn-primary "><i data-feather="plus"></i>{{__('user-manager.add_employee')}}</button></a>
                </a>
            </div>
            <div class="card-body">
                <div class="row align-item-center mb-3">
                    <div class="col-lg-2 col-md-3 col-4">
                        <select class="form-control form-select" aria-label="Default select example">
                            <option>10</option>
                        </select>
                    </div>
                    <div class="col-lg-6 col-md-3 col-8">
                        <input type="text" id="Search" class="form-control col-lg-4 fas fa-search" placeholder="Search..." aria-label="Search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table border table_wrapper rounded">
                        <thead>
                            <tr>
                                <th>{{__('common.sl_no')}}</th>
                                <th>Employee id</th>
                                <th>Staff Photo</th>
                                <th>Staff Name</th>
                                <th>Staff Email</th>
                                <th >Department</th>
                                <th>Designation</th>
                                <th>Verification Status</th>
                                <th>{{__('common.status')}}</th>
                                <th>{{__('common.action')}}</th>
                            </tr>
                        </thead>
                        <tbody id="Search_Tr">
                            @if (!empty($data))
                                @forelse($data as $key => $staff)
                                    <tr>  
                                        <td class="px-3">{{ $key + 1 }}</td>
                                        <td>{{$staff->employee_id}}</td>
                                        <td>
                                            <img src="{{$staff->staff_photo}}" alt="" class="img-fluid" style="height:50px;width:50px;">
                                        </td>
                                        <td class="px-3">{{ $staff->staff_name }}</td>
                                        <td>{{ $staff->staff_email }}</td>
                                        <td class="px-3">
                                            @if (!empty($staff->department))
                                            {{ $staff->department->dept_name }}
                                            @endif
                                        </td>
                                        <td class="px-3">
                                            @if (!empty($staff->designation))
                                            {{ $staff->designation->designation_name }}
                                            @endif
                                        </td>
                                        <td>
                                            <select name="" id="" class="form-select form-control">
                                                <option value="1" {{($staff->verification_status =='0' ? 'selected' : '')}}>Pending</option>
                                                <option value="2" {{($staff->verification_status =='1' ? 'selected' : '')}}>Verified</option>
                                            </select>
                                        </td>
                                        <td>
                                            <div class="custom-control custom-switch">
                                                <input type="checkbox" data-id="{{ $staff->staff_id }}" {{ ($staff->status == '1') ? 'checked' : '' }} class="custom-control-input toggle_status" data-on="Active" data-off="InActive" id="customSwitch">
                                                <label class="custom-control-label" for="customSwitch"></label>
                                            </div>
                                        </td>
                                        <td class="d-flex align-items-center gap-2 justify-content-center">
                                            <a href="{{ route('staff.show', $staff->staff_id) }}" id="staff_view" class="btn btn-sm btn-white table_btn py-1 px-2"><i data-feather="eye"></i></a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5">
                                            <h5 class="text-center mb-0 py-1">No Record Found !.</h5>
                                        </td>
                                    </tr>
                                @endforelse
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>         
        </div><!--end row-->
    </div>
    <!---- Delete employee modal start here---> 
    <div class="modal fade effect-scale" id="delete_modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title">{{__('user-manager.delete_user')}}</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="delete_department_id" name="input_field_id">
                    <p class="mg-b-0">{{ __('common.delete_confirmation') }}</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    {{ __('common.no')}}
                    </button>
                    <button type="button" class="btn btn-primary delete_submit_btn">{{ __('common.yes') }}</button>
                </div>
            </div>
        </div>
    </div>
    <!---- Delete employee modal end here--->
        
    @push('scripts')
        <!-- search ajax-->
        <script>
            // employee status change ajax
            $('.toggle_status').change(function(e) {
                e.preventDefault();
                let status = $(this).prop('checked') === true ? 1 : 0;
                let staff_id = $(this).data('id');
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "{{ url('staffStatus') }}",
                    data: {
                        'status': status,
                        'staff_id': staff_id
                    },
                    success: function(data) {
                        Toaster(' Employee Status Change Successfully');
                    }
                });
            });

            // delete id set in delete modal 
            $(document).on("click", "#delete_btn", function() {
                var staff_id = $(this).val();
                $('#delete_department_id').val(staff_id);
            });

            //employee delete ajax
            $(document).on('click', '.delete_submit_btn', function() {
                var staff_id = $('#delete_department_id').val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('staff')}}/" + staff_id,
                    data: {
                        staff_id: staff_id,
                        _method: 'DELETE'
                    },
                    dataType: "json",
                    success: function(response) {
                        Toaster(response.success);
                        setTimeout(function() {
                            location.reload(true);
                        }, 3000);
                        $('#delete_modal').modal('hide');
                    }
                });
            }); 
        </script>
    @endpush
</x-app-layout>