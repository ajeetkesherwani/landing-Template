<style>
    .btn-size {
        margin-right: 5px !important;
        font-size: 12px !important;
    }
</style>
<x-app-layout>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500">
            <li class="breadcrumb-item"><a href="#" class="text-dark tx-15">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><a href="#" class="text-dark tx-15">Staff</a></li>
            <!-- <li class="breadcrumb-item active" aria-current="page">Create</li> -->
        </ol>
    </nav>
    <form action="{{route('staff.store')}}" id="staffFrom" class="needs-validation" method="POST" novalidate>
        <!-- <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item active">
            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#personal" role="tab" aria-controls="home" aria-selected="true">Personal Information</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#Qualification" role="tab" aria-controls="profile" aria-selected="false">Qualification Information</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#workExperiance" role="tab" aria-controls="contact" aria-selected="false">Work Experiance Information</a>
            </li>
        </ul> -->
        <div class="tab-content mt-4" id="myTabContent">
            <!------ Personal Information Tab Start Here--------->
            <!-- <div class="tab-pane fade show active" id="personal" role="tabpanel" aria-labelledby="home-tab"> --> 
            <!---- Primary Information data form start here ------------>
                <div class="card">
                    <div class="tab-content">
                        <div class="card-header d-flex align-items-center justify-content-between py-3 px-3">
                            <h5 class="tx-15 mb-0">Primary Information</h5>
                        </div>
                        <div class="card-body pb-0">
                            <div class="form-row">
                                <div class="form-group col-md-4 col-4">
                                    <label for="user_type">User Type</label>
                                    <select class="form-select form-control" id="user_type" name="user_type" required>
                                        <option selected disable value="" disabled>Select User Type</option> 
                                        <option value="new">{{Trans('NEW')}}</option>
                                        <option value="existing">
                                        {{Trans('EXISTING')}}
                                        </option>
                                    </select>
                                    <div class="invalid-feedback">
                                            Select User Type
                                    </div>
                                </div>

                                <!---- If User type is new then this input is showing othewise hide ------>
                                <div class="form-group col-md-4 col-4 d-none" id="users">
                                    <label for="user_type">User</label>
                                    <select class="form-select form-control" id="User" name="user_id" required>
                                        <option selected disable value="" disabled>Select User</option>  
                                        @if(!empty($user_list))
                                            @foreach($user_list as $userdata)
                                                <option value="{{$userdata->id}}">{{$userdata->first_name}}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                    <div class="invalid-feedback">
                                        Select User 
                                    </div>
                                </div>
                                <!-------- hidden input field --------------->

                                <div class="form-group col-md-4 col-4" id="StaffRole">
                                    <label for="role_name">Role</label>
                                    <select class="form-select form-control" id="role_name" name="role_name" required>
                                        <option selected disable value="" disabled>Select Role</option> 
                                            @if(!empty($role_list))
                                                @foreach ($role_list as $list)
                                                    <option value="{{ $list->roles_id }}"> {{ $list->roles_name }}</option>
                                                @endforeach
                                            @endif
                                    </select>
                                    <div class="invalid-feedback">
                                        Select Role 
                                    </div>
                                </div>
                                <div class="form-group col-md-4 col-4">
                                    <label for="department_id">Department</label>
                                    <select class="form-select form-control" id="department_id" name="department_id" required>
                                        <option selected disable value="" disabled>Select Department</option> 
                                        @if(!empty($department_list))
                                        @foreach ($department_list as $dl_data)
                                            <option value="{{ $dl_data->department_id }}"> {{ $dl_data->dept_name }}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                    <div class="invalid-feedback">
                                        Select department 
                                    </div>
                                </div>
                            </div>
                            <div class="form-row" id="StaffDetail">
                                <div class="form-group col-md-4 col-4">
                                    <label for="name">Staff Name</label>
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Staff Name" value="{{old('name')}}" required>
                                    <div class="invalid-feedback">
                                        Enter Staff Name
                                    </div>
                                </div>
                                <div class="form-group col-md-4 col-4">
                                    <label for="email">Staff Email</label>
                                    <input type="text" class="form-control" id="email" name="email" placeholder="Staff Email" value="{{old('email')}}" required>
                                    <div class="invalid-feedback">
                                        Enter Staff Email
                                    </div>
                                </div>
                                <div class="form-group col-md-4 col-4"">
                                    <label for="password">Password</label>
                                    <input type="text" class="form-control" id="password" name="password" placeholder="password" value="{{old('password')}}" required>
                                    <div class="invalid-feedback">
                                        {{ __('crm.industry_error') }}
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">  
                                <div class="form-group col-md-4 col-4">
                                    <label for="industry">Designation</label>
                                    <select class="form-select form-control" id="designation_id" name="designation_id" required>
                                        <option selected disable value="" disabled>Select Designation</option> 
                                        @if(!empty($designation_list))
                                        @foreach ($designation_list as $dg_data)
                                            <option value="{{ $dg_data->designation_id }}"> {{ $dg_data->designation_name }}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                    <div class="invalid-feedback">
                                        Select Designation
                                    </div>
                                </div> 
                                <div class="form-group col-md-4 col-4">
                                    <label for="date_of_joining">Date Of Joining</label>
                                    <input type="date" class="form-control" id="date_of_joining" name="staff_date_of_joining" placeholder="{{ __('crm.contact_placeholder') }}" value="{{old('date_of_joining')}}">
                                    <div class="invalid-feedback">
                                        {{ __('crm.source_error') }}
                                    </div>
                                </div>
                                <div class="form-group col-md-4 col-4">
                                    <label for="salary">Salary</label>
                                    <input type="number" class="form-control" id="salary" name="salary" placeholder="Salary" value="{{old('salary')}}">
                                    <div class="invalid-feedback">
                                        Enter salary
                                    </div>
                                </div>
                            </div>
                            
                            <!-- <div class="row mt-4 mb-3 d-flex">
                                <div class="col-lg-1">
                                    <button type="button" id="pslDataSubBtn" class="btn btn-primary btn-sm">submit</button>
                                </div>
                                <div class="col-lg-1">
                                    <button type="button" class="btn btn-primary btn-sm btnNext">Next</button>
                                </div>
                            </div> -->
                        </div>         
                    </div><!--end row-->
                </div> 
            <!---- Primary Information data form end here ------------>
            <!---- Personal Information data form start here ------------>
                <div class="card mt-3">
                    <div class="tab-content">
                        <div class="card-header d-flex align-items-center justify-content-between py-3 px-3">
                            <h5 class="tx-15 mb-0">Personal Information</h5>
                        </div>
                        <div class="card-body pb-0">
                            <div class="form-row">
                                <div class="form-group col-md-4 col-4">
                                    <label for="phone_no">Contact Number</label>
                                    <input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Contact Number" value="{{old('phone_no')}}">
                                    <div class="invalid-feedback">
                                        Enter Contact Name
                                    </div>
                                </div>
                                <div class="form-group col-md-4 col-4">
                                    <label for="gender">Gender</label>
                                    <select class="form-select form-control" id="gender" name="gender">
                                        <option selected disable value="" disabled>Select Gender</option>
                                        <option value="1">Male</option>
                                        <option value="2">Female</option>
                                        <option value="3">Transgender</option>
                                    </select>
                                    <div class="invalid-feedback">
                                        Select Gender
                                    </div>
                                </div> 
                                <div class="form-group col-md-4 col-4">
                                    <label for="date_of_birth">Date Of Birth</label>
                                    <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" placeholder=">Date Of Birth" value="{{old('date_of_birth')}}">
                                    <div class="invalid-feedback">
                                        Enter Date of Birth
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-4 col-4">
                                    <label for="street_address">Street Address</label>
                                    <input type="text" class="form-control" id="street_address" name="street_address" placeholder="Street Address" value="{{old('street_address')}}">
                                    <div class="invalid-feedback">
                                        Enter Street Address
                                    </div>
                                </div>
                                <div class="form-group col-md-4 col-4">
                                    <label for="city">City</label>
                                    <input type="text" class="form-control" id="city" name="city" placeholder="City" value="{{old('city')}}">
                                    <div class="invalid-feedback">
                                        Enter City
                                    </div>
                                </div>
                                <div class="form-group col-md-4 col-4">
                                    <label for="state">State</label>
                                    <input type="text" class="form-control" id="state" name="state" placeholder="State" value="{{old('state')}}">
                                    <div class="invalid-feedback">
                                            Enter State
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-4 col-4">
                                    <label for="countries_id">Country</label>
                                    <select class="form-select form-control" id="countries_id" name="countries_id">
                                        <option selected disable value="" disabled>Select Country</option>  
                                        @if(!empty($country_list))
                                            @foreach ($country_list as $country)
                                                <option value="{{ $country->countries_id }}"> {{ $country->countries_name }}</option>
                                            @endforeach
                                        @endif
                                    </select>
                                    <div class="invalid-feedback">
                                        Select Country
                                    </div>
                                </div>
                                <div class="form-group col-md-4 col-4">
                                    <label for="postcode">Postcode</label>
                                    <input type="text" class="form-control" id="postcode" name="postcode" placeholder="postcode" value="{{old('contact_name')}}">
                                    <div class="invalid-feedback">
                                        Enter Postcode
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-lg-12 d-flex">
                                    <input type="checkbox" class="form-check" id="diffrentAddress"><span class="ml-2">Different Permanent Address</span>
                                </div>
                            </div>
                            <div class="permanent-address mt-4" style="display: none;">
                                <div class="form-row" >
                                    <div class="form-group col-md-4 col-4">
                                        <label for="permanent_phone_no">Contact Number</label>
                                        <input type="text" class="form-control" placeholder="Contact Number" id="permanent_phone_no" name="permanent_phone_no" value="{{old('permanent_phone_no')}}">
                                        <div class="invalid-feedback">
                                                Enter Contact Numeber
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4 col-4">
                                        <label for="permanent_street_address">Street Adddress</label>
                                        <input type="text" class="form-control" id="permanent_street_address" name="permanent_street_address" placeholder="Street Address" value="{{old('permanent_street_address')}}">
                                        <div class="invalid-feedback">
                                                Enter Street Address
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4 col-4">
                                        <label for="permanent_postcode">Postcode</label>
                                        <input type="text" class="form-control" id="permanent_postcode" name="permanent_postcode" placeholder="Postcode" value="{{old('permanent_postcode')}}">
                                        <div class="invalid-feedback">
                                            Enter Postcode
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row" >
                                    <div class="form-group col-md-4 col-4">
                                        <label for="permanent_city">City</label>
                                        <input type="text" class="form-control" id="permanent_city" name="permanent_city" placeholder="City" value="{{old('permanent_city')}}">
                                        <div class="invalid-feedback">
                                            Enter City
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4 col-4">
                                        <label for="permanent_state">State</label>
                                        <input type="text" class="form-control" id="permanent_state" name="permanent_state" placeholder="State" value="{{old('permanent_state')}}">
                                        <div class="invalid-feedback">
                                            Enter State
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4 col-4">
                                        <label for="permanent_countries_id">Country</label>
                                        <select class="form-select form-control" id="permanent_countries_id" name="permanent_countries_id">
                                            <option selected disable value="" disabled>Select Country</option> 
                                            @if(!empty($country_list))
                                                @foreach ($country_list as $country)
                                                    <option value="{{ $country->countries_id }}"> {{ $country->countries_name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                        <div class="invalid-feedback">
                                            Select Country
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>         
                    </div><!--end row-->
                </div>
            <!---- Personal Information data form end here ------------>
            <!-- </div>  -->
            <!------ Personal Information Tab End Here--------->
             
            <!------ Qualification Information Tab Start Here--------->
            <!-- <div class="tab-pane fade" id="Qualification" role="tabpanel" aria-labelledby="profile-tab"> -->
                <div class="card mt-3">
                    <div class="tab-content">
                        <div class="card-header">
                            <div class="d-flex align-items-center justify-content-between">
                                <h5 class="tx-15 mb-0">Education Information</h5>
                                <div class="d-flex gap-2">
                                    <button type="button" id="append" class="btn btn-sm btn-primary"><i data-feather="plus"></i></button> 
                                </div>
                            </div>
                        </div>
                        <div class="card-body " id="qualification_append">
                            <div class="card card-header div_remove">
                                <div class="form-row justify-content-end">
                                    <div class="form-group rem mb-0">
                                        <a href="#" class="btn btn-sm btn-danger py-1 px-3">x</a>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-4">
                                        <lable for="education.0.education_id">Education</lable>
                                        <select class="form-select form-control" id="education_id[]" name="education_id[]">
                                            <option selected disabled value="">Select Education</option>
                                            @if(!empty($education_list))
                                                @foreach($education_list as $eduList)
                                                    <option value="{{$eduList->education_id}}">{{$eduList->education_name}}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <lable for="education.0.university_name">University Name</lable>
                                        <input type="text" name="university_name[]" id="university_name[]" class="form-control" placeholder="University Name">
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <lable for="education.0.admission_at">Admission Year</lable>
                                        <select class="form-select form-control" id="admission_at[]" name="admission_at[]">
                                            <option selected disabled value="">Select Admission Year</option>
                                            @for($i='1973'; $i<='2027'; $i++)
                                            <option value="{{$i}}">{{$i}}</option>
                                            @endfor
                                        </select>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-lg-4">
                                        <lable for="education.0.passing_at">Passing Year</lable>
                                        <select class="form-select form-control" id="passing_at[]" name="passing_at[]">
                                            <option selected disabled value="">Select Passing Year</option>
                                            @for($i='1973'; $i<='2027'; $i++)
                                                <option value="{{$i}}">{{$i}}</option>
                                            @endfor
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <lable for="education.0.document_type">Document Type</lable>
                                        <select class="form-select form-control" id="document_type[]" name="education_document_type[]">
                                            <option selected disabled value="">Select Document Type</option>
                                            @if(!empty($document_list))
                                                @foreach($document_list as $docData)
                                                    <option value="{{$docData->document_id}}">{{$docData->document_name}}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <div class="form-group col-lg-4">
                                        <input type="hidden" name="education_document[]">
                                        <lable for="customFile">Document Upload</lable>
                                        <input type="file" class="form-control p-1" id="customFile">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>   
                </div>
                <!-- <div class="row mt-3">
                    <div class="col-md-12">
                        <button type="button" class="btn btn-dark btn-sm btnPrevious">Prev</button>
                        <button type="button" class="btn btn-primary btn-sm btnNext">Next</button>
                    </div>
                </div> -->
            <!-- </div> -->
            <!------ Qualification Information Tab End Here--------->

            <!------ Work Experiance Tab Start Here--------->
            <!-- <div class="tab-pane fade" id="workExperiance" role="tabpanel" aria-labelledby="contact-tab"> -->
                <!-- <form id="workExpForm" class="needs-validation" novalidate> -->
                    <div class="card mt-3">
                        <div class="tab-content">
                            <div class="card-header">
                                <div class="d-flex align-items-center justify-content-between">
                                    <h5 class="tx-15 mb-0">Work Information</h5>
                                    <div class="d-flex">
                                        <button type="button" id="work_append" class="btn btn-sm btn-primary mg-r-5"><i data-feather="plus">+</i></button> 
                                    </div>
                                </div>
                            </div>
                            <div class="card-body " id="work_experiance_append">
                                <div class="card card-header" >
                                    <div class="form-row justify-content-end">
                                        <div class="form-group rem mb-0">
                                            <a href="#" class="btn btn-sm btn-danger py-1 px-3">x</a>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-lg-4">
                                            <lable for="workexp.0.company_name">Company Name</lable>
                                            <input name="company_name[]" class="form-control" id="company_name[]" placeholder="Company Name">
                                        </div>
                                        <div class="form-group col-lg-4">
                                            <lable for="workexp.0.company_designation">Company Designation</lable>
                                            <input name="company_designation[]" id="company_designation[]" class="form-control" placeholder="Company Designation">
                                        </div>
                                        <div class="form-group col-lg-4">
                                            <lable for="workexp.0.company_address">Company Address</lable>
                                            <input name="company_address[]" id="company_address" class="form-control" placeholder="Company Address">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-lg-4">
                                            <lable for="workexp.0.contact_name">Contact Name</lable>
                                            <input name="contact_name[]" id="contact_name[]" class="form-control" placeholder="Contact Name">
                                        </div>
                                        <div class="form-group col-lg-4">
                                            <lable for="workexp.0.contact_email">Contact Email</lable>
                                            <input name="contact_email[]" id="contact_email" class="form-control" placeholder="Contact Email">
                                        </div>
                                        <div class="form-group col-lg-4">
                                            <lable for="workexp.0.contact_phone">Contact Phone</lable>
                                            <input name="contact_phone[]" id="contact_phone" class="form-control" placeholder="Contact Phone">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-lg-4">
                                            <lable for="workexp.0.date_of_joining">Date Of Joining</lable>
                                            <input type="date" name="date_of_joining[]" id="date_of_joining" class="form-control" placeholder="Date Of Joining"> 
                                        </div>
                                        <div class="form-group col-lg-4">
                                            <lable for="workexp.0.date_of_leaving">Date Of Leaving</lable>
                                            <input type="date" name="date_of_leaving[]" id="date_of_leaving[]" class="form-control" placeholder="Date Of Leaving">
                                        </div>
                                        <div class="form-group col-lg-4">
                                            <lable for="reason_for_leaving">Reason For Leaving</lable>
                                            <input name="reason_for_leaving[]" class="form-control" id="reason_for_leaving[]" placeholder="Reason For Leaving">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-lg-6">
                                            <lable for="document_type">Document Type</lable>
                                            <select class="form-select form-control" id="document_type[]" name="work_document_type[]">
                                                <option selected disabled value="">Select Document Type</option>
                                                <option value="1">10th</option>
                                                <option value="2">12th</option>
                                                <option value="3">Graduation</option>
                                                <option value="4">Post Graduation</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-lg-6">
                                            <input type="hidden" id="work_document[]" name="work_document[]">
                                            <lable for="fileupload">Document Upload</lable>
                                            <input type="file" class="form-control p-1" id="customFile">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mx-1 my-3">
                                <div class="col-md-12">
                                    <button type="submit" id="subBtn" class="btn btn-primary btn-sm btnPrevious">Submit</button>
                                    <button type="submit"  class="btn btn-light btn-sm">Cancel</button>
                                </div>
                            </div>
                        </div>  
                    </div>
                <!-- </form> -->
            <!-- </div> -->
            <!------ Work Experiance Tab End Here--------->
        </div>
    </form>
@push('scripts')
<script>
    $(document).ready(function() {
        //append qualification information
        var i = 1;
        $("#append").on("click",function(){
            $("#qualification_append").append(`<div class="card card-header mt-2 div_remove" >
                <div class="form-row justify-content-end">
                    <div class="form-group rem mb-0">
                        <a href="#" class="btn btn-sm btn-danger py-1 px-3">x</a>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-4">
                        <lable for="education.0.education_id">Education</lable>
                        <select class="form-select form-control" id="education_id[]" name="education_id[]">
                            <option selected disabled value="">Select Education</option>
                            <option value="1">10th</option>
                            <option value="2">12th</option>
                            <option value="3">Graduation</option>
                            <option value="4">Post Graduation</option>
                        </select>
                    </div>
                    <div class="form-group col-lg-4">
                        <lable for="education.0.university_name">University Name</lable>
                        <input type="text" name="university_name[]" id="university_name[]" class="form-control" placeholder="University Name">
                    </div>
                    <div class="form-group col-lg-4">
                        <lable for="education.0.admission_at">Admission Year</lable>
                        <select class="form-select form-control" id="admission_at[]" name="admission_at[]">
                            <option selected disabled value="">Select Admission Year</option>
                            @for($i='1973'; $i<='2027'; $i++)
                            <option value="{{$i}}">{{$i}}</option>
                            @endfor
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-4">
                        <lable for="education.0.passing_at">Passing Year</lable>
                        <select class="form-select form-control" id="passing_at[]" name="passing_at[]">
                            <option selected disabled value="">Select Passing Year</option>
                            @for($i='1973'; $i<='2027'; $i++)
                            <option value="{{$i}}">{{$i}}</option>
                            @endfor
                        </select>
                    </div>
                    <div class="form-group col-lg-4">
                        <lable for="education.0.document_type">Document Type</lable>
                        <select class="form-select form-control" id="document_type[]" name="education_document_type[]">
                            <option selected disabled value="">Select Document Type</option>
                            <option value="1">10th</option>
                            <option value="2">12th</option>
                            <option value="3">Graduation</option>
                            <option value="4">Post Graduation</option>
                        </select>
                    </div>
                    <div class="form-group col-lg-4">
                        <input type="hidden" name="education_document[]">
                        <lable for="customFile">Document Upload</lable>
                        <input type="file" class="form-control p-1" id="customFile">
                    </div>
                </div>
            </div>`);
            i++;
        });

        //remove qualification information & work experiance 
        $(document).on("click",".rem", function(){
           $(this).parent('div').parent('div').remove();
        });

		// append work experiance information 
        var i = 1;
		$("#work_append").on("click",function(){
            $("#work_experiance_append").append(` <div class="card card-header mt-2" >
                            <div class="form-row justify-content-end">
                                <div class="form-group rem mb-0">
                                    <a href="#" class="btn btn-sm btn-danger py-1 px-3">x</a>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <lable for="company_name">Company Name</lable>
                                    <input name="company_name[]" class="form-control" id="company_name[]" placeholder="Company Name">
                                </div>
                                <div class="form-group col-lg-4">
                                    <lable for="company_designation">Company Designation</lable>
                                    <input name="company_designation[]" id="company_designation[]" class="form-control" placeholder="Company Designation">
                                </div>
                                <div class="form-group col-lg-4">
                                    <lable for="company_address">Company Address</lable>
                                    <input name="company_address[]" id="company_address[]" class="form-control" placeholder="Company Address">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <lable for="contact_name">Contact Name</lable>
                                    <input name="contact_name[]" id="contact_name[]" class="form-control" placeholder="Contact Name">
                                </div>
                                <div class="form-group col-lg-4">
                                    <lable for="contact_email">Contact Email</lable>
                                    <input name="contact_email[]" id="contact_email[]" class="form-control" placeholder="Contact Email">
                                </div>
                                <div class="form-group col-lg-4"
                                    <lable for="contact_phone">Contact Phone</lable>
                                    <input name="contact_phone[]" id="contact_phone[]" class="form-control" placeholder="Contact Phone">
                                </div>
                            </div>
							<div class="form-row">
                                <div class="form-group col-lg-4">
                                    <lable for="date_of_joining">Date Of Joining</lable>
                                    <input type="date" name="date_of_joining[]" id="date_of_joining[]" class="form-control" placeholder="Date Of Joining"> 
                                </div>
                                <div class="form-group col-lg-4">
                                    <lable for="date_of_leaving">Date Of Leaving</lable>
                                    <input type="date" name="date_of_leaving[]" id="wdate_of_leaving[]" class="form-control" placeholder="Date Of Leaving">
                                </div>
                                <div class="form-group col-lg-4">
                                    <lable for="reason_for_leaving">Reason For Leaving</lable>
                                    <input name="reason_for_leaving[]" class="form-control" id="reason_for_leaving[]" placeholder="Reason For Leaving">
                                </div>
                            </div>
							<div class="form-row">
                                <div class="form-group col-lg-6">
                                    <lable for="document_type">Document Type</lable>
                                    <select class="form-select form-control" id="document_type[]" name="work_document_type[]">
                                        <option selected disabled value="">Select Document Type</option>
                                        <option value="1">10th</option>
                                        <option value="2">12th</option>
                                        <option value="3">Graduation</option>
                                        <option value="4">Post Graduation</option>
                                    </select>
                                </div>
                                <div class="form-group col-lg-6">
                                <input type="hidden" name="work_document[]">
                                    <lable for="fileupload">Document Upload</lable>
                                    <input type="file" class="form-control p-1" id="customFile">
                                </div>
                            </div>
                        </div>`);
                        i++;
		              });

        //Different Permanent Address
        $("#diffrentAddress").on("click",function() {
            $(".permanent-address").toggle();
        }); 

        $(".btnNext").on("click",function(){
            $('.nav-tabs > .active').removeClass('active').next('li').addClass('active').find('a').trigger('click');
         
        });

        $('.btnPrevious').click(function(){
            $('.nav-tabs > .active').removeClass('active').prev('li').addClass('active').find('a').trigger('click');
            // $('.nav-tabs > li > .active').prev('li').find('a').trigger('click');
        });


        //
        $('#subBtn').on("click",function(e){
            e.preventDefault();  
            $('#staffFrom').addClass('was-validated');
            $("#staffFrom").validate({
                    focusInvalid: false,
                    invalidHandler: function(form, validator) {

                        if (!validator.numberOfInvalids())
                            return;

                        $('html, body').animate({
                            scrollTop: $(validator.errorList[0].element).offset().top
                        }, 2000);

                    }
                });
            $(".form-control:valid").css({
                "border-color": "#ced4da",
                "box-shadow": "none",
                "background-image": "none",
            });
            if ($('#staffFrom')[0].checkValidity() === false) {
                event.stopPropagation();
            } 
            else{
                $('#staffFrom').removeClass('was-validated')
                $('#staffFrom').submit();
            }
        });

        //user type change jquery
        $('#user_type').on('change', function() {
            var userType = $('#user_type').val();
            console.log(userType);
            if(userType == 'existing'){
                $('#StaffDetail,#StaffRole').addClass('d-none'); 
                $('#users').removeClass('d-none');
                $('#role_name,#name,#email,#password').removeAttr('required');
                $('#User').attr('required',true);
            }
            else{
                $('#StaffDetail,#StaffRole').removeClass('d-none'); 
                $('#role_name,#name,#email,#password').attr('required',true);
                $('#User').removeAttr('required');
                $('#users').addClass('d-none');
            }
        });
    });  
</script>
@endpush
</x-app-layout>
