<x-app-layout>
	<h4>Welcome..</h4>
</x-app-layout>