<x-app-layout>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500"> 
            <li class="breadcrumb-item"><a href="#" class="text-dark tx-16">Dashboard</a></li>
        </ol>
    </nav>
    <div class="card">
        <div class="tab-content">
            <div class="card-header d-flex align-items-center justify-content-between py-3 px-3">
                <h5 class="tx-15 mb-0">{{__('user-manager.permission_list')}}</h5>
                {{-- <a href="{{ route('employee.create') }}">
                    <button class="btn btn-md  btn-primary "><i data-feather="plus"></i>{{__('user-manager.add_employee')}}</button>
                </a> --}}
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table border table_wrapper rounded">
                        <thead>
                            <tr>
                                <th>{{__('common.sl_no')}}</th>
                                <th>{{__('user-manager.permission_name')}}</th>
                                <th>{{__('user-manager.permission_slug')}}</th>
                                <th>{{__('user-manager.sort_order')}}</th>
                                <th>{{__('common.status')}}</th>
                                <th>{{__('common.action')}}</th>
                            </tr>
                        </thead>
                        <tbody id="Search_Tr">
                            <tr>
                                <td>1</td>
                                <td>Admin</td>
                                <td>No </td>
                                <td>2</td>
                                </td>
                                <td>
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input toggle_status" id="customSwitch">
                                    <label class="custom-control-label" for="customSwitch"></label>
                                </div>
                                </td>
                                <td class="d-flex align-items-center gap-2 justify-content-center">
                                    <a href="#" class="btn btn-sm btn-white table_btn py-1 px-2"><i data-feather="eye"></i></a>
                                </td>
                            </tr>
                            @if (!empty($staff_list))
                                @foreach ($staff_list as $key => $staff)
                                    <tr>
                                        <td class="px-3">{{ $key + 1 }}</td>
                                        <td class="px-3">{{ $staff->staff_name }}<br> {{ $staff->staff_email }}</td>
                                        <td class="px-3">
                                            @if (!empty($staff->designation))
                                            {{ $staff->designation->designation_name }}
                                            @endif
                                        </td>
                                        <td class="px-3">
                                            @if (!empty($staff->department))
                                            {{ $staff->department->dept_name }}
                                            @endif
                                        </td>
                                        <td class="px-3">
                                            <div class="form-check form-switch">
                                                <input data-id="{{ $staff->staff_id }}" class="form-check-input toggle_status" data-on="Active" data-off="InActive" type="checkbox" role="switch" {{ $staff->status ? 'checked' : '' }} id="flexSwitchCheckDefault" checked>
                                            </div>
                                        </td>
                                        <td class="d-flex align-items-center gap-2 justify-content-center">
                                            <a href="{{ route('employee.edit', $staff->staff_id) }}" class="btn btn-sm btn-white table_btn py-1 px-2"><i class="uil uil-edit"></i></a>
                                            <button type="button" id="delete_btn" value="{{ $staff->staff_id }}" class="btn btn-sm btn-white py-1 px-2"><i class="uil uil-trash-alt"></i></button>
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>         
        </div><!--end row-->
    </div>
    <!--start delete modal-->
    <div class="modal fade" id="delete_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">{{__('user-manager.delete_permission')}}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
                </div>
                <div class="modal-body">
                    <h5>{{__('user-manager.are_you_sure')}}</h5>
                    <input type="hidden" id="delete_department_id" name="input_field_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{__('common.no')}}</button>
                    <button type="submit" class="btn btn-primary delete_submit_btn">{{__('common.yes')}}</button>
                </div>
            </div>
        </div>
    </div>
    <!--end delete modal-->
    @push('scripts')
    <script>
        $(document).ready(function() {
            $(document).on("click", "#delete_btn", function() {
                var permission_id = $(this).val();
                $('#delete_department_id').val(permission_id);
                $('#delete_modal').modal('show');
            });
            $(document).on('click', '.delete_submit_btn', function() {
                var permission_id = $('#delete_department_id').val();

                $('#delete_modal').modal('show');

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    type: "POST",
                    url: "{{ url('permission')}}/" + permission_id,
                    data: {
                        permission_id: permission_id,
                        _method: 'DELETE'
                    },
                    dataType: "json",
                    success: function(response) {

                        $('#delete_modal').modal('hide');
                        $('.flash-message').html(response.success);
                        $('.flash-message').addClass('alert alert-danger');
                        $('.flash-message').fadeOut(1000, function() {
                            location.reload();
                        });
                    }
                });

            });
        });
    </script>
    <!--end delete ajax-->
    <script type="text/javascript">
        // change status in ajax code start
        $('.toggle_class').change(function() {
            let status = $(this).prop('checked') === true ? 1 : 0;
            let permissions_id = $(this).data('id')

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "{{ url('permission-status-change') }}",
                data: {
                    'status': status,
                    'permissions_id': permissions_id
                },
                success: function(data) {
                    console.log(data);
                    // location.reload();
                    Toaster(' Permission Status Changed ');
                }
            });
        });
        // change status in ajax code end  

        $(".permission_sort_order").on("blur", function(e) {
            e.preventDefault();
            var permissions_id = $(this).data('id');
            var sort_order = $(this).val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{ url('permission-sortorder') }}",
                data: {
                    permissions_id: permissions_id,
                    sort_order: sort_order
                },
                dataType: "json",
                success: function(data) {

                    Toaster('Sort order updated ');
                    $('#permission_sort_order').val(data.sort_order);
                    $('#permission_sort_order').val(data.sort_order);
                }
            });
        });
        // end sortoreder ajax
    </script>
    @endpush
</x-app-layout>