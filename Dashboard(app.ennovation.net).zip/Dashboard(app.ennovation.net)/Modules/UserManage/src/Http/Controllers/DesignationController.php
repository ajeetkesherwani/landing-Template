<?php

namespace Modules\UserManage\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Modules\UserManage\Models\Designation;
use App\Helper\Helper;

class DesignationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $parameters =array( 
            "search" => "",
            "sortBy"=> "",
            "orderBY" => "",
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/designation";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        return view('UserManage::designation.index', collect($responseData->data));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('UserManage::designation.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         
        $parameters =array( 
            "designation_name" => $request->designation_name, 
        );
        
        $apiurl = "https://e-nnovation.net/backend/public/api/designation/store";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        if($responseData->message){
            return response()->json($responseData->message);
        }
        else{
            return response()->json($responseData['message']);
        } 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    { 
        $parameters =array( 
            "designation_id" => $id, 
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/designation/edit";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        if($responseData->data){
            return response()->json($responseData->data);
        }
        else{
            return respomse()->json(['data',$responseData['message']]);
        } 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
            //
    }

     /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // 
    }

    public function designationtUpdate(Request $request)
    {
        $parameters =array( 
            "designation_id" => $request->designation_id, 
            "designation_name" => $request->designation_name,
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/designation/update";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        if($responseData->data){
            return response()->json($responseData->message);
        }
        else{
            return respomse()->json(['data',$responseData['message']]);
        }  
    }

   public function changedesignationStatus(Request $request)
    {
        dd($request->all());
        $designation =  Designation::where('designation_id' ,$request->designation_id)->first();
        $designation->status = $request->status;
        $designation->update();
        return response()->json(['status'=>1, 'message'=>' Designation Status Changed Successfully']);
    }
    public function designationDestroy(Request $request)
    {
        
        $parameters =array( 
            "designation_id" => $request->designation_id,  
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/designation/delete";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        if($responseData->data){
            return response()->json($responseData->message);
        }
        else{
            return respomse()->json(['data',$responseData['message']]);
        }  
    }
}
