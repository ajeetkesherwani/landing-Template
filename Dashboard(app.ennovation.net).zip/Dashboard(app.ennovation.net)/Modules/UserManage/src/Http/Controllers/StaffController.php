<?php

namespace Modules\UserManage\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use App\Helper\Helper;
use Auth;

class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $parameters =array( 
            "search" => "",
            "sortBy"=> "",
            "orderBY" => "",
        );
        
        $apiurl = "https://e-nnovation.net/backend/public/api/staff";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
        // dd($responseData) ;
        if($responseData->data){
            return view('UserManage::staff.index', collect($responseData->data)); 
        }
        else{
            return view('UserManage::staff.index', collect($responseData['message'])); 
        } 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $parameters =array( 
            
        );
        $apiurl = "https://e-nnovation.net/backend/public/api/staff/create";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        if($responseData->data){
            return view('UserManage::staff.create', collect($responseData->data)); 
        }
        else{
            return view('UserManage::staff.create', collect($responseData['message'])); 
        }  
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        dd($request->all());
        $parameters =array( 
            "user_type" => $request->user_type,
            "name" => $request->name ?? '',
            "email" => $request->email ?? '' ,
            "password" => $request->password ?? '' ,
            "user_id" => $request->user_id ?? '',
            "role_name" => $request->role_name ?? '' ,
            "department_id" => $request->department_id,
            "designation_id" => $request->designation_id,
            "gender" => $request->gender,
            "phone_no" => $request->phone_no,
            "date_of_joining" => $request->date_of_joining,
            "date_of_leaving" => $request->date_of_leaving ?? '',
            "marital_status" => $request->marital_status,
            "date_of_birth" => $request->date_of_birth,
            "staff_id" => $request->staff_id ?? '',
            "street_address" => $request->street_address,
            "city" => $request->city,
            "state" => $request->state,
            "postcode" => $request->postcode,
            "countries_id" => $request->countries_id,
            "permanent_street_address" => $request->permanent_street_address,
            "permanent_city" => $request->permanent_city,
            "permanent_state" => $request->permanent_state,
            "permanent_postcode" => $request->permanent_postcode,
            "education_id" => $request->education_id,
            "university_name" => $request->university_name,
            "admission_at" => $request->admission_at,
            "passing_at" => $request->passing_at,
            "permanent_countries_id" => $request->permanent_countries_id,
            "permanent_phone_no" => $request->permanent_phone_no,
            "education_document_type" => $request->education_document_type,
            "education_document" => $request->education_document,
            "company_name" => $request->company_name,
            "company_designation" => $request->company_designation,
            "company_address" => $request->company_address,
            "contact_name" => $request->contact_name,
            "contact_email" => $request->contact_email,
            "contact_phone" => $request->contact_phone,
            "reason_for_leaving" => $request->reason_for_leaving,
            "work_document_type" => $request->work_document_type,
            "work_document" => $request->work_document,
            "salary" => $request->salary,
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/staff/store";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
        dd($responseData);
        if($responseData->data){
            return view('UserManage::staff.index', collect($responseData->message)); 
        }
        else{
            return view('UserManage::staff.index', collect($responseData['message'])); 
        }  
        return redirect()->route('employee.index')->with('success', 'Employee Added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // return view('UserManage::staff.index', collect($responseData->message)); 
        return view('UserManage::staff.show'); 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (Staff::find($id)->exists()) {
        $staff = Staff::find($id);
        $user_list = User::all();
        $department_list = Department::all();
        $designation_list = Designation::all();
        $country_list = Country::all();
        $staff_address = StaffAddress::where('staff_id', $staff->staff_id)->first();
        return view('UserManage::staff.edit', compact('staff', 'staff_address', 'user_list', 'department_list', 'designation_list', 'country_list'));
        }else{
            return redirect()->route('employee.edit')->with('error', "Employee don't Edit successfully");
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (Staff::where('staff_id', $id)->exists()) {
        $staff = Staff::find($id);
        $staff->delete(); 
         return response()->json(['success' => 'Employee deleted successfully']);
        }else{
            return response()->json(['error' => 'User already deleted!']);
        }
    }

    public function changeEmployeeStatus(Request $request)
    {
        $parameters =array( 
            
        );
        $apiurl = "https://e-nnovation.net/backend/public/api/staff/changeStatus";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        if($responseData->data){
            return view('UserManage::staff.create', collect($responseData->data)); 
        }
        else{
            return view('UserManage::staff.create', collect($responseData['message'])); 
        } 
    }
}
