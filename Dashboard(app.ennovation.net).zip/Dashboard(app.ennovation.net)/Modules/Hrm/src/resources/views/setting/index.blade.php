
<x-app-layout>

<nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500"> 
            <li class="breadcrumb-item"><a href="#" class="text-dark tx-16">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{url('hrm/setting')}}">{{ __('hrm.setting_list') }}</a></li>
        </ol>
    </nav>

<div class="contact-content">
    <div class="contact-content-header mg-b-20 mg-lg-b-25 mg-xl-b-30">
        <ul class="nav nav-line" role="tablist">
        <li class="nav-item"><a href="#leave-setting" class="nav-link  {{ request()->tab == 'leave-setting' || !isset(request()->tab) ? 'active' : '' }} " data-toggle="tab">{{ __('hrm.leave_setting')}}</a></li>
            <li class="nav-item"><a href="#attendence-setting" class="nav-link" data-toggle="tab">{{ __('hrm.attendence_setting')}}</a></li>
        </ul>

    </div>
    <div class="card contact-content-body">
        <div class="tab-content">
            <div id="leave-setting" class="tab-pane active">
                <div class="card-header">
                    <div class="d-flex align-items-center justify-content-between">
                    <h6 class="tx-15 mg-b-0">{{ __('hrm.setting_list') }}</h6>
                    <a href="{{ url('hrm/setting/leave-create') }}"
                                class="btn btn-sm btn-bg d-flex align-items-center mg-r-5"><i
                                    data-feather="plus"></i><span
                                    class="d-none d-sm-inline mg-l-5">{{ __('hrm.add_leave_type')}}</span></a>

                   
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table border table_wrapper">
                            <thead>
                                <tr>
                                    <th>{{__('common.sl_no')}}</th>
                                    <th>{{__('hrm.leave_type') }}</th>
                                    <th>{{__('hrm.no_of_days') }}</th>
                                   <th>{{__('hrm.information') }}</th>   
                                    <th class="text-center wd-10p">{{__('common.action')}}</th>
                                </tr>
                            </thead>
                            <tbody>
                                        @if (!empty($leave_type))

                                            @foreach ($leave_type as $key => $type)
                                                <tr>

                                                    <td>{{ ++$key }}</td>
                                                    <td>{{ ($type->leave_type_name) }}</td>
                                                    <td>{{ ($type->no_of_days) }}</td>
                                                    <td>{{ ($type->leave_info) }}</td>
                                                    <td class="d-flex align-items-center">
                                                        <a href="{{ url('hrm/setting/leave-edit/' . $type->leave_type_id) }}"
                                                            data-task-id="{{ $type->leave_type_id }}"
                                                            class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i
                                                                data-feather="edit-2"></i><span
                                                                class="d-none d-sm-inline mg-l-5"></span></a>
                                                      
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @endif
                                    </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div id="attendence-setting" class="tab-pane">
                <div class="card-header">
                    <div class="d-flex align-items-center justify-content-between">
                        <h6 class="tx-15 mg-b-0">{{ __('crm.lead_status_list') }}</h6>
                        <a href="#status_add" data-toggle="modal" class="btn btn-sm btn-bg d-flex align-items-center"><i data-feather="plus"></i><span class="d-none d-sm-inline mg-l-5">{{ __('crm.add_lead_status') }}</span></a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table border table_wrapper">
                            <thead>
                                <tr>
                                    <th>{{ __('common.sl_no')}}</th>
                                    <th>{{__('crm.status_name') }}</th>
                                    <th>{{__('common.status')}}</th>
                                    <th class="text-center wd-10p">{{ __('common.action') }}</th>
                                </tr>
                            </thead>
                           
                        </table>
                    </div>
                </div>
            </div>
          
        </div>
    </div>
</div>




     <!-------------- Edit source Modal --------------->
     <div class="modal fade" id="modalEditResult" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                  <h6 class="modal-title" id="exampleModalLabel">{{ __('crm.update_lead_source') }}</h6>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation novalidate" id="edit_result_title_form" novalidate>
                        <input type="hidden" name="input_field_id" id="edit_input_field">
                        <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label class="form-label">{{__('crm.source_name') }}<span
                                        class="text-danger">*</span></label>
                            <input name="source_name" id="editsource_name" type="text"
                            class="form-control" placeholder="{{ __('crm.source_name_placeholder') }}" required>
                            <span class="text-danger">
                                @error('source_name')
                                {{ $message }}
                                @enderror
                            </span>
                            <div class="invalid-feedback">
                                {{ __('crm.source_name_error') }}
                            </div>
                        </div>
                    </div>
                       
                        <div class="row">
                            <div class="col-sm-12 mt-4" required>
                                <input type="submit" id="add_title_submit" class="btn btn-primary" value="Update">
                            </div>
                        </div>
                    </form>
                </div>
           
            </div>
        </div>
    </div>
    <!--------------Edit source Modal end here --------------->


        <!-------------- Edit status Modal --------------->
        <div class="modal fade" id="modalEditStatus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                  <h6 class="modal-title" id="exampleModalLabel">{{ __('crm.update_lead_ststus') }}</h6>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation novalidate" id="edit_status_title_form" novalidate>
                       
                        <input name="source_id" id="hidden_status_id" type="hidden"
                        class="form-control">
                        <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label class="form-label">{{ __('crm.status_name')
                                    }}<span class="text-danger">*</span></label>
                            <input name="status_name" id="edit_status_name"
                            type="text" class="form-control" placeholder="{{ __('crm.status_name_placeholder') }}" required>
                            <span class="text-danger">
                                @error('status_name')
                                {{ $message }}
                                @enderror
                            </span>
                            <div class="invalid-feedback">
                                {{ __('crm.status_name_error') }}
                            </div>
                        </div>
                    </div>
                       
                        <div class="row">
                            <div class="col-sm-12 mt-4" required>
                                <input type="submit" id="add_title_submit" class="btn btn-primary" value="Update">
                            </div>
                        </div>
                    </form>
                </div>
           
            </div>
        </div>
    </div>



      






</x-app-layout>