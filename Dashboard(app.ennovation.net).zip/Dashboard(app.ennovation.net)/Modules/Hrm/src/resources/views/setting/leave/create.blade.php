<x-app-layout>
    <div class="contact-content">
        <div class="layout-specing">
            <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent px-0">
                    <li class="breadcrumb-item"><a href="">{{ __('hrm.setting_list') }}</a></li>
                   
                </ol>
            </nav>
            <div class="card contact-content-body">
                <form action="{{url('seo-task-store')}}" id="userForm"  method="POST" class="needs-validation" novalidate>
                    @csrf
                    <div class="card-header d-flex align-items-center justify-content-between py-2 px-3">
                        <h6 class="tx-15 mg-b-0">{{ __('hrm.add_leave_type')}}</h6>
                        
                    </div>
                    <div class="card-body">
                        <div data-label="Example" class="df-example demo-forms">
                        <div class="form-row">
              <div class="form-group col-md-6 col-6">
              <label class="form-label">{{ __('hrm.leave_type')}} <span class="text-danger mg-l-5">*</span></label>
              <input type="text" class="form-control" name="first_name" placeholder="{{ __('hrm.leave_type_placeholder')}}" required>
                      
            <div class="invalid-feedback">
                      {{ __('crm.customer_name_error')}}
                      </div>
              </div>
     <div class="form-group col-md-6 col-6">
              <label class="form-label">{{ __('hrm.no_of_days')}} <span class="text-danger mg-l-5">*</span></label>
              <input type="number" class="form-control" placeholder="{{ __('crm.customer_email_placeholder')}}" name="email" required>
                  <div class="invalid-feedback">
                  {{ __('crm.customer_emial_error')}}
                  </div>
              </div>

          </div>


          <div class="form-row">
        <div class="form-group col-md-6 col-6">
              <label class="form-label">{{ __('hrm.max_allowed')}} <span class="text-danger mg-l-5">*</span></label>
              <input type="number" class="form-control" name="first_name" placeholder="{{ __('hrm.leave_type_placeholder')}}" required>
                      
            <div class="invalid-feedback">
                      {{ __('crm.customer_name_error')}}
                      </div>
              </div>
       <div class="form-group col-md-6 col-6">
              <label class="form-label">{{ __('hrm.information')}} <span class="text-danger mg-l-5">*</span></label>
              
              <textarea name="note" rows="2" value="" class="form-control"></textarea>
                  <div class="invalid-feedback">
                  {{ __('crm.customer_emial_error')}}
                  </div>
              </div>

          </div>
                        </div>
                    </div>
                    <div class="">
                        <div class="col-sm-12 mb-3 mx-3 p-0">
                            <input type="submit" id="submit" name="send" class="btn btn-primary" value="Submit">
                            <a href="" class="btn btn-secondary mx-1">Cancel</a>
                        </div><!--end col-->
                    </div><!--end row-->
                </form>

             






            </div>
        </div>
    </div>
    @push('scripts')
  
    @endpush
</x-app-layout>