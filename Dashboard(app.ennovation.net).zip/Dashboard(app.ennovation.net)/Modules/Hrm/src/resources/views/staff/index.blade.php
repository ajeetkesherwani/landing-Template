<x-app-layout>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500"> 
            <li class="breadcrumb-item"><a href="#" class="text-dark tx-16">Dashboard</a></li>
        </ol>
    </nav>
    <div class="card">
        <div class="tab-content">
            <div class="card-header d-flex align-items-center justify-content-between py-2 px-3">
                <h5 class="tx-15 mb-0">{{__('user-manager.employee_list')}}</h5>
                <a href="{{ route('hrm.staff.create') }}">
                    <button class="btn btn-md  btn-primary "><i data-feather="plus"></i>{{__('user-manager.add_employee')}}</button></a>
                </a>
            </div>
            <div class="card-body">
                <div class="row align-item-center mb-3">
                    <div class="col-lg-2 col-md-3 col-4">
                        <select class="form-control form-select" aria-label="Default select example">
                            <option>10</option>
                        </select>
                    </div>
                    <div class="col-lg-6 col-md-3 col-8">
                        <input type="text" id="Search" class="form-control col-lg-4 fas fa-search" placeholder="Search..." aria-label="Search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table border table_wrapper rounded">
                        <thead>
                            <tr>
                                <th>{{__('common.sl_no')}}</th>
                                <th>Employee id</th>
                                <th>Staff Photo</th>
                                <th>Staff Name</th>
                                <th>Staff Email</th>
                                <th >Department</th>
                                <th>Designation</th>
                                <th>Verification Status</th>
                                <th>{{__('common.status')}}</th>
                                <th>{{__('common.action')}}</th>
                            </tr>
                        </thead>
                        <tbody id="Search_Tr">
                            @if (!empty($data))
                                @forelse($data as $key => $staff)
                                    <tr>  
                                        <td class="px-3">{{ $key + 1 }}</td>
                                        <td>{{$staff->employee_id}}</td>
                                        <td>
                                            <img src="{{$staff->staff_photo}}" alt="" class="img-fluid" style="height:50px;width:50px;">
                                        </td>
                                        <td class="px-3">{{ $staff->staff_name }}</td>
                                        <td>{{ $staff->staff_email }}</td>
                                        <td class="px-3">
                                            @if (!empty($staff->department))
                                            {{ $staff->department->dept_name }}
                                            @endif
                                        </td>
                                        <td class="px-3">
                                            @if (!empty($staff->designation))
                                            {{ $staff->designation->designation_name }}
                                            @endif
                                        </td>
                                        <td>
                                            <select name="" data-id="{{$staff->staff_id}}" id="staffVerStatus" class="form-select form-control col-10">
                                                <option value="0" {{($staff->verification_status =='0' ? 'selected' : '')}}>Pending</option>
                                                <option value="1" {{($staff->verification_status =='1' ? 'selected' : '')}}>Verified</option>
                                            </select>
                                        </td>
                                        <td>
                                            <select name="" id="staffStatus" data-id="{{ $staff->staff_id }}" class="form-select form-control">
                                                <option value="1" id="staffActive"  {{($staff->status =='1' ? 'selected' : '')}} >Active</option>
                                                <option value="2" {{($staff->status =='2' ? 'selected' : '')}}>InActive</option>
                                            </select>
                                        </td>
                                        <!-- <td>
                                            <div class="custom-control custom-switch">
                                                <input type="checkbox" data-id="{{ $staff->staff_id }}" {{ ($staff->status == '1') ? 'checked' : '' }} class="custom-control-input toggle_status" data-on="Active" data-off="InActive" id="customSwitch">
                                                <label class="custom-control-label" for="customSwitch"></label>
                                            </div>
                                        </td> -->
                                        <td class="d-flex align-items-center gap-2 justify-content-center my-2">
                                            <a href="{{ route('hrm.staff.show', $staff->staff_id) }}" id="staff_view" class="btn btn-sm btn-white table_btn py-1 px-2"><i data-feather="eye"></i></a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5">
                                            <h5 class="text-center mb-0 py-1">No Record Found !.</h5>
                                        </td>
                                    </tr>
                                @endforelse
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>         
        </div><!--end row-->
    </div>
    <!---- Staff Status Change modal start here---> 
    <div class="modal fade effect-scale" id="statusModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title">Termination</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation" method="POST" id="update_userForm" novalidate>
                        <input name="staff_id" id="staff_id" type="hidden" class="form-control">
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label class="form-label">Termination Reason<span class="text-danger">*</span></label>
                                <select name="termination_reason" id="termination_reason" class="form-control form-select">
                                    <option value="" selected disabled>Select Termination Reason</option>
                                    <option value=1>Left </option>
                                    <option value=2>Resigned</option>
                                    <option value=3>Fired</option>
                                    <option value=4>Others</option>
                                </select>
                                <div class="invalid-feedback">
                                    Please Select termination Reason
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label class="form-label">Remark Details<span class="text-danger">*</span></label>
                                <textarea name="remark_details" id="remark_details" cols="30" rows="5"></textarea>
                                <div class="invalid-feedback">
                                    please Enter Remark Details
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
                        <input type="Submit" id="submitBtn" name="send" class="btn btn-primary" value="{{__('common.submit')}}">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!---- Staff status Change modal end here--->
        
    @push('scripts')
        <!-- search ajax-->
        <script>
            //staff verification status change jquery
            $('#staffVerStatus').change( function(){
                var data = {
                    staff_id: $('#staffVerStatus').data('id'),
                    type: 'verification',  
                    verification_status :$('#staffVerStatus').val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ route('hrm.staffStatus')}}",
                    data: data,
                    dataType: "json",
                    success: function(response) { 
                        Toaster(response.message);
                        setTimeout(function() {
                            location.reload(true);
                        }, 1000); 
                    }
                });
            }); 

            //staff status chanage jquery 
            $('#staffStatus').change( function(e){
                var status = $('#staffStatus').val();
                var staff_id = $('#staffStatus').data('id');
                if(status == '1'){
                    $('#statusModal').modal('show');
                    $('#staff_id').val(staff_id);
                }
                else{
                    var data = {
                    staff_id: $('#staffStatus').data('id'),
                    type: 'staffStatus', 
                    status:status,
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ route('hrm.staffStatus')}}",
                    data: data,
                    dataType: "json",
                    success: function(response) { 
                        Toaster(response.message);
                        setTimeout(function() {
                            location.reload(true);
                        }, 1000); 
                    }
                });
                }
            }); 

            $('#submitBtn').on("click",function(e){
                e.preventDefault();
                data = {
                    staff_id: $('#staffStatus').data('id'),
                    type: 'staffStatus', 
                    staff_id: $('#staff_id').val(),
                    termination_reason: $('#termination_reason').val(),
                    remark_details: $('#remark_details').val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ route('hrm.staffStatus')}}",
                    data: data,
                    dataType: "json",
                    success: function(response) { 
                        $('#statusModal').modal('hide');
                        Toaster(response.message);
                        setTimeout(function() {
                            location.reload(true);
                        }, 1000); 
                    }
                });
            });
        </script>
    @endpush
</x-app-layout>