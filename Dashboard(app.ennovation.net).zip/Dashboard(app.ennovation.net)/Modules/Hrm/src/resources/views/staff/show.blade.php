<style>
	$(".form-control:valid").css({
		"border-color": "#ced4da",
		"box-shadow": "none",
		"background-image": "none",
	});

</style>
<x-app-layout>
	<nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500">
            <li class="breadcrumb-item"><a href="#" class="text-dark tx-15">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="" class="text-dark tx-15">Staff</a></li> 
        </ol>
    </nav>
	<div class="card">
		<div class="tab-content">
			<div class="card-header d-flex align-items-center justify-content-between py-3 px-3">
				<h5 class="tx-15 mb-0">Staff Information</h5>
			</div>
			<div class="card-body pb-0">
				<!---- Basic Information data form start here ------------>
				<div class="card">
					<div class="row">
						<div class="col-sm-3 col-md-3 col-lg-3 pt-5 py-3"> 
							<div class="staff-image">
								<img src="{{$staff_photo}}" alt="" class="img-fluid" style="border-radius: 50%;border: 1px solid #ccc">
							</div>
							<div class="text-center my-3">
								<h6>{{$staff_name}}</h6>
							</div>
							<div class="text-center my-1">
							<p>{{$staff_email}}</p>
							</div>
						</div>
						<div class="col-sm-9 col-md-9 col-lg-9 border-left p-3">  
							<div class="card ">
								<div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
									<h6 class="tx-uppercase tx-semibold mg-b-0">BAsic Information</h6>
									<nav class="nav nav-with-icon tx-13">
									<a href="#" data-target="#basicInfoAddModal" data-toggle="modal" class="nav-link"><i data-feather="plus"></i>Add</a>
									<a href="#" data-target="#basicInfoModal" data-toggle="modal" class="nav-link"><i data-feather="edit-2"></i>Edit</a>
									</nav>
								</div><!-- card-header -->
								<div class="card-body pd-25">
								<div class="row d-flex justify-content-between px-4 pt-3">
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Employee Id:</h6>
										<p>{{$employee_id}}</p>
									</div>
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Designation :</h6> 
										<p>{{$designation->designation_name}}</p>
									</div>
								</div>
								<div class="row d-flex justify-content-between px-4 pt-3">
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Department:</h6>
										<p>{{$department->dept_name}}</p>
									</div>
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Gender :</h6> 
										<p>
											@if($gender == '1')
												Male
											@elseif($gender == '2')
												Female
											@else
												Transgender
											@endif
										</p>
									</div>
								</div>
								<div class="row d-flex justify-content-between px-4 pt-3">
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Date of Birth :</h6> 
										<p>{{$date_of_birth ?? ''}}</p>
									</div>
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Phone:</h6> 
										<p>{{$staff_phone ?? ''}}</p>
									</div>
								</div>
								<div class="row d-flex justify-content-between px-4 pt-3">
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Date of joining :</h6> 
										<p>{{$date_of_joining ?? ''}}</p>
									</div>
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Date of leaving :</h6> 
										<p>{{$date_of_leaving ?? ''}}</p>
									</div>
								</div>
								<div class="row d-flex justify-content-between px-4 pt-3">
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Matrital Status:</h6> 
										<p>
											@if($marital_status == '1')
												Married
											@else 
												Unmarried
											@endif
										</p>
									</div>
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Salary :</h6> 
										<p>{{$salary ?? ''}}</p>
									</div>
								</div>
								<div class="row d-flex justify-content-between px-4 pt-3">
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Verification Status :</h6> 
										<p>
											@if($verification_status == '1')
												<span class="badge badge-danger">Pending</span>
											@else
												<span class="badge badge-success">Verified</span>
											@endif
										</p>
									</div>
									<div class="col-6 col-sm-12 col-md-6 d-flex justify-content-between">
										<h6>Status :</h6> 
										<p>
											@if($status == '2')
												<span class="badge badge-danger">Terminated</span>
											@else
												<span class="badge badge-success">Working</span>
											@endif
										</p>
									</div>
								</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!---- Basic Information data form end here ------------>
				<!---- Permanent and Present Address start here -------->
				<div class="row d-flex mt-3">
					@if($staff_address)
					<input type="hidden" value="{{json_encode($staff_address)}}" id="totalAddressData">
						@foreach($staff_address as $address)
							@if($address->address_type == '1') 
								<div class="col-lg-6 col-md-6 col-sm-12">
									<div class="card mg-b-20 mg-lg-b-25">
										<div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
											<h6 class="tx-uppercase tx-semibold mg-b-0">Permanent Address</h6>
											<nav class="nav nav-with-icon tx-13">
											<a href="#" data-target="#addressModal" data-id="{{$address->address_id}}" id="permanent_address" data-toggle="modal" class="nav-link"><i data-feather="edit-2"></i>Edit</a>
											</nav>
										</div><!-- card-header -->
										<div class="card-body">
											<div class="col-12 d-flex">
												<p class="mg-b-3 tx-color-02"><span class="tx-medium tx-color-01">{{$address->street_address}}</span>, {{$address->city}}, {{$address->state}},</p>&nbsp;
												<span class="d-block tx-13 tx-color-03">{{$address->country->countries_name}},  {{$address->postcode}}</span>
											</div>
										</div>
									</div>
								</div>
							@else
								<div class="col-lg-6 col-md-6 col-sm-12">
									<div class="card mg-b-20 mg-lg-b-25">
										<div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
											<h6 class="tx-uppercase tx-semibold mg-b-0">Present Address</h6>
											<nav class="nav nav-with-icon tx-13">
											<a href="#" data-target="#addressModal" id="present_address" data-id="{{$address->address_id}}" data-toggle="modal" class="nav-link"><i data-feather="edit-2"></i>Edit</a>
											</nav>
										</div><!-- card-header -->
										<div class="card-body">
											<div class="col-12 d-flex">
												<p class="mg-b-3 tx-color-02"><span class="tx-medium tx-color-01">{{$address->street_address}}</span>, {{$address->city}}, {{$address->state}},</p>&nbsp;
												<span class="d-block tx-13 tx-color-03">{{$address->country->countries_name}},  {{$address->postcode}}</span>
											</div>
										</div>
									</div>
								</div>
							@endif
						@endforeach
					@endif
				</div>
				<!---- Permanent and Present Address end here -------->
				<!---- Staff Education  and document section section start here -------->
				<div class="row d-flex">
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="card mg-b-20 mg-lg-b-25">
							<div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
								<h6 class="tx-uppercase tx-semibold mg-b-0">Education</h6> 
								<nav class="nav nav-with-icon tx-13"> 
									<a href="#" data-target="#EducationAddModal" data-toggle="modal" class="nav-link"><i data-feather="plus"></i>Add</a>
								</nav>
							</div><!-- card-header -->
							@if($staff_qualification)
								@foreach($staff_qualification as $education)
									<div class="card-body pb-0">
										<div class="col-12 d-flex justify-content-between">
											<h6>{{$education->education->education_name}}</h6>
											<p>{{$education->university_name}}</p>
											<p class="d-flex">{{$education->admission_at}} - {{$education->passing_at}}  &nbsp;
												<a href="#delete_modal" data-toggle="modal" id="delete_btn" class="btn btn-sm btn-white d-flex align-items-center mg-r-5" data-id="{{$department->department_id}}"><i data-feather="edit-2"></i></a>
											</p>
										</div>
									</div>
								@endforeach
							@endif
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="card mg-b-20 mg-lg-b-25">
							<div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
								<h6 class="tx-uppercase tx-semibold mg-b-0">Document</h6>
							</div><!-- card-header -->
							<div class="row px-3 py-3">
							@if($staff_document)
								@foreach($staff_document as $document)
									<div class="col-lg-4 col-md-4 col-sm-4 text-center">
										<a href=""><span>{{$document->doc_info->document_name}}</span></a>
										<img src="{{$document->document_file}}" alt="">
									</div>
								@endforeach
							@endif
							</div>
							
						</div>
					</div>
				</div>
				<!---- Staff Education section section end here --------> 
				<!---- Staff Work exeperience section start here -------->
				@if(!empty($staff_experiance))
					<div class="row d-flex"> 
						<div class="col-lg-12 col-md-12 col-sm-12">
							<div class="card mg-b-20 mg-lg-b-25">
								<div class="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
									<h6 class="tx-uppercase tx-semibold mg-b-0">Work Experience</h6>
									<nav class="nav nav-with-icon tx-13"> 
										<a href="#" data-target="#workInfoAddModal" data-toggle="modal" class="nav-link"><i data-feather="plus"></i>Add</a>
									</nav>
								</div> 
								<div class="row">
								<input type="hidden" id="TotalWorkExpData" value="{{ json_encode($staff_experiance)}}">
									@foreach($staff_experiance as $experience)  
										<div class="col-lg-6 border-right">
											<div class="card-body">
												<div class="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
													<div class="d-flex justify-content-between">
														<h5 class="mg-b-5">{{$experience->company_name}}</h5>
														<a href="#workInfoModal"  data-id="{{$experience->experience_id}}" data-toggle="modal" id="delete_btn" class="staffWorkExp btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="edit-2"></i></a>
													</div>
													<p class="mg-b-3 tx-color-02"><span class="tx-medium tx-color-01">{{$experience->company_designation}}</span>, {{$experience->company_address}}</p>
													<span class="d-block tx-13 tx-color-03">{{$experience->date_of_joining}} - {{$experience->date_of_leaving}}</span>

													<ul class="pd-l-10 mg-0 mg-t-20 tx-13">
														<li>{{$experience->contact_name}}</li>
														<li>{{$experience->contact_email}}</li>
														<li>{{$experience->contact_phone}}</li>
														<li>{{$experience->reason_for_leaving}}</li> 
													</ul>
												</div> 
											</div>
										</div>
									@endforeach
								</div>
							</div>
						</div> 
					</div>
				@endif 
			</div>         
		</div> 
	</div> 
	<!----- Work Experience Add modal start here ------------>
	<div class="modal fade" id="workInfoAddModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                    <h6 class="modal-title" id="exampleModalLabel">Work Experience</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation" id="userForm" novalidate>
                        <input name="department_id" id="department_id" type="hidden" class="form-control">
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label">Company Name<span class="text-danger">*</span></label>
                                <input name="comany_name"   id="comany_name" type="text" class="form-control" placeholder="Company Name" required>
                                <div class="invalid-feedback">
                                    Enter Comany Name
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label"> Company Designation<span class="text-danger">*</span></label>
                                <input name="company_designation"   id="company_designation" type="text" class="form-control" placeholder="Company Designation" required>
								<div class="invalid-feedback">
                                    Enter Comany Designation
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
						<div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label"> Company Address</label>
                                <input name="comany_address"  id="comany_address" type="text" class="form-control" placeholder="Comapny Address">
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label">Conatct Name<span class="text-danger">*</span></label>
                                <input name="contact_name"   id="contact_name" type="text" class="form-control" placeholder="Conatct Name" >
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
						<div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label">Contact Email<span class="text-danger">*</span></label>
                                <input name="contact_email"  id="contact_email" type="text" class="form-control" placeholder="Contact Email">
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label"> Contact Phone</label>
                                <input name="contact_phone"   id="contact_phone" type="text" class="form-control" placeholder="Contact Phone">
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
						<div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label">Date Of Joining</label>
                                <input name="date_of_joining" id="date_of_joining" type="date" class="form-control" placeholder="Date Of Joining">
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label">Date Of Leaving</label>
                                <input name="date_of-leaving"   id="date_of-leaving" type="date" class="form-control" placeholder="Date Of Leaving">
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
						<div class="form-row">
							<div class="form-group col-lg-12">
                                <label class="form-label">Reason For Leaving</label>
                                <input name="reason_for_leaving"  id="reason_for_leaving" type="text" class="form-control" placeholder="Reason For Leaving">
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
						</div>
						<div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label">Document Type</label>
                                <input name="document_type"  id="document_type" type="text" class="form-control" placeholder="Document Type">
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label">Document Upload</label>
                                <input name="document_upload"  id="document_upload" type="file" class="form-control" placeholder="Document Upload">
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>

                    <input type="submit" id="submit" name="send" class="btn btn-primary" value="{{__('common.submit')}}">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!----- Work Experience Add modal end here ------------>
	<!----- Work Experience Edit modal start here ------------>
    <div class="modal fade" id="workInfoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                    <h6 class="modal-title" id="exampleModalLabel">Work Experience</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation" id="userForm" novalidate>
                        <input name="department_id" id="department_id" type="hidden" class="form-control">
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label">Company Name<span class="text-danger">*</span></label>
                                <input name="comany_name"   id="edit_comany_name" type="text" class="form-control" placeholder="Company Name" required>
                                <div class="invalid-feedback">
                                    Enter Comany Name
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label"> Company Designation<span class="text-danger">*</span></label>
                                <input name="company_designation"   id="edit_company_designation" type="text" class="form-control" placeholder="Company Designation" required>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
						<div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label"> Company Address</label>
                                <input name="comany_address"  id="edit_comany_address" type="text" class="form-control" placeholder="Comapny Address" required>
                                <div class="invalid-feedback">
                                    Enter Company Address
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label">Conatct Name<span class="text-danger">*</span></label>
                                <input name="contact_name"   id="edit_contact_name" type="text" class="form-control" placeholder="Conatct Name" required>
                                <div class="invalid-feedback">
                                    {{__('user-manager.name_error')}}
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
						<div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label">Contact Email<span class="text-danger">*</span></label>
                                <input name="contact_email"  id="edit_contact_email" type="text" class="form-control" placeholder="Contact Email" required>
                                <div class="invalid-feedback">
                                    {{__('user-manager.name_error')}}
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label"> Contact Phone</label>
                                <input name="contact_phone"   id="edit_contact_phone" type="text" class="form-control" placeholder="Contact Phone" required>
                                <div class="invalid-feedback">
                                    {{__('user-manager.name_error')}}
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
						<div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label">Date Of Joining</label>
                                <input name="date_of_joining" id="edit_date_of_joining" type="date" class="form-control" placeholder="Date Of Joining" required>
                                <div class="invalid-feedback">
                                    {{__('user-manager.name_error')}}
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label">Date Of Leaving</label>
                                <input name="date_of-leaving"   id="edit_date_of-leaving" type="date" class="form-control" placeholder="Date Of Leaving" required>
                                <div class="invalid-feedback">
                                    {{__('user-manager.name_error')}}
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
						<div class="form-row">
							<div class="form-group col-lg-12">
                                <label class="form-label">Reason For Leaving</label>
                                <input name="reason_for_leaving"  id="edit_reason_for_leaving" type="text" class="form-control" placeholder="Reason For Leaving" required>
                                <div class="invalid-feedback">
                                    {{__('user-manager.name_error')}}
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
						</div>
						<div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label">Document Type</label>
                                <input name="document_type"  id="edit_document_type" type="text" class="form-control" placeholder="Document Type">
                                <div class="invalid-feedback">
                                    {{__('user-manager.name_error')}}
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label">Document Upload</label>
                                <input name="document_upload"  id="edit_document_upload" type="file" class="form-control" placeholder="Document Upload">
                                <div class="invalid-feedback">
                                    {{__('user-manager.name_error')}}
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>

                    <input type="submit" id="submit" name="send" class="btn btn-primary" value="{{__('common.submit')}}">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!----- Work Experience Edit modal end here ------------>
	<!----- Address modal start here ------------>
    <div class="modal fade" id="addressModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Address</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation" id="userForm" novalidate>
                        <input name="department_id" id="department_id" type="hidden" class="form-control">
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label">Contact Number</label>
                                <input name="contact_number"   id="contact_number" type="text" class="form-control" placeholder="Contact Number"  >
                                <div class="invalid-feedback">
                                    Enter Comany Name
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label"> Street Address</label>
                                <input name="street_address"   id="street_address" type="text" class="form-control" placeholder="Street Address"  >
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
						<div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label">City</label>
                                <input name="city"  id="city" type="text" class="form-control" placeholder="City"  >
                                <div class="invalid-feedback">
                                    Enter Company Address
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label">State</label>
                                <input name="state" id="state" type="text" class="form-control" placeholder="State"  >
                                <div class="invalid-feedback">
                                    {{__('user-manager.name_error')}}
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
						<div class="form-row">
                            <div class="form-group col-lg-6">
                                <label class="form-label">Country</label>
                                <input name="contact_email"  id="contact_email" type="text" class="form-control" placeholder="Country"  >
                                <div class="invalid-feedback">
                                    {{__('user-manager.name_error')}}
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
							<div class="form-group col-lg-6">
                                <label class="form-label">Postcode</label>
                                <input name="postcode"   id="postcode" type="text" class="form-control" placeholder="Postcode"  >
                                <div class="invalid-feedback">
                                    {{__('user-manager.name_error')}}
                                </div>
                                <span class="text-danger">
                                    @error('dept_name')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
                    	<input type="submit" id="submit" name="send" class="btn btn-primary" value="{{__('common.submit')}}">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!----- Address modal end here ------------>
@push('scripts')
	<script>
		$(document).ready(function(){
			// Work exeperience data show in edit modal
			$('.staffWorkExp').on("click",function(e){
				e.preventDefault();
				var staff_id = $(this).data('id');
				total_data = $('#TotalWorkExpData').val();
				var workData = $.parseJSON(total_data);
				$.each(workData, function(index, value) {
					if(value.experience_id == staff_id){
						$('#edit_comany_name').val(value.company_name);
						$('#edit_company_designation').val(value.company_designation);
						$('#edit_comany_address').val(value.company_address);
						$('#edit_contact_name').val(value.contact_name);
						$('#edit_contact_email').val(value.contact_email);
						$('#edit_contact_phone').val(value.contact_phone);
						$('#edit_date_of_joining').val(value.date_of_joining);
						$('#edit_date_of-leaving').val(value.date_of_leaving);
						$('#edit_reason_for_leaving').val(value.reason_for_leaving);
					}
				});
				console.log(staff_id);
			});
			// Permanent address data show in edit modal
			$('#permanent_address').on("click",function(e){
				e.preventDefault();
				var address_id = $('#permanent_address').data('id');
				var total_address = $('#totalAddressData').val();
				var addressData = $.parseJSON(total_address);
				console.log(addressData);
				$.each(addressData, function(index, value) {
					if(value.address_id == address_id){
						$('#contact_number').val(value.phone_no);
						$('#street_address').val(value.street_address);
						$('#city').val(value.city);
						$('#state').val(value.state);
						$('#country').val(value.countries_id);
						$('#postcode').val(value.postcode);
					}
				});
			});
			// Present Adress data show in edit modal
			$('#present_address').on("click",function(e){
				e.preventDefault();
				var address_id = $('#present_address').data('id');
				var total_address = $('#totalAddressData').val();
				var addressData = $.parseJSON(total_address);
				$.each(addressData, function(index, value) {
					if(value.address_id == address_id){
						$('#contact_number').val(value.phone_no);
						$('#street_address').val(value.street_address);
						$('#city').val(value.city);
						$('#state').val(value.state);
						$('#country').val(value.countries_id);
						$('#postcode').val(value.postcode);
					}
				});
			});
		});
	</script>
@endpush

</x-app-layout>