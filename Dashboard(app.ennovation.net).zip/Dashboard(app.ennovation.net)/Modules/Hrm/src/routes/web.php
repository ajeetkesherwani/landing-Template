<?php
use Illuminate\Support\Facades\Route;
use Modules\Hrm\Http\Controllers\SettingController;
use Modules\Hrm\Http\Controllers\StaffController;
use Modules\Hrm\Http\Controllers\DepartmentController;
use Modules\Hrm\Http\Controllers\DesignationController;
use Modules\Hrm\Http\Controllers\LeaveController;




/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your aaplication. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['as'=> 'hrm.', 'prefix' => 'hrm'], function(){

    //setting
   
    Route::get('setting', [SettingController::class, 'index'])->name('setting');
    Route::get('setting/leave-create', [SettingController::class,'leave_create'])->name('setting/leave-create');
    Route::get('setting/leave-edit/{id}', [SettingController::class,'leave_edit'])->name('setting/leave-edit');
    Route::post('setting/leave-update/{id}', [SettingController::class,'leave_update'])->name('setting/leave-update');
    Route::post('setting/leave-store', [SettingController::class,'leave_store'])->name('setting/leave-store');


    //leave
    Route::get('leave', [LeaveController::class, 'index'])->name('leave');
    Route::get('leave/create', [LeaveController::class,'create'])->name('leave-create');
    Route::post('leave/store', [LeaveController::class,'store'])->name('leave-store');
    Route::get('leave/edit/{id}', [LeaveController::class,'edit'])->name('leave/edit');
    Route::post('leave/update/{id}', [LeaveController::class,'update'])->name('leave/update');
    Route::post('changeStatus', [LeaveController::class,'changeStatus'])->name('changeStatus');
    


    //Staff
    Route::resource('staff', StaffController::class)->except([
        'edit', 'update', 'destroy'
    ]);
    Route::post('staffStatus', [StaffController::class,'chgStaffStatus'])->name('staffStatus');

    // department   
    Route::resource('department', DepartmentController::class);
    Route::post('department/dptUpdate', [DepartmentController::class,'dptUpdate'])->name('dptUpdate');
    Route::post('department/dptStatus', [DepartmentController::class,'dptStatus'])->name('dptStatus');
    Route::post('dptdestroy/{id}', [DepartmentController::class,'dptDestroy'])->name('dptdestroy');

      //DESIGNATION ROUTES
      Route::resource('designation', DesignationController::class);
      Route::post('designation/Update', [DesignationController::class,'desgUpdate'])->name('designation-updatedata');
      Route::post('designationDestroy/{id}', [DesignationController::class,'desgDestroy'])->name('designationDestroy');
      Route::post('designation/changedesignationStatus', [DesignationController::class,'chgdesgStatus'])->name('changedesignationStatus');
});
   
   
   