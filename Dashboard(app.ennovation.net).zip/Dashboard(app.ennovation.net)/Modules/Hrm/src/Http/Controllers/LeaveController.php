<?php
namespace Modules\Hrm\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Helper\Helper;

class LeaveController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $parameters =array( 
            "search" => "",
            "sortBy"=> "",
            "orderBY" => "",
        );
        
        $apiurl = "https://e-nnovation.net/backend/public/api/leave";

        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 

       // dd( $responseData);
       return view('Hrm::leave.index', collect($responseData->data)); 
      
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    { 
        $parameters =array(
    
     
            "language" => "1",
           );
    
            $apiurl = config('apipath.leave-type');
            $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
           //  dd( $responseData->data);
    
           return view('Hrm::leave.create', collect($responseData->data)); 
          
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {       
       
        $parameters =array( 
            "leave_date" => $request->leave_date, 
          
            "leave_type_id" => $request->leave_type_id, 
            "reason" => $request->reason, 
            "user_id"=>$request->user_id
        );


        $apiurl = "https://e-nnovation.net/backend/public/api/leave/store";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
      // dd($responseData);
        if($responseData->message){
            return redirect()->route('hrm.leave')->with('success', $responseData->message);
           
        }
        else{
            return redirect()->route('hrm.leave')->with('error', $responseData->message);
        } 

    }

   
    public function edit($id)
    {   
        $parameters =array(
    
     
            "leave_id" => $id
           );
    
         //   $apiurl = config('apipath.leave-type');
         $apiurl = "https://e-nnovation.net/backend/public/api/leave/edit";
         $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
           //  dd( $responseData->data);
    
           return view('Hrm::leave.edit', collect($responseData->data)); 
      
    }


    public function update(Request $request,$id)
    {
        $parameters =array( 
             "leave_id"=>$id,
            "leave_date" => $request->leave_date, 
           
            "leave_type_id" => $request->leave_type_id, 
            "reason" => $request->reason, 
            "user_id"=>$request->user_id,
            "status"=>$request->status
        );


        $apiurl = "https://e-nnovation.net/backend/public/api/leave/update";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
      // dd($responseData);
        if($responseData->message){
            return redirect()->route('hrm.leave')->with('success', $responseData->message);
           
        }
        else{
            return redirect()->route('hrm.leave')->with('error', $responseData->message);
        } 

    }


    
    public function changeStatus(Request $request)
    {
         $parameters =array(
                    "leave_id" => $request->leave_id,
               
                    "status" => $request->status,
                );

               // $apiurl = config('apipath.lead-changeStatus');

         $apiurl ="https://e-nnovation.net/backend/public/api/leave/status";
                
                $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
               //  dd( $responseData);

        return response()->json(['status' => 1, 'message' => $responseData->message]);
    }

 
 
}
