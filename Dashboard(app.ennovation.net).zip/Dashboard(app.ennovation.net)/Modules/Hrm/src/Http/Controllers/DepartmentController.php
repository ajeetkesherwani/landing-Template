<?php
namespace Modules\Hrm\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Hrm\Models\Department;
use Auth;
use App\Helper\Helper;

class DepartmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $parameters =array( 
            "search" => "",
            "sortBy"=> "",
            "orderBY" => "",
        );
        
        $apiurl = "https://e-nnovation.net/backend/public/api/department";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
        return view('Hrm::department.index', collect($responseData->data)); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {    
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {       
       
        $parameters =array( 
            "dept_name" => $request->dept_name, 
        );
        $apiurl = "https://e-nnovation.net/backend/public/api/department/store";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        if($responseData->message){
            return response()->json($responseData->message);
        }
        else{
            return response()->json($responseData['message']);
        } 

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        
        $parameters =array( 
            "updateId" => $id, 
        );
        $apiurl = "https://e-nnovation.net/backend/public/api/department/edit";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        if($responseData){
            return response()->json($responseData);
        }
        else{
            return response()->json($responseData['message']);
        } 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {    
        // 
    }

    public function DptUpdate(Request $request)
    {
        $parameters =array( 
            "department_id" => $request->department_id, 
            "dept_name" => $request->dept_name,
            "status" => $request->status,
        );
        $apiurl = "https://e-nnovation.net/backend/public/api/department/update";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        if($responseData->message){
            return response()->json($responseData->message);
        }
        else{
            return response()->json($responseData['message']);
        }
   }

   public function DptStatus(Request $request)
    {
        dd($request->all());
    }  
    public function DptDestroy(Request $request)
    {
         
        $parameters =array( 
            "deleteId" => $request->department_id, 
        );
        $apiurl = "https://e-nnovation.net/backend/public/api/department/delete";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        if($responseData->message){
            return response()->json($responseData->message);
        }
        else{
            return response()->json($responseData['message']);
        } 
    }
}
