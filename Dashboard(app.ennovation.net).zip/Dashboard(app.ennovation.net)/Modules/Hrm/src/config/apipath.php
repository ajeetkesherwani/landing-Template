<?php
return [
    'leave-type' => 'https://e-nnovation.net/backend/public/api/leaveType',
    'leave-type-store' => 'https://e-nnovation.net/backend/public/api/leaveType/store',
    'leave-type-edit' => 'https://e-nnovation.net/backend/public/api/leaveType/edit',
    'leave-type-update' => 'https://e-nnovation.net/backend/public/api/leaveType/update',
    




];
