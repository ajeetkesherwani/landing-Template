<x-app-layout>
    <div class="card contact-content-body">
        <div class="tab-content">
            <div class="card-header">
                <h6 class="tx-15 mg-b-0">
                    @if(!empty($proTitle))
                        {{$proTitle->categories_name}}
                    @else
                        Product List
                    @endif
                </h6>
            </div>
            @if (session()->has('message'))
                <div class="alert alert-success">
                    {{ session('message') }}
                </div>
            @endif 
            <div class="card-body">
                <div data-label="Example" class="df-example demo-table">
                    <form action="{{route('pc-products.index')}}" method="post">
                        @csrf
                        <div class="row mt-3 mb-3" id="search">
                            <div class="col-sm-3">
                                <div class="search-form">
                                    <input type="search" name="search" id="searchbar" class="form-control" placeholder="Search Here"> 
                                    <button class="btn" id="searchBtn" type="submit"><i data-feather="search"></i></button>
                                </div>
                            </div>
                        </div>
                    </form>
                    <table class="table border table_wrapper allWebsite" id="website_listing">
                        <thead>
                            <tr>
                                <th class="border-bottom col-sm-1">
                                    {{__('common.sl_no')}}</th>
                                <th class="border-bottom col-sm-1">
                                    Product Model</th>
                                    <th class="border-bottom col-sm-2">
                                    Product Name</th>
                                <th class="border-bottom text-center col-sm-1">
                                    Sort Order</th>
                                <th class="border-bottom text-center col-sm-1">
                                    {{__('common.status')}}</th>
                                <th class="text-center border-bottom col-sm-1">
                                    {{__('common.action')}}
                                </th>
                            </tr>
                        </thead>  
                        <tbody> 
                            @forelse($PcProducts_list->data as $key=>$product)
                                <tr>    
                                    <td class="text-left ">
                                        @php
                                            $data = (int)$key +1;
                                            echo  "$data";
                                        @endphp
                                    </td>
                                    <td class="text-left "> {{$product->products_model}}</td> 
                                    <td class="text-left ">  
                                        @if (!empty($product->productdescription))
                                            {{ $product->productdescription->products_name }}
                                        @endif
                                    </td> 
                                    <td class="text-center">
                                        <input type="number" class="col-xs-1 inputPassword2 width1" data-id="{{$product->products_id}}"  placeholder="" value="{{$product->sort_order}}" style="width:50px;">
                                    </td>
                                    <th scope="col" class="text-center">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input toggle-class"  {{ $product->products_status== '1' ? 'checked' : '' }} data-id="{{$product->products_id}}"  id="customSwitch{{$product->products_id}}">
                                            <label class="custom-control-label" for="customSwitch{{$product->products_id}}"></label>
                                        </div> 
                                    </th>
                                    <td class="align-items-center justify-content-center d-flex">
                                        <a href="#" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="eye"></i><span class="d-sm-inline mg-l-5"></span></a>
                                        <a href="{{route('pc-products.edit',$product->products_id )}}" id="website_delete_btn" class="btn btn-sm btn-white d-flex align-items-center"><i data-feather="edit-2"></i><span class="d-none d-sm-inline mg-l-5"></span></a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="5">
                                        <h5 class="text-center my-2">No Data Availabel</h5>
                                    </td> 
                                </tr>
                            @endforelse 
                        </tbody>
                    </table>
                     <!-- Pagination Start-->
                        {{-- @dd($PcProducts_list); --}}
                        {{-- {!! $PcProducts_list->links() !!} --}}
                    <!--End of Pagination-->
                </div>
            </div>
        </div>
    </div>
@push('scripts')
    <script>
        $(document).ready(function() { 
            // Product status toggle button jquery
            $('.toggle-class').change(function () {
                let status = $(this).prop('checked') === true ? 1 : 0;  
                let products_id = $(this).data('id');
                console.log(products_id);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "{{url('pchangeStatus')}}",
                data: {'status': status, 'products_id': products_id},
                success: function (data) {
                    Toaster(data.success);
                    }
                });
            });

            // product sort order update
            $(".inputPassword2").on("blur",function(e){ 
                e.preventDefault();
                var products_id = $(this).data('id');
                var sort_order = $(this).val();
                console.log(products_id);
                console.log(sort_order);
                $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                $.ajax({
                    type:"POST",
                    url: "{{route('pSortOrder')}}",
                    data:{products_id:products_id,sort_order:sort_order},
                    dataType:"json",
                    success:function(data){
                        Toaster(data.success);
                    }
                }); 
            }); 
        }); 
    </script>
    @endpush
</x-app-layout>