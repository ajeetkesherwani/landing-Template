<x-app-layout>
    <div class="card contact-content-body">
        <div class="tab-content">
            <div id="website" class="tab-pane show active">
                <div class="card-header">
                    <div class="d-flex align-items-center justify-content-between ">
                        <h6 class="tx-15 mg-b-0">
                            @if(!empty($parentData))
                                {{$parentData->categories_name}}
                            @else 
                                Category List
                            @endif    
                        </h6> 
                    </div>
                </div>
                @if (session()->has('message'))
                    <div class="alert alert-success">
                        {{ session('message') }}
                    </div>
                @endif
                {{-- @if(isset($message))
                    <div class="alert alert-success" role="alert">
                        {{$message}}
                    </div>
                @endif --}}
                <div class="card-body">
                    <div data-label="Example" class="df-example demo-table">
                        <form action="{{route('pc-categories.index')}}" method="get"> 
                            <div class="form-row">  
                                <div class="form-group col-md-3">
                                    <div class="form-icon d-flex position-relative">
                                        @if(!empty($parentData))
                                            <input type="hidden" name="parentId" value="{{$parentData->categories_id}}">
                                        @endif
                                        <input type="search" name="search" id="searchbar" class="form-control" placeholder="Search Here">
                                        <button class="btn" id="searchBtn" type="submit"><i data-feather="search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </form> 
                        <table class="table border table_wrapper allWebsite" id="website_listing">
                            <thead>
                                <tr>
                                    <th class="border-bottom col-sm-1">
                                        {{__('common.sl_no')}}</th>
                                    <th class="border-bottom col-sm-1">
                                        Category Name</th>
                                    <th class="border-bottom text-center col-sm-1">
                                        Sort Order</th>
                                    <th class="border-bottom text-center col-sm-1">
                                        {{__('common.status')}}</th>
                                    <th class="border-bottom text-center col-sm-1">
                                        {{__('common.action')}}</th>
                                    </tr>
                                </tr>
                            </thead>
                            <tbody>
                                @if(!empty($PCCategory_list))
                                    @forelse ($PCCategory_list as $key=>$category)
                                        <tr> 
                                            <td class="text-left ">
                                                @php
                                                    $data = (int)$key +1;
                                                    echo "$data";
                                                @endphp
                                            </td>
                                            <td class="text-left ">   
                                                @if (!empty($category->categorydescription))
                                                    {{ $category->categorydescription->categories_name }}
                                                @endif
                                            </td>
                                            <td class="text-center">
                                                <input type="number" class="col-xs-1 inputPassword2 width1" data-categories_id="{{$category->categories_id}}"  placeholder="" value="{{$category->sort_order}}" style="width:50px;">
                                            </td>
                                            <td class="text-center"> 
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input toggle-class" data-categories_id="{{$category->categories_id}}"   {{ $category->status== '1'? 'checked' : '' }} data-id="{{$category->categories_id}}" id="customSwitch{{$category->categories_id}}">
                                                    <label class="custom-control-label" for="customSwitch{{$category->categories_id}}"></label>
                                                </div>
                                            </td>
                                            <td class="align-items-center justify-content-center d-flex">
                                                <a href="{{ route('pc-categories.show', $category->categories_id) }}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="eye"></i><span class="d-sm-inline mg-l-5"></span></a>
                                                <a href="{{route('pc-products.show',$category->categories_id)}}" id="website_delete_btn" class="btn btn-sm btn-white d-flex align-items-center"><i data-feather="repeat"></i><span class="d-none d-sm-inline mg-l-5"></span></a>
                                                <a href="{{route('pc-categories.edit',$category->categories_id)}}" id="catEditId" class="btn btn-sm btn-white d-flex align-items-center"><i data-feather="edit-2"></i><span class="d-none d-sm-inline mg-l-5"></span></a>
                                            </td>
                                        </tr> 
                                    @empty
                                        <tr>
                                            <td colspan="5">
                                                <h5 class="text-center my-2">There are no any category</h5>
                                            </td> 
                                        </tr>
                                    @endforelse
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
                <div>
                    <div class="col-12 my-3">   
                        {{-- <div class="d-md-flex align-items-center text-center justify-content-between">
                            <span class="text-muted me-3">Showing {{$current_page}} - {{$total_page}} out of {{$total_records}}</span> 
                        </div> --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
@push('scripts')

    
<script type="text/javascript">
  
  $('.toggle-class').change(function () {
      let status = $(this).prop('checked') === true ? 1 : 0;
      let categories_id = $(this).data('categories_id');
      console.log(status)
      console.log(categories_id);
      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax({
          type: "POST",
          dataType: "json",
          url: "{{ url('changeStatus') }}",
          data: { 'status': status, 'categories_id': categories_id },
          success: function (response) {
             Toaster(response.success);
          }
      });
  });
</script>

<script>
        $(document).ready(function() {

         // category sort order update
            $(".inputPassword2").on("blur",function(e){ 
                e.preventDefault();
                var categories_id = $(this).data('categories_id');
                var sort_order = $(this).val(); 
                $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                $.ajax({
                    type:"POST",
                    url: "{{route('pcCategrySortOrder')}}",
                    data:{categories_id:categories_id,sort_order:sort_order},
                    dataType:"json",
                    success:function(data){
                        Toaster(data.success);
                    }
                }); 
            }); 

        });
        
    </script>

@endpush
</x-app-layout>
