<x-app-layout>  
    @foreach($data->pcCategory->category_description as $Cdata)
    <div class="card contact-content-body"> 
        <div class="tab-content">
            <div class="card-header"> 
                    <h6 class="tx-15 mg-b-0">{{$Cdata->categories_name}}</h6>
            </div>
            <div class="card-body"> 
                <form action="{{route('pc-categories.update',$data->pcCategory->categories_id)}}" method="POST" class="needs-validation" novalidate> 
                @csrf
                {{ method_field('PUT') }}
                    <div class="form-row"> 
                        <div class="form-group col-lg-12">
                            <label class="form-label">Category Description</label>
                                <textarea cols="40" rows="40" name="categories_description" id="summernote" class="form-control" value="" required>{{$Cdata->categories_description ?? ''}}</textarea>
                            <div class="invalid-feedback">
                                Please Enter Product Description
                            </div>
                            <span class="text-danger">
                                @error('products_description')
                                    {{ $message }}
                                @enderror
                            </span>
                        </div>
                    </div>
                    <div class="card p-3 mt-1">
                        <div class="form-row">
                            <div class="form-group col-lg-12 col-sm-12">
                                <label class="form-label">Seo Title</label>
                                <input name="seometa_title" type="text" class="form-control" placeholder="Enter Seo Title" value="{{$data->seo->seometa_title ?? ''}}" required>
                                <div class="invalid-feedback">
                                    Please Enter Seo Title
                                </div>
                                <span class="text-danger">
                                    @error('seometa_title')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
                        <div class="form-row">  
                            <div class="form-group col-lg-12 col-sm-12">
                                <label class="form-label">Seo meta description</label>
                                <textarea name="seometa_description" type="text" class="form-control" value="" placeholder="Enter seo meta description" required>{{$data->seo->seometa_desc ?? ''}}</textarea>
                                <div class="invalid-feedback">
                                    Please Enter Seo meta description
                                </div>
                                <span class="text-danger">
                                    @error('products_description')
                                    {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="mt-3 d-flex ">
                        <div class="col-lg-1 p-0">
                            <input type="submit" name="send" class="btn btn-primary" value="{{ __('common.update')}}">
                        </div>
                        <div class="col-lg-1 p-0">
                            <a href="{{route('pc-categories.index')}}">
                                <input type="button" name="send" class="btn btn-light" value="{{ __('common.cancel')}}">
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    @endforeach 
@push('scripts')
    {{-- <script type="text/javascript" src="{{asset('assets/js/ckeditor.js')}}"></script> --}}
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
        
    <script>
        $(document).ready(function() {
            $('#summernote').summernote({
                placeholder: 'Enter Category Description',
                height: 150
            });
        });
        // ClassicEditor
        //     .create(document.querySelector('#editor'))
        //     //ckeditor height code
        //     .then( editor => {
        //         editor.editing.view.change( writer => {
        //             writer.setStyle( 'height', '200px', editor.editing.view.document.getRoot() );
        //         } );
        //     } )
        //     .catch(error => {
        //         console.error(error);
        //     });
    </script>
@endpush
</x-app-layout>