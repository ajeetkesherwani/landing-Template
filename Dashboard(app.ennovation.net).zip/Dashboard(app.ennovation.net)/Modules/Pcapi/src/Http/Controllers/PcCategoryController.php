<?php

namespace Modules\Pcapi\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Hash;
use Auth;
use Illuminate\Support\Str;
use App\Services\ApiService;
use App\Helper\Helper; 
use PSpell\Config;

class PcCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public static function index(Request $request)
    { 
        
            $parameters =array( 
                "parentId" => $request->parentId ?? 0,  
                "search" => $request->search ?? '',
            );
            // $apiurl = "https://e-nnovation.net/backend/public/api/pcCategory"; 
            $apiurl = config('apipath.category');
            $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
            
            return view('Pcapi::category.index',collect( $responseData->data));
    
    } 

    public function changeStatus(Request $request)
    {  
        // dd($request->all());
        $parameters =array(
            "status" => $request->status,
            "categories_id" => $request->categories_id,
          
           ); 
        $apiurl = config('apipath.category-changeStatus');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        return response()->json(['status'=>1, 'success'=>$responseData->message]);
    }

         /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */ 
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    { 
        $parameters =array(
            "id" => $id,  
        );  
        $apiurl = config('apipath.category-show'); 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
        if(isset($responseData->data)){
            return view('Pcapi::category.index',collect( $responseData->data));
        }
        else{
            return view('Pcapi::category.index')->with(['messages'=>'There are no any product']);
        }

 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $parameters =array( 
            "categories_id" => $id,
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/pcCategory/edit";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);    
        return view('Pcapi::category.edit',collect( $responseData)); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    { 
        $parameters =array( 
            "categories_id" => $id,
            "categories_description" => $request->categories_description,
            'seometa_description' => $request->seometa_description,
            'seometa_title' => $request->seometa_title,
        );  
        $apiurl = "https://e-nnovation.net/backend/public/api/pcCategory/update";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
        // dd($responseData);
        if(isset($responseData->message)){
            return redirect()->route('pc-categories.index')->with('message', $responseData->message);
        }
        else{
            return view('Pcapi::category.index')->with('error', $responseData['message']);
        } 
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }  
    public function sortOrder(Request $request)
    {
        $parameters =array(
            "categories_id" => $request->categories_id,
            "sort_order" => $request->sort_order,
        );
        $apiurl = config('apipath.category-sortorder');
        // $apiurl = "https://e-nnovation.net/backend/public/api/pcCategory/sort-order";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        return response()->json(['status'=>1, 'success'=> $responseData->message]);

    }
    
}
