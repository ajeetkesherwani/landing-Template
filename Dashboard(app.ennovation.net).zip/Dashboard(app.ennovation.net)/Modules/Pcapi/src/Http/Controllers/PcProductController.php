<?php

namespace Modules\Pcapi\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Hash;
use Auth;
use App\Helper\Helper;


class PcProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public static function index(Request $request)
    {    
        $parameters =array( 
            "search"=> $request->search ?? "",
            "page" => $request->page,
            "perPage" => "50", 
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1", 
          
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/pcProduct";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);    
        return view('Pcapi::product.index',collect( $responseData->data)); 
    }

         /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($catId)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    { 
        $parameters =array( 
            "product_id" => $id,
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/pcProduct/edit";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
        return view('Pcapi::product.edit',collect( $responseData)); 

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    { 
        try {
            $parameters =array( 
                "products_id" => $id,
                "products_description" => $request->products_description,
                'seometa_description' => $request->seometa_description,
                'seometa_title' => $request->seometa_title,
            );  
            $apiurl = "https://e-nnovation.net/backend/public/api/pcProduct/update";
            $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
            if(isset($responseData->message)){
                return redirect()->route('pc-products.index')->with('message', $responseData->message);
            }
            else{
                return redirect()->route('pc-products.index')->with('message', $responseData['message']); 
            } 
        } 
        catch (Throwable $e) {
            report($e); 
            return false;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function changeStatus(Request $request)
    {
        $parameters =array(
            "status" => $request->status,
            "products_id" => $request->products_id, 
           );
        // $apiurl = config('apipath.category-changeStatus');
        $apiurl = "https://e-nnovation.net/backend/public/api/pcProduct/change-status";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
        if(!empty($responseData->message)){
            return response()->json(['status'=>1, 'success'=>$responseData->message]);
        }
        else{
            return response()->json(['status'=>1, 'success'=>$responseData['message']]);
        }
    }
    public function sortOrder(Request $request)
    {
        $parameters =array( 
            "sort_order" => $request->sort_order,
            "products_id" => $request->products_id, 
           );
        // $apiurl = config('apipath.category-changeStatus');
        $apiurl = "https://e-nnovation.net/backend/public/api/pcProduct/sort-order";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
        if($responseData->message){
            return response()->json(['status'=>1, 'success'=>$responseData->message]);
        }
        else{
            return response()->json(['status'=>1, 'success'=>$responseData['message']]);
        }
    }
  
 

}
