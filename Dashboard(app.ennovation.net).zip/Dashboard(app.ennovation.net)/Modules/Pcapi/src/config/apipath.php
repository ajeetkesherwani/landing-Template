<?php
return [
    'category' => 'https://e-nnovation.net/backend/public/api/pcCategory',
    'category-show' => 'https://e-nnovation.net/backend/public/api/pcCategory/show',
    'category-changeStatus' => 'https://e-nnovation.net/backend/public/api/pcCategory/change-status',
    'category-sortorder' => 'https://e-nnovation.net/backend/public/api/pcCategory/sort-order',
    
    
];
