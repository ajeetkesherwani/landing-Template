<?php
namespace Modules\AddOnManager\Http\Controllers;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;


use App\Helper\Reply;
use Artisan;
use Carbon\Carbon;
use Session;
use DB;
use App\Http\Requests\FileRequest\ImportProcessRequest;

use App\Services\ApiService;
use App\Helper\Helper;



class AddOnController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index()
    {

        $parameters =array(
            "page" => '1',
            "perPage" => "2", 
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",
           );
    
            $apiurl = "https://e-nnovation.net/backend/public/api/addOn";
            $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
            return view('AddOnManager::add-on-manager.index', collect($responseData->data));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      
        $industry = AddOn::find($id);
      
        return response()->json(['industry'=>$industry]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function changeStatus(Request $request)
    {

        $parameters =array(
            "id" => $request->id,
            "status" => $request->status,
        );
    
        $apiurl = "https://e-nnovation.net/backend/public/api/addOn/change-status";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
        dd( $responseData);
        return response()->json(['status'=>1, 'success'=> $responseData->message]);

    }




}
