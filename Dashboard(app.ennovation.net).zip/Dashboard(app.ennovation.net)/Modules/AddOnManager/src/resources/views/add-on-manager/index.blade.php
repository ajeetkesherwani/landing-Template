<style>
.pull-left button{
    float:right;
    margin: 1rem 0 0.6rem;
}
.btns{
    margin:0 10px!important;
}

.table_btn{
    margin:0 4px;
    }
</style>
<x-app-layout>
    <div class="card contact-content-body">
        <div class="tab-content">
            <div class="card-header d-flex align-items-center justify-content-between py-2 px-3">
                <h6 class="tx-15 mg-b-0">Add On Manager</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table border table_wrapper rounded px-3">
                        <thead>
                            <tr>
                                <th class="border-bottom ">#</th>
                                <th class="border-bottom " style="min-width: 220px;">Image</th>
                                <th class="border-bottom " style="min-width: 220px;">Add On Name</th>                                  
                                <th class=" border-bottom ">Version</th>
                                <th class="border-bottom ">Status</th>
                                <th class="border-bottom "">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(!empty($add_on))
                                @foreach($add_on as $key => $data)
                                    <tr>
                                        <td class="">{{$key+1}}</td>
                                        <td class="">{{$data->image}}</td>
                                        <td class="">{{$data->addon_name}}</td>
                                        <td class="">{{@$data->version}}</td> 
                                        <td class="">
                                            <div class="form-check form-switch">
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input toggle-class"   {{ $data->status ? 'checked' : '' }} data-id="{{$data->id}}" id="customSwitch{{$data->id}}">
                                                    <label class="custom-control-label" for="customSwitch{{$data->id}}"></label>
                                                </div> 
                                            </div>
                                        </td>
                                        <td class="align-items-center justify-content-center d-flex"> 

                                            <a href="#papachina_edit" data-id="{{ $data->industry_id }}" data-toggle="modal" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="eye"></i><span class="d-none d-sm-inline mg-l-5"></span></a> 
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div> 
    <!-- Edit modal start here -->
    <div class="modal fade" id="papachina_edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content tx-14">
            <form id="papachina_update_userForm" method="POST" class="needs-validation" novalidate>
                @csrf
                <div class="modal-header">
                    <h6 class="modal-title" id="exampleModalLabel">PapaChina Api Setting</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input name="industry_id" id="hidden_industry_id" type="hidden" class="form-control ps-5">
                                            
                    <div class=" row">
                        <label  class="col-sm-4 col-form-label">Profit Percent</label>
                        <div class=" form-icon col-sm-8">
                            <input type="text" readonly class="form-control" id="staticEmail" value="email@example.com">
                        </div>
                    </div>
                    <div class="row pt-2">
                        <label  class="col-sm-4 col-form-label">Enable Shipping</label>
                        <div class=" form-icon col-sm-8">
                            <input type="radio" id="contactChoice1" name="contact" value="email">
                            <label for="Choice1">Yes</label>
                            <input type="radio" id="contactChoice2" name="contact" value="phone">
                            <label for="Choice2">No</label>
                        </div>
                    </div>
                    <div class=" row">
                        <label  class="col-sm-4 col-form-label">Shipping Option </label>
                        <div class=" form-icon col-sm-8">
                            <select class="form-select form-control" name="access_privilege" id="update_access_privilege" required="">
                                <option value="0">Ex</option>
                                <option value="1">Ec</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-sm-12">
                            <button type="submit" id="papachina_update_btn" class="btn btn-primary tx-13">Submit</button>
                        </div>
                    </div>
                    {{-- <div class="row">
                        <div class="col-sm-12" required>
                            <input type="submit" id="papachina_update_btn" name="send" class="btn-primary"">
                        </div><!--end col-->
                    </div>     --}}
                    <!--end row-->
                </div>
                
            </form>
            </div>
        </div>
    </div>
    <!-- Edit modal end here --> 
@push('scripts') 
    <script type="text/javascript"> 
        $('.toggle-class').change(function () {
            let status = $(this).prop('checked') === true ? 1 : 0; 
            let id = $(this).data('id');  
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "{{ url('changeStatus') }}", 
                data: { 'status': status, 'id': id },
                success: function (response) {
                   console.log(response);
                   Toaster(response.success);
                }
            });
        });
        // modal edit open ajax 
        $(document).on("click", "#papachina_editmodal", function(e) {
            e.preventDefault();
            var addon_id = $(this).data('id');
            $('#papachina_edit').modal('show');
            $.ajax({
                url: "add-on-manager/" + addon_id + "/edit",
                type: "GET",
                success: function(response) {
                    console.log(response);
                    if (response.status == 400) {
                        $('#errorlist').html("");
                        $('#errorlist').addClass("alert alert-danger");
                        $('#errorlist').append('<li>' + response.message + '</li>');

                    } else {
                        $('#edit_industry_name').val(response.industry.industry_name);
                        $('#hidden_industry_id').val(addon_id);
                    }
                }
            }); 
        });
        // modal edit closed ajax
    </script>  
@endpush 
</x-app-layout> 
