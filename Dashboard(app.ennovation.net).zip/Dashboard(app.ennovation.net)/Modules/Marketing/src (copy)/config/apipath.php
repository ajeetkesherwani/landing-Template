<?php
return [
    'category' => 'https://e-nnovation.net/backend/public/api/pcCategory',
    'category-show' => 'https://e-nnovation.net/backend/public/api/pcCategory/show',
    'category-changeStatus' => 'https://e-nnovation.net/backend/public/api/pcCategory/ChangeStatus',
    'category-sortOrder' => 'https://e-nnovation.net/backend/public/api/pcCategory/sortOrder',
];
