<x-app-layout>
    {{-- @dd($data_list); --}}
    <div class="card groupData-content-body">
        <div class="card-header">
            <div class="d-flex align-items-center justify-content-between">
                <h6 class="tx-15 mg-b-0">{{ __('newsletter.contact_group') }}</h6>


                <div class="d-flex gap-1">

                    <a href="#add_groupData_modal" data-toggle="modal" class="btn btn-sm btn-bg"><i
                            data-feather="plus"></i>{{ __('newsletter.add_group') }}</a>
                    </a>
                    <a href="{{ route('contact-import') }}" class="btn btn-sm btn-bg d-flex align-items-center mg-r-5"><i
                            data-feather="plus"></i><span
                            class="d-none d-sm-inline mg-l-5">{{ __('newsletter.import') }}</span></a> 
                </div> 
            </div>
        </div>
        @if(Session::has('message'))
            <div class="alert alert-danger">
                {{ Session::get('message') }}
            </div>
        @endif
        <div class="card-body">
            <div class="form-row">
                <div class="form-group col-2 col-lg-1 col-sm-3">
                    <select class="form-control">
                        <option>10</option>
                        <option>20</option>
                        <option>30</option>
                        <option>40</option>
                        <option>50</option>
                    </select>
                </div>
                <div class="form-group mg-l-5">
                    <input type="text" class="form-control" id="Search"
                        placeholder="{{ __('newsletter.search_placeholder') }}">
                </div>
            </div>
            <div class="table-responsive">
                @if (!empty($data_list))
                    <table class="table border table_wrapper">
                        <thead>
                            <tr>
                                <th>{{ __('common.sl_no') }}</th>
                                <th>{{ __('newsletter.group_name') }}</th>
                                {{-- <th>{{ __('newsletter.No_of_groupData') }}</th> --}}
                                <th>{{ __('common.status') }}</th>
                                <th class="text-center wd-10p">{{ __('common.action') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if (!empty($data_list))
                                @foreach ($data_list as $key => $groupData)
                                    <tr>
                                        <td>{{ $key + 1 }}</td>
                                        <td>{{ $groupData->group_name }}</td>
                                        {{-- <td>{{ count($groupDatagroupcount->where('group_id',$groupData->id)) }}</td> --}}
                                        <td>
                                            <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input toggle-class"
                                                    {{ $groupData->status == '1' ? 'checked' : '' }}
                                                    data-id="{{ $groupData->id }}"
                                                    id="customSwitch{{ $groupData->id }}">
                                                <label class="custom-control-label"
                                                    for="customSwitch{{ $groupData->id }}"></label>
                                            </div>
                                        </td>
                                        {{-- @if (count($groupDatagroupcount->where('group_id', $groupData->id)) == 0)
                                <td class="d-flex align-items-center">
                                    <a href="{{ route('groupData-list',$groupData->id) }}" value="{{ $groupData->id }}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="eye"></i></a>

                                    <button type="button" value="{{ $groupData->id }}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"
                                    value="1" id="edit_btn" data-toggle="modal" data-target="#edit_groupData_modal">
                                    <i data-feather="edit-2"></i></button>

                                    
                                    <button type="button" id="delete_btn" value="{{ $groupData->id }}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="trash"></i></button>
                                </td>
                            @else --}}
                                        <td class="d-flex align-items-center">
                                            <a href="{{ route('contact-list', $groupData->id) }}" value="{{ $groupData->id }}"
                                                class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="eye"></i></a>

                                            <button type="button" value="{{ $groupData->id }}"
                                                class="btn btn-sm btn-white d-flex align-items-center mg-r-5"
                                                value="1" id="edit_btn" data-toggle="modal"
                                                data-target="#edit_groupData_modal">
                                                <i data-feather="edit-2"></i></button>
                                        </td>
                                        {{-- @endif --}}
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                @endif
            </div>
        </div>
    </div>

    <!--start add modal-->
    <div class="modal fade" id="add_groupData_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                    <h6 class="modal-title" id="exampleModalLabel">{{ __('newsletter.add_contact') }}</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" id="add_form" class="needs-validation" novalidate>
                        @csrf
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label class="form-label">{{ __('newsletter.group_name') }}
                                    <span class="text-danger">*</span>
                                </label>
                                <input name="group_name" id="group_name" type="text" class="form-control"
                                    placeholder="{{ __('newsletter.group_name_placeholder') }}" required>
                                <div class="invalid-feedback">
                                    {{ __('newsletter.group_name_error') }}
                                </div>
                                <span style="color:red;">
                                    @error('group_name')
                                        {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label class="form-label">{{ __('newsletter.details') }}</label>
                                <input name="details" id="details" type="text" class="form-control"
                                    placeholder="{{ __('newsletter.details_placeholder') }}">
                                <div class="invalid-feedback">
                                    {{ __('newsletter.details_error') }}
                                </div>
                                <span style="color:red;">
                                    @error('details')
                                        {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
                        <!--end row-->
                        <input type="submit" name="send" class="btn btn-primary groupData_submit" value="Submit">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--end add modal-->

    <!--start edit modal-->
    <div class="modal fade" id="edit_groupData_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                    <h6 class="modal-title" id="exampleModalLabel">{{ __('newsletter.update_contact') }}</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation" id="groupEdit_form" novalidate>
                        <input name="input_field" id="input_field" type="hidden">
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label class="form-label">{{ __('newsletter.group_name') }}
                                    <span class="text-danger">*</span></label>
                                <input name="group_name" id="update_group_name" type="text" class="form-control"
                                    placeholder="{{ __('newsletter.group_name_placeholder') }}" required>
                                <div class="invalid-feedback">
                                    {{ __('newsletter.group_name_error') }}
                                </div>
                                <span style="color:red;">
                                    @error('group_name')
                                        {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label class="form-label">{{ __('newsletter.details') }}</label>
                                <input name="details" id="update_details" type="text" class="form-control"
                                    placeholder="{{ __('newsletter.details_placeholder') }}">
                                <div class="invalid-feedback">
                                    {{ __('newsletter.details_error') }}
                                </div>
                                <span style="color:red;">
                                    @error('details')
                                        {{ $message }}
                                    @enderror
                                </span>
                            </div>
                        </div>
                        <input type="submit" name="send" id="groupUpBtn" class="btn btn-primary "
                            value="Update">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--end edit modal-->




    @push('scripts')
        <script>
            $(document).ready(function() {
                //search group data in group lsting ajax start here
                $("#Search").on("keyup", function() {
                    var value = $(this).val().toLowerCase();
                    $("#Search_Tr tr").filter(function() {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });

                // add group data ajax start here
                $(document).on('click', ".groupData_submit", function(e) {
                    e.preventDefault();
                    $('#add_form').addClass('was-validated');
                    if ($('#add_form')[0].checkValidity() === false) {
                        event.stopPropagation();
                    } else {
                        var data = {
                            group_name: $("#group_name").val(),
                            details: $("#details").val(),
                        };

                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "{{ route('contact-group-list.store') }}",
                            data: data,
                            dataType: "json",

                            success: function(response) {
                                console.log(response);
                                Toaster(response.success);
                                setTimeout(function() {
                                    location.reload(true);
                                }, 1000);
                            }
                        });
                    }
                });

                //group status change ajax start here
                $('.toggle-class').change(function() {
                    let status = $(this).prop('checked') === true ? 1 : 0;
                    let group_id = $(this).data('id');

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        dataType: "json",
                        url: "{{ route('changeContactGroupStatus') }}",
                        data: {
                            'status': status,
                            'group_id': group_id
                        },
                        success: function(data) {
                            console.log(data.success);
                            Toaster(data.success);
                        }
                    });
                });

                //edit group data ajax start here
                $(document).on("click", "#edit_btn", function(e) {
                    e.preventDefault();
                    var group_id = $(this).val();
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: "{{ url('contact-edit') }}",
                        type: "POST",
                        data: {
                            'group_id': group_id
                        },
                        success: function(response) {
                            console.log(response['1']);
                            $('#update_group_name').val(response['1'].group_name);
                            $('#update_details').val(response['1'].description);
                            $('#input_field').val(response['1'].id);
                        }
                    });
                });

                //update group data ajax start here
                $(document).on("click", "#groupUpBtn", function(e) {
                    e.preventDefault();
                    $('#groupEdit_form').addClass('was-validated');
                    if ($('#groupEdit_form')[0].checkValidity() === false) {
                        event.stopPropagation();
                    } else {
                        var data = {
                            group_name: $("#update_group_name").val(),
                            details: $("#update_details").val(),
                            group_id: $('#input_field').val(),
                        }
                        console.log(data);
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });

                        $.ajax({
                            type: "POST",
                            url: "{{ route('contactGroupUpdate') }}",
                            data: data,
                            dataType: "json",
                            success: function(response) {
                                Toaster(response.success);
                                setTimeout(function() {
                                    location.reload();
                                }, 1000);
                            }
                        });
                    }
                });
            });
        </script>

        <script>
            // update ajax start
            // update ajax end
        </script>

        <script type="text/javascript">
            //  toggle ajax start
            // $('.toggle-class').change(function() {
            //     let status = $(this).prop('checked') === true ? 1 : 0;
            //     let group_id = $(this).data('id');

            //     $.ajaxSetup({
            //         headers: {
            //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            //         }
            //     });
            //     $.ajax({
            //         type: "POST",
            //         dataType: "json",
            //         url: "{{ route('changeContactGroupStatus') }}",
            //         data: {
            //             'status': status,
            //             'group_id': group_id
            //         },
            //         success: function(data) {
            //             Toaster('Contact Group Status Changed Successfully')
            //         }
            //     });
            // });
            //  toggle ajax end
        </script>

        <!-- start delete ajax-->
        <script>
            $(document).ready(function() {

                $(document).on("click", "#delete_btn", function() {
                    var group_id = $(this).val();
                    $('#delete_groupData_id').val(group_id);
                    $('#delete_groupData_modal').modal('show');
                });
                $(document).on('click', '.groupData_delete', function() {
                    var group_id = $('#delete_groupData_id').val();

                    $('#delete_groupData_modal').modal('hide');

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "{{ url('deleteContactGroup') }}/" + group_id,
                        data: {
                            group_id: group_id,

                        },
                        dataType: "json",
                        success: function(response) {
                            Toaster(response.success);
                            setTimeout(function() {
                                location.reload();
                            }, 1000);
                        }
                    });
                });
            });
        </script>
    @endpush
</x-app-layout>
