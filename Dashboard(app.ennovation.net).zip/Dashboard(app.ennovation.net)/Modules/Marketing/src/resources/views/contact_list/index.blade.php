
<x-app-layout> 
    <div class="card contact-content-body">
        <div class="card-header">
            <div class="d-flex align-items-center justify-content-between">

                @if(!empty($group_name))
                    <h6 class="tx-15 mg-b-0">{{$group_name}}</h6>
                @else
                    <h6 class="tx-15 mg-b-0">Group name</h6>
                @endif
                <div class="d-flex">
                <a href="{{route('contact-create')}}" class="btn btn-sm btn-bg"><i data-feather="plus" class="mg-r-5"></i>{{__('newsletter.add_contact')}}</a>
                <a href="{{route('importcreate')}}" class="btn btn-sm btn-bg mg-l-5">Import</a>
                </div>
            </div>
        </div>
        @if(Session::has('message'))
            <div class="alert alert-danger">
                {{ Session::get('message') }}
            </div>
        @endif
        <div class="card-body">
            <div class="table-responsive"> 
                @if(!empty($data_list))
                    <table class="table border table_wrapper">
                        <thead>
                            <tr>
                                <th>{{ __('common.sl_no') }}</th>
                                <th>{{__('newsletter.contact_name')}}</th>
                                <th>{{__('newsletter.contact_email')}}</th>
                                {{-- <th>{{ __('common.status') }}</th> --}}
                                <th class="text-center wd-10p">{{ __('common.action') }}</th>
                            </tr>
                        </thead>  
                        @if(!empty($data_list))
                            <tbody>    
                                @forelse($data_list as $key=>$contact)
                                    <tr>       
                                        <td>{{ $key + 1 }}</td>
                                        <td>{{$contact->contact_details->contact_name ?? ''}}</td>
                                        <td>{{$contact->contact_details->contact_email ?? ''}}</td>
                                        <td class="d-flex align-items-center">
                                            <a href="{{route('contact-edit',$contact->contact_id)}}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5" id=""><i data-feather="edit-2"></i>
                                            </a>
                                            <button class="btn btn-sm btn-white d-flex align-items-center mg-r-5" id="delete_btn" data-target="#delete_modal" data-toggle="modal" value="{{$contact->contact_id}}"><i data-feather="trash"></i></button>
                                        </td>
                                        
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5">
                                            <h5 class="text-center my-2">No Record Found!</h5>
                                        </td> 
                                    </tr>
                                @endforelse
                            </tbody>
                        @endif
                    </table>
                @endif
            </div>
        </div>
    </div>
    <!--start delete modal-->
    <div class="modal fade" id="delete_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel5" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                    <h6 class="modal-title" id="exampleModalLabel5">{{ __('newsletter.contact_group') }}</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>{{ __('common.delete_confirmation') }}</h6>
                    <input type="hidden" id="deleteContactId" name="input_field_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    {{ __('common.no')}}
                    </button>
                    <button type="submit" class="btn btn-primary contactDelBtn">{{ __('common.yes') }}</button>
                </div>
            </div>
        </div>
    </div>
    <!--end delete modal--> 

    @push('scripts') 
    <script>
        //delete contact id transfer in delete modal ajax start here
        $(document).on("click", "#delete_btn", function() {
            var contact_id = $(this).val(); 
            $('#deleteContactId').val(contact_id); 
        });

        //delete modal confirmation data start here
        $(document).on('click','.contactDelBtn', function() { 
            var contact_id = $('#deleteContactId').val(); 
            console.log(contact_id);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            }); 
            $.ajax({
                type: "POST",
                url : "{{route('contact-list-delete')}}",
                data: {
                    contact_id: contact_id,
                },
                dataType: "json", 
                success: function(response) { 
                    Toaster(response.success);
                    setTimeout(function() {
                        location.reload(true);
                    },1000); 
                }
            });
        });


        $(document).on("click", "#clicktomove", function(e) {
            e.preventDefault();
                var group_id = $("#edit_template").val();
                if ($(".group_check").is(':checked')) {
                var contact_id = [];
                    $('input[name="checkname[]"]').each(function () {
                        if(this.checked) contact_id.push($(this).val())
                    });  
                }
                else{
                    toastr.error("Please Select Checkbox.");
                } 

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            }); 
            $.ajax({
                url:url,
                type: "GET",
                data: {
                    group_id: group_id,
                    contact_id : contact_id,
                },
                dataType: "json",
                success: function(result) {
                    console.log(result);
                    if(result.success){
                        Toaster(result.success);
                        setTimeout(function() {
                        location.reload(true);
                    }, 3000);
                    }else{
                        toastr.error(result.error);
                        setTimeout(function() {
                        location.reload(true);
                    }, 3000);
                    } 
                } 
            });
        });
        $(document).ready(function() {
            $("#Search").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#Search_Tr tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });

        //  toggle ajax start
        $('.toggle-class').change(function() {
            let blocked = $(this).prop('checked') === true ? 1 : 0;
            let id = $(this).data('id');

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                dataType: "json",
             
                data: {
                    'blocked': blocked,
                    'id': id
                },
                success: function(data) {
                    Toaster(data.success);
                }
            });
        }); 

        function toggle(source) {
            var checkboxes = document.querySelectorAll('.checkbox');
            for (var i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i] != source)
                    checkboxes[i].checked = source.checked;
            }
        }
    </script>
    @endpush
</x-app-layout> 