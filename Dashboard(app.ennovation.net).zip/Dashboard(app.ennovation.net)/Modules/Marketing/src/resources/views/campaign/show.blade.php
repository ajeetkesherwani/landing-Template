<x-app-layout>
    {{-- @dd($data) --}}
    <div class="container-fluid">
        <div class="layout-specing">
            <div class="row">
                <div class="col-md-12 col-lg-12 my-0">
                    <div class="card pb-1">
                        <div class=" border-0 quotation_form">
                            <div class="card-header py-3 bg-transparent d-flex align-items-center justify-content-between">
                                <h5 class="tx-uppercase tx-semibold mg-b-0">{{ __('campaign.campaign_details') }}</h5>
                                <div>
                                    <a href="{{ route('campaign.create') }}"><button class="btn btn-md btn-primary" id="add_modal"><i data-feather="plus" class="lead_icon mg-r-5"></i>{{ __('campaign.add_campaign') }}</button></a>
                                </div>
                            </div>
                        </div>
                        <div class="p-4 mt-1">
                            <div class="table-responsive" id="department">
                                <table class="table table-center bg-white mb-0">
                                    <thead>
                                        <tr>
                                            <th class="border-bottom p-3">{{ __('campaign.campaign_name') }}</th>
                                            <th class="border-bottom p-3">{{ __('campaign.source_name') }}</th>
                                            {{-- <th class="border-bottom p-3">{{ __('campaign.groups') }}</th> --}}
                                            <th class="border-bottom p-3">{{ __('campaign.subject') }}</th>
                                            <th class="border-bottom p-3">{{ __('campaign.sender_name') }}</th>
                                            <th class="text-center border-bottom p-3">{{ __('common.action') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Start -->
                                        <tr>
                                            <td class="p-3">{{$data->campaign_name}}</td>
                                            <td class="p-3">{{$data->source_ids}}</td>
                                            {{-- <td class="p-3">{{$data->group_ids}}</td> --}}
                                            <td class="p-3">{{$data->campaign_subject}}</td>
                                            <td class="p-3">{{$data->sender_name}}</td>
                                            <td class="p-3 d-flex align-items-center justify-content-between">
                                            <a href="{{ url('campaign-edit/'.$data->campaign_id) }}" id="editmodal"
                                                    class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i
                                                    data-feather="edit-2"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <!-- End -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card  mt-2">

                        <div class=" border-0 quotation_form">
                            <div class="card-header  bg-transparent d-flex align-items-center justify-content-between">
                                <h5 class="tx-uppercase tx-semibold mg-b-0">{{ __('campaign.customer_list') }}</h5>
                                <div class="form-row">  
                                    <div class="form-group">
                                        <div class="form-icon d-flex ">
                                            <input type="search" name="search" id="searchbar" class="form-control" placeholder="Search Here.....">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="p-4 mt-1">
                            <div class="table-responsive" id="department">
                                <table class="table table-center bg-white mb-0">
                                    <thead>
                                        <tr>
                                            <th class="border-bottom p-3">{{ __('common.sl_no') }}</th>
                                            <th class="border-bottom p-3">{{ __('campaign.cutsomer_name') }}</th>
                                            <th class="border-bottom p-3">{{ __('campaign.customer_email') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody id="myTable">
                                        <!-- Start -->
                                        @if(!empty($data->customer_data))
                                        @foreach($data->customer_data as $key=>$customer)
                                        <tr>
                                            <td class="p-3">{{$key+1}}</td>
                                            <td class="p-3">{{$customer->name ?? ''}}</td>
                                            <td class="p-3">{{$customer->email ?? ''}}</td>
                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody><!-- End -->
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--end row-->
        </div>
    </div>

    @push('scripts')
        <script>
            $(document).ready(function(){
            $("#searchbar").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
           });
        </script>
    @endpush
</x-app-layout>