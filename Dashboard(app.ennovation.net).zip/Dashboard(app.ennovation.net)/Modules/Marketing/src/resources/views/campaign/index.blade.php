<x-app-layout>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
    {{-- <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" /> --}}

    {{-- <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script> --}}
    <div class="card">
        <div class="tab-content">
            <div class="card-header">
                <div class="d-flex align-items-center justify-content-between ">
                    <h6 class="tx-15 mg-b-0">{{ __('campaign.campaign_list') }}</h6>
                    <a href="{{ route('campaign.create') }}" class="btn btn-sm btn-bg d-flex align-items-center mg-r-5"><i
                            data-feather="plus"></i><span
                            class="d-none d-sm-inline mg-l-5">{{ __('campaign.add_campaign') }}</span></a>
                </div>
            </div>
            <div class="card-body ">
                <div class="table-responsive" id="department">
                    @if (!empty($data))
                        <table class="table border table_wrapper" id="table">
                            <thead>
                                <tr>
                                    <th class="">{{ __('common.sl_no') }}</th>
                                    <th class="" style="min-width: 150px;">{{ __('campaign.campaign_name') }}</th>
                                    <th class="" style="min-width: 150px;">{{ __('campaign.campaign_subject') }} </th>
                                    <th class="text-center">{{ __('common.status') }}</th>
                                    <th class="text-center">{{ __('common.action') }}</th>

                                </tr>
                            </thead>
                            <tbody>
                                <!-- Start -->
                                @if (!empty($data))
                                    @foreach ($data as $key => $campaign)
                                        <tr>
                                            <td>{{ $key + 1 }}</td>
                                            <td>{{ $campaign->campaign_name }}</td>
                                            <td>{{ $campaign->campaign_subject }}</td>
                                           
                                            <td>
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input toggle-class"
                                                        {{ $campaign->status ? 'checked' : '' }}
                                                        data-id="{{ $campaign->id }}"
                                                        id="customSwitch{{ $campaign->id }}">
                                                    <label class="custom-control-label"
                                                        for="customSwitch{{ $campaign->id }}"></label>
                                                </div>
                                            </td>
                                            <td class="d-flex align-items-center float-right">
                                                <a href="{{url('campaign-view/'.$campaign->id )}}"
                                                    class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="eye"></i></a>

                                                <a href="{{ url('campaign-edit/'.$campaign->id) }}" id="editmodal"
                                                    value="{{ $campaign->id }}"
                                                    class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i
                                                        data-feather="edit-2"></i>
                                                </a>

                                                {{-- <a href="javascript:void(0)" id="delete_btn" value="{{ $campaign->id }}" data-toggle="modal"
                                                    class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i
                                                        data-feather="trash"></i></a> --}}
                                            </td>
                                        </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    @else
                        <div class="table-responsive">
                            <table class="table border table_wrapper">
                                <thead>
                                    <tr>
                                        <th>{{ __('common.sl_no') }}</th>
                                        <th>{{ __('campaign.campaign_name') }}</th>
                                        <th>{{ __('campaign.campaign_subject') }}</th>
                                        <th>{{ __('campaign.campaign_group') }}</th>
                                        <th>{{ __('common.status') }}</th>
                                        <th class="text-center wd-10p">{{ __('common.action') }}</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td colspan="6">
                                            <h4 class="text-center">No Record Found !.</h4>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    @endif
                </div>
            </div>
        </div>
    </div>
    <!--end container-->

  
    <!--start delete modal-->
    <div class="modal fade effect-scale" id="delete_modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title">{{ __('campaign.delete_campaign') }}</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" value='' id="delete_designation_id" name="input_field_id">
                    <p class="mg-b-0">{{ __('user-manager.are_you_sure') }}</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        {{ __('common.no') }}
                    </button>
                    <button type="submit" class="btn btn-primary delete_submit_btn">{{ __('common.yes') }}</button>
                </div>
            </div>
        </div>
    </div>
    <!--end delete modal-->



    @push('scripts')
        <script>
            $(document).ready(function() {

                // Delete Ajax Start

                $(document).on("click", "#delete_btn", function() {
                    var campaign_id = $(this).attr('value');
                    $('#delete_designation_id').val(campaign_id);
                    $('#delete_modal').modal('show');
                });
                $(document).on('click', '.delete_submit_btn', function() {
                    var campaign_id = $('#delete_designation_id').val();

                    $('#delete_modal').modal('hide');

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "{{ url('campaign-delete') }}",
                        data: {
                            campaign_id: campaign_id
                        },
                        dataType: "json",
                        success: function(response) {
                            Toaster(response.success);
                            location.reload();
                        }
                    });

                });
                //End of delete ajax

            

                //  Change Status Start
                $('.toggle-class').change(function() {
                    let status = $(this).prop('checked') === true ? 1 : 0;
                    let campaign_id = $(this).data('id');

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        dataType: "json",
                        url: "{{ route('campaign-status') }}",
                        data: {
                            'status': status,
                            'campaign_id': campaign_id
                        },
                        success: function(response) {
                            Toaster(response.success);
                        }
                    });
                });
                //Change Status End
            });
        </script>
    @endpush
</x-app-layout>
