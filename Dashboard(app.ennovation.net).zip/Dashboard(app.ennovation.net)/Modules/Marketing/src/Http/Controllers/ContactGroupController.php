<?php

namespace Modules\Marketing\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Helper\Helper;



class ContactGroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

         
        $parameters =array( 
            "perPage" => "",
            "search" => "",
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/contact-group"; 
        
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        return view('Marketing::contact.index', collect($responseData->data));  
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $parameters =array( 
            "group_name" => $request->group_name,
            "description" => $request->details, 
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/contact-group/store"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
        if($responseData->message){
            return response()->json(['success'=> $responseData->message]); 
        }
        else{
            return back()->json(['error'=> $responseData['message']]); 
        } 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
    }

    public function contactGroupUpdate(Request $request)
    { 
        $parameters =array( 
            "group_id" => $request->group_id,
            "group_name" => $request->group_name,
            "description" => $request->details, 
        );  
        $apiurl = "https://e-nnovation.net/backend/public/api/contact-group/update"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        if(isset($responseData->message)){
            return response()->json(['success'=>$responseData->message]);
        }
        else{
            return response()->json(['success'=>$responseData['message']]);
        } 
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       
    }

    public function changeContactGroupStatus(Request $request)
    {
        $parameters =array( 
            "status" => $request->status,
            "group_id" => $request->group_id, 
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/contact-group/change-status"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        if($responseData->message){
            return response()->json(['success'=>$responseData->message]);
        }
        else{
            return response()->json(['success'=>$responseData['message']]);
        } 
    }
    public function EditContact(Request $request)
    {
        $parameters =array( 
            "group_id" => $request->group_id, 
        ); 
        $apiurl = "https://e-nnovation.net/backend/public/api/contact-group/edit"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        // dd($responseData);
        if(isset($responseData->message)){
            return response()->json(['message',$responseData->data]);
        }
        else{
            return response()->json(['message', $responseData['message']]);
        }
    }
    public function GetContact(Request $request)
    { 
         
        $parameters =array( 
            "contact_name" => $request->contact_name,
            "contact_email" => $request->contact_email,
            "company" => $request->company,
            "website" => $request->website,
            "countried_id" => $request->country,
            "phone" => $request->phone,
            "address" => $request->address,
            "id" => $request->contact_group, 
        );  
         
        $apiurl = "https://e-nnovation.net/backend/public/api/contact/store"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        if(!empty($responseData->message)){
            return redirect()->route('contact-list',$responseData->data->contact_group->group_id)->with('message',$responseData->message);  
        }
        else{
            return redirect()->route('contact-list',$responseData->data->contact_group->group_id)->with('message',$responseData['message']);
            // return response()->json(['success',$responseData['message']]);
        } 
    }
    public function ContactCreate(Request $request)
    { 
        $parameters =array( 
            
        );  
        $apiurl = "https://e-nnovation.net/backend/public/api/contact/create"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
         
        if(isset($responseData->data)){
            return view('Marketing::contact_list.create',collect($responseData->data)); 
        }
        else{
            return view('Marketing::contact_list.index',$responseData['message']); 
        } 
    }

    public function contactImport(Request  $request)
    { 
        $apiurl = "https://e-nnovation.net/backend/public/api/contact-group/contact-import";  
            
        $responseData = Helper::ApiServiceResponse($apiurl, []);  

        return view('Marketing::contact.import.import ', collect($responseData->data));
    }


    public function contactImportProcess(Request  $request)
    { 
        $request->validate([
            'contact_group' => 'required',
            'import_file' => 'required'
        ]); 

       if($_FILES['import_file']['name']) {

        $file = $request->import_file;
        $file_ext=$file->getClientOriginalExtension();
        $file_name= 'contact_group-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$file_ext;
  
        $file->move(public_path('uploads'), $file_name);

        $arr_file = asset('uploads/'.$file_name);

       } else{
        $arr_file = '';
       }

        if($arr_file != ''){

            $parameters =array( 
                "contact_group" => $request->contact_group,
                "import_file_path" => $arr_file,
            );

           $apiurl = "https://e-nnovation.net/backend/public/api/contact-group/contact-import-process"; 
            $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 

            
            return redirect()->route('contact-group-list.index' , ['group_name='.$request->contact_group])->with('success', $responseData->message); 

         } else{
            return redirect()->route('contact-group-list.index')->with('error', $responseData->message);
         }

    }
    public function GroupContactEdit(Request $request,$id)
    {   
         
        $parameters =array( 
            "id" => $request->id,
        ); 
         
        $apiurl = "https://e-nnovation.net/backend/public/api/contact/edit"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
         
        if(isset($responseData->data)){
            return view('Marketing::contact_list.edit',collect($responseData->data));  
        }
        else{
            return view('Marketing::contact_list.edit',collect($responseData['message']));  
        } 
    }
    public function DeleteContact(Request $id)
    {
        // dd($id);
        $parameters =array( 
            "contact_id" => $id,
        ); 
        // dd($parameters);
        $apiurl = "https://e-nnovation.net/backend/public/api/contact/delete"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        dd($responseData);
        if(isset($responseData->data)){
            return response()->json(['success',$responseData->data]);
        }
        else{
            return response()->json(['success',$responseData['message']]);
        } 
    }
    public function ContacView(Request $request,$id)
    {
         
        $parameters =array( 
            "id" => $id,
        );  
         
        $apiurl = "https://e-nnovation.net/backend/public/api/contact"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
         
        if(!empty($responseData)){
            return view('Marketing::contact_list.index',collect($responseData->data));
        }
        else{
            return view('Marketing::contact_list.index',collect($responseData->message));
        }
    }
    public function GroupContactUpdate(Request $request)
    { 
        $parameters =array( 
            "contact_name" => $request->contact_name,
            "contact_email" => $request->contact_email,
            "company" => $request->company,
            "website" => $request->website,
            "countried_id" => $request->country,
            "phone" => $request->phone,
            "address" => $request->address, 
            "group_id"  => $request->contact_group,
            "id" => $request->contact_id,
        );  
         
        $apiurl = "https://e-nnovation.net/backend/public/api/contact/update"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
        
        if(!empty($responseData->message)){
            return redirect()->route('contact-group-list.index')->with('message',$responseData->message); 
        }
        else{
            return redirect()->route('contact-group-list.index')->with('message',$responseData['message']); 
        }
    }
    
}

 
 