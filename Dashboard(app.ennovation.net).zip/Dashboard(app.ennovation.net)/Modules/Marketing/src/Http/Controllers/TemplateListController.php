<?php

namespace Modules\Marketing\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect;
use App\Helper\Helper;

class TemplateListController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $parameters =array( 
            "perPage" => "",
            "search" => "",
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",
        );
        $apiurl = config('apipath.marketing-template');
        // $apiurl = "https://e-nnovation.net/backend/public/api/marketing-template"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        return view('Marketing::templatelist.index', collect($responseData->data)); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {  
        return view('Marketing::templatelist.create');
    }

    public function proEditor()
    {
        return view('Marketing::templatelist.pro_editor');
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $parameters =array( 
            "subject" => $request->subject,
        );
        $apiurl = config('apipath.marketing-template-store');
        // $apiurl = "https://e-nnovation.net/backend/public/api/marketing-template/store"; 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
        
        if($request->editor="pro")
        return view('Marketing::templatelist.pro_editor',['data'=>$responseData->data]);
        else
        return view('Marketing::templatelist.html_editor',['data'=>$responseData->data]);
        
        
        // if ($responseData) {
        //     return redirect()->route('template-list.index')->with('success', $responseData->message);
        // } else {
        //     return redirect()->route('template-list.index')->with('error', $responseData->message);
        // }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $parameters =array( 
            "id" => $id,
        );
        $apiurl = config('apipath.marketing-template-edit');
        // $apiurl = "https://e-nnovation.net/backend/public/api/marketing-template/edit";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        return view('Marketing::templatelist.edit', collect($responseData)); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   
        dd($request->id());
        $parameters =array( 
            "id" => $id,
        );
        $apiurl = config('apipath.marketing-template-update');
        // $apiurl = "https://e-nnovation.net/backend/public/api/marketing-template/update";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        if ($responseData) {
            return redirect()->route('template-list.index')->with('success', $responseData->message);
        } else {
            return redirect()->route('template-list.index')->with('error', $responseData->message);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function TemplateListDestroy(Request $request)
    {  
        $parameters =array( 
            "id" => $request->id,
        );
        $apiurl = config('apipath.marketing-template-destroy');
        // $apiurl = "https://e-nnovation.net/backend/public/api/marketing-template/destroy";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        
        if ($responseData) {
            return response()->json(['success' => $responseData->message]);
        } else {
            return response()->json(['success' => $responseData->message]);
        }
        
    }
    public function TemplateListUpdate(Request $request, $id)
    {  
         
        $parameters =array( 
            "id" => $request->id,
            "subject" => $request->subject,
            "content" => $request->content,
        );
        $apiurl = config('apipath.marketing-template-update');
        // $apiurl = "https://e-nnovation.net/backend/public/api/marketing-template/update";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);    
        
        if (isset($responseData->message)) {
            return redirect()->route('template-list.index')->with('success', $responseData->message); 
        } else {
            return redirect()->route('template-list.index')->with('success', $responseData['message']);
        }
        
    }

    public function ChangeTemplateListStatus(Request $request)
    {
        $parameters =array( 
            "id" => $request->id, 
        ); 
        $apiurl = config('apipath.marketing-template-changeStatus');
        // $apiurl = "https://e-nnovation.net/backend/public/api/marketing-template/changeStatus";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);    
        
        if (isset($responseData->message)) {
            return response()->json(['success' => $responseData->message]);
        } else {
            return response()->json(['success' => $responseData['message']]); 
        } 
    }


  
    
}
