<?php

namespace Modules\Marketing\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Auth;
use App\Helper\Helper;

class SenderListController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $parameters =array( 
            "perPage" => "",
            "search" => "",
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",
        );
        $apiurl = config('apipath.marketing-template'); 
        $apiurl = "https://e-nnovation.net/backend/public/api/senderemail";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);    
        return view('Marketing::settings.index', collect($responseData->data));  
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return response()->json([ 'success'=>'Sender Added successfully']);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {       
        $parameters =array( 
            "sender_id" => $id,
        );
        // $apiurl = config('apipath.marketing-template-edit'); 
        $apiurl = "https://e-nnovation.net/backend/public/api/senderemail/edit";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        return response()->json(['edit_sender' => $responseData->data]); 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       
        
    }
    public function AddSender(Request $request)
    {
        $parameters =array( 
            "sender_name" => $request->sender_name,
            "sender_email" => $request->sender_email,
        );
        // $apiurl = config('apipath.marketing-template-edit'); 
        $apiurl = "https://e-nnovation.net/backend/public/api/senderemail/store";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        if(isset($responseData->message)){
            return response()->json(['success'=>$responseData->message]);
        }
        else{
            return response()->json(['success'=>$responseData['message']]);
        }
        // return response()->json(['success'=>'Sender Status Changed Successfully']);
    }
    public function SenderUpdate(Request $request)
    {
        $parameters =array( 
            "sender_id" => $request->sender_id,
            "sender_name" => $request->sender_name,
            "sender_email" => $request->sender_email,
        );
        // $apiurl = config('apipath.marketing-template-edit'); 
        $apiurl = "https://e-nnovation.net/backend/public/api/senderemail/update";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        if(isset($responseData->message)){
            return response()->json(['success'=>$responseData->message]);
        }
        else{
            return response()->json(['success'=>$responseData['message']]);
        }
       
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        
        
    }
    public function DeleteSender(Request $request)
    {  
        $parameters =array( 
            "sender_id" => $request->id,
        );  
        $apiurl = "https://e-nnovation.net/backend/public/api/senderemail/delete";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);    
        if(isset($responseData->message)){
            return response()->json(['success'=>$responseData->message]);
        }
        else{
            return response()->json(['success'=>$responseData['message']]);
        }
        
    }
    public function ChangeSenderStatus(Request $request)
    {    
        $parameters =array( 
            "status" => $request->status,
            "sender_id" => $request->sender_id,
        );  
        $apiurl = "https://e-nnovation.net/backend/public/api/senderemail/change-status";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);   
        if(isset($responseData->message)){
            return response()->json(['success'=>$responseData->message]);
        }
        else{
            return response()->json(['success'=>$responseData['message']]);
        } 
    }
}
