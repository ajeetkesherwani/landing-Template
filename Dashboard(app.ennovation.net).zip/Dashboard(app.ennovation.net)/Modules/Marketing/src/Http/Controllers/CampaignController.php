<?php

namespace Modules\Marketing\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Marketing\Models\TemplateList;
use Modules\Marketing\Models\ServerMail;
use Modules\Marketing\Models\ContactGroup;
use Modules\Marketing\Models\Campaign;
use App\Helper\Helper;


use Illuminate\Support\Facades\Hash;
// use Modules\UserManage\Models\UserHasRoles;
use Auth;

class CampaignController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $parameters =array();
        $apiurl = config('apipath.marketing-campaign-list'); 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        return view('Marketing::campaign.index',['data'=>$responseData->data->data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        $parameters =array();
        $apiurl = config('apipath.marketing-campaign-create'); 
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        return view('Marketing::campaign.create',['data'=>$responseData->data]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        // dd($request->all());
        $parameters =array( 
            "campaign_name" => $request->name,
            "campaign_subject" =>  $request->subject,
            "template_id" =>  $request->campaign_template,
            "sender_id" =>  $request->sender_id,
            "group_ids" =>  $request->group,
            "description" =>  $request->description,
            "source_ids" =>  $request->source_id,
            "description" =>  $request->description,
            "start_date" =>  $request->start_date,
            "from_time" =>  $request->from_time,
            "to_time" =>  $request->to_time,
            "time_zone" =>  $request->time_zone,
            
        );
        
        $apiurl = config('apipath.marketing-campaign-store');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 

        if(isset($responseData->message)) {
            return redirect()->route('campaign.index')->with('success', $responseData->message);
        } else {
            return redirect()->route('campaign.index')->with('error', $responseData['message']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {       
        $parameters =array('id'=>$id);
        $apiurl = config('apipath.marketing-campaign-edit'); 
        // $apiurl="https://e-nnovation.net/backend/public/api/campaign/edit";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        return view('Marketing::campaign.edit',['data'=>$responseData->data]);      
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function CampaignUpdate(Request $request)
    {
        $parameters =array( 
            "campaign_name" => $request->name,
            "campaign_subject" =>  $request->subject,
            "template_id" =>  $request->campaign_template,
            "sender_id" =>  $request->sender_id,
            "group_ids" =>  $request->group,
            "description" =>  $request->description,
            "source_ids" =>  $request->source_id,
            "description" =>  $request->description,
            "campaign_id" =>  $request->campaign_id,

            "start_date" =>  $request->start_date,
            "from_time" =>  $request->from_time,
            "to_time" =>  $request->to_time,
            "time_zone" =>  $request->time_zone,
            
        );

        // dd($parameters);
        
        $apiurl = config('apipath.marketing-campaign-update');
        // $apiurl="https://e-nnovation.net/backend/public/api/campaign/update";

        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
        // dd($responseData);
        if(isset($responseData->message)) {
            return redirect()->route('campaign.index')->with('success', $responseData->message);
        } else {
            return redirect()->route('campaign.index')->with('error', $responseData['message']);
        }
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {   
        $parameters =array(
            'id'=>$request->campaign_id,
        );
        $apiurl = config('apipath.marketing-campaign-delete');
        // $apiurl="https://e-nnovation.net/backend/public/api/campaign/delete";

        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 
    
        if(isset($responseData->message)) {
            return response()->json(['success' => $responseData->message]);
        } else {
            return response()->json(['success' => $responseData['message']]); 
        }
    }

    public function ChangeCampaignStatus(Request $request)
    {   
        $parameters =array( 
            "id" => $request->campaign_id, 
        ); 
        $apiurl = config('apipath.marketing-campaign-status');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);    
        
        if (isset($responseData->message)) {
            return response()->json(['success' => $responseData->message]);
        } else {
            return response()->json(['success' => $responseData['message']]); 
        } 
    }
    public function CampaignView($id)
    {
        $parameters =array('id'=>$id);
        // $apiurl = config('apipath.marketing-campaign-view'); 
        $apiurl="https://e-nnovation.net/backend/public/api/campaign/view";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        // dd($responseData);
        return view('Marketing::campaign.show',['data'=>$responseData->data]);
    }



}
