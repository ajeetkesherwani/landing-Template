<?php

namespace Modules\Marketing\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Helper\Helper;




class ProTemplateBuilderController extends Controller
{
    public function create()
    {
        return view('maildoll_editor.create');
    }

    /*
    *   Image Upload
    *   @param $request
    *   @return json
    */
    public function imgUpload(Request $request)
    {
        $file = $request->file('file');
        $fileName = time().'.'.$file->extension();
        $file->move(public_path('editor_images'), $fileName);
        return response()->json(['success' => $fileName]);
    }

    /*
    *   Get all images from the folder
    *   @param $request
    *   @return json
    */
    public function getImg(Request $request)
    {
        $upload_dir = public_path('editor_images/');
        //get all files in uploads folder
        $files = array_diff(scandir($upload_dir), ['.', '..']);

        //creating response
        $response = [];

        $response['code'] = 0;
        $response['files'] = $files;
        // $response['directory']= $upload_dir;
        $response['directory'] = url('/editor_images/');
        //convert to json
        return json_encode($response);
    }

    /*
    *   Store template to the database and create a HTML copy
    *   @param $request
    *   @return json
    */
    public function store(Request $request)
    {   
        dd($request->all());
        $parameters =array( 
            "id" => $request->id,
            "content" => $request->html,
            "subject" => $request->subject,
            "source" =>"add",
        );

        $apiurl = config('apipath.marketing-template-update');
        // $apiurl = "https://e-nnovation.net/backend/public/api/marketing-template/update";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);  
        dd($responseData);
        if ($responseData) {
            return redirect()->route('template-list.index')->with('success', $responseData->message);
        } else {
            return redirect()->route('template-list.index')->with('error', $responseData->message);
        }
    }

    /*
    *   Editor view
    *   @return view
    */
    public function edit(Request $request)
    {
        $template = TemplateBuilder::where('id', $request->template_id)->HasAgent()->first();

        return view('maildoll_editor.edit', compact('template'));
    }

    //END
}
