<?php
use Illuminate\Support\Facades\Route;
use Modules\Marketing\Http\Controllers\SenderListController;
use Modules\Marketing\Http\Controllers\TemplateController;
use Modules\Marketing\Http\Controllers\TemplateListController;
use Modules\Marketing\Http\Controllers\ContactGroupController;
use Modules\Marketing\Http\Controllers\ServerMailController;
use Modules\Marketing\Http\Controllers\ContactController;
use Modules\Marketing\Http\Controllers\CampaignController;
use Modules\Marketing\Http\Controllers\ProTemplateBuilderController;




/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your aaplication. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



    // Sender List Resource
    Route::resource('server-mail', ServerMailController::class);
    Route::post('server-update',[ServerMailController::class,'ServerUpdate'])->name('server-update');
    Route::resource('sender-list', SenderListController::class);
    Route::post('sender-add',[SenderListController::class,'AddSender'])->name('sender-add');
    Route::post('sender-delete',[SenderListController::class,'DeleteSender'])->name('sender-delete');
    Route::post('sender-update',[SenderListController::class,'SenderUpdate'])->name('sender-update');
    Route::post('sender-status',[SenderListController::class,'ChangeSenderStatus'])->name('sender-status');
    Route::post('server-status',[ServerMailController::class,'ChangeServerStatus'])->name('server-status');

    //campaign Route
    Route::resource('campaign',CampaignController::class);
    Route::post('campaign-status',[CampaignController::class,'ChangeCampaignStatus'])->name('campaign-status');
    Route::get('campaign-edit/{id}',[CampaignController::class,'edit'])->name('campaign-edit');
    Route::post('campaign-update',[CampaignController::class,'CampaignUpdate'])->name('campaign-update');
    Route::post('campaign-delete',[CampaignController::class,'destroy'])->name('campaign-delete');
    Route::get('campaign-view/{id}',[CampaignController::class,'CampaignView'])->name('campaign-view');

    // Template Route
    Route::resource('template-group-list', TemplateController::class);
    Route::post('template-status',[TemplateController::class,'ChangeTemplateStatus'])->name('template-status');
    Route::post('template-delete',[TemplateController::class,'TemplateDestroy'])->name('template-delete');
    Route::post('template-update',[TemplateController::class,'TemplateUpdate'])->name('template-update');

    // Template route
     Route::resource('template-list', TemplateListController::class);
     Route::get('template-lists/{id}', [TemplateListController::class,'TemplateList'])->name('template-list');
     Route::get('template-lists/create/pro-editor', [TemplateListController::class,'proEditor'])->name('template.pro-editor');
     Route::post('template-list-status',[TemplateListController::class,'ChangeTemplateListStatus'])->name('template-list-status');
    Route::post('template-list-delete',[TemplateListController::class,'TemplateListDestroy'])->name('template-list-delete');
    Route::post('template-list-update/{id}',[TemplateListController::class,'TemplateListUpdate'])->name('template-list-update');


    // Pro-template-editor

    Route::post('/pro/email-builder/upload', [ProTemplateBuilderController::class, 'imgUpload'])
    ->name('pro.template.builder.image_upload');

    Route::get('/pro/email-builder/get-image', [ProTemplateBuilderController::class, 'getImg'])
            ->name('pro.template.builder.get.image');

    Route::any('/pro/email-builder/store', [ProTemplateBuilderController::class, 'store'])
            ->name('pro.template.builder.store');

    Route::post('/pro/email-builder/edit', [ProTemplateBuilderController::class, 'edit'])
            ->name('pro.template.builder.edit');



    //contact route
     Route::resource('contact-group-list', ContactGroupController::class);
    
    Route::post('contact-group/changeContactGroupStatus', [ContactGroupController::class,'changeContactGroupStatus'])->name('changeContactGroupStatus');
    Route::post('contact-group/contactGroupUpdate',[ContactGroupController::class,'contactGroupUpdate'])->name('contactGroupUpdate');
    Route::post('deleteContactGroup/{id}', [ContactGroupController::class,'deleteContactGroup'])->name('deleteContactGroup');
    Route::get('contact-list/{id}',[ContactGroupController::class,'ContacView'])->name('contact-list');
    Route::get('contact-create',[ContactGroupController::class,'ContactCreate'])->name('contact-create');
    Route::get('contact-edit/{id}',[ContactGroupController::class,'GroupContactEdit'])->name('contact-edit');
    Route::put('contact-update',[ContactGroupController::class,'GroupContactUpdate'])->name('contact-update');
    Route::post('contact_add',[ContactGroupController::class,'GetContact'])->name('contact_add');
    Route::post('contact-list-delete',[ContactGroupController::class,'DeleteContact'])->name('contact-list-delete');

    Route::get('contact-import', [ContactGroupController::class,'contactImport'])->name('contact-import');
     Route::post('contact-import-process', [ContactGroupController::class,'contactImportProcess'])->name('contact-import-process');



     

//bulk import
Route::get('importfile',[ContactController::class,'import'])->name('importcreate');
Route::post('import',[ContactController::class,'uploadContactList'])->name('import');
Route::get('simple-download-file',[ContactController::class,'donwloadFile'])->name('simple-download-file');


     //contact list route

//     Route::get('contact-list/{id}',[ContactController::class,'GetContact'])->name('get-contact-id');
    // Route::get('contact-lists/{id}',[ContactController::class,'GetContactList'])->name('contact-list-show');
    // Route::resource('add-contact', ContactController::class);
//     Route::get('contact-list/{id}',[ContactController::class,'GetGroupId'])->name('contact-list');
    // Route::get('/contact-list/{id}', [ContactController::class, 'GetContactList']);
    Route::get('checkgroupbox',[ContactController::class,'checkgroupbox'])->name('checkgroupbox');

    Route::post('contact-list/updateContact', [ContactController::class,'updateContact'])->name('updateContact');
    Route::post('contact-list/changeContactListStatus', [ContactController::class,'changeContactListStatus'])->name('changeContactListStatus');
    Route::post('contact-list/ChangeContactToGroupStatus', [ContactController::class,'ChangeContactToGroupStatus'])->name('ChangeContactToGroupStatus');

    