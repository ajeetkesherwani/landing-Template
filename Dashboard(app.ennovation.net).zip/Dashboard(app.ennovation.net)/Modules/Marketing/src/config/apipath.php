<?php
return [
    // TemplateList Api's
    'marketing-template' => 'https://e-nnovation.net/backend/public/api/marketing-template',
    'marketing-template-store' => 'https://e-nnovation.net/backend/public/api/marketing-template/store',
    'marketing-template-edit' => 'https://e-nnovation.net/backend/public/api/marketing-template/edit',
    'marketing-template-update' => 'https://e-nnovation.net/backend/public/api/marketing-template/update',
    'marketing-template-destroy' => 'https://e-nnovation.net/backend/public/api/marketing-template/destroy',
    'marketing-template-changeStatus' => 'https://e-nnovation.net/backend/public/api/marketing-template/changeStatus',
    
    'marketing-campaign-list'=>'https://e-nnovation.net/backend/public/api/campaign',
    'marketing-campaign-create'=>'https://e-nnovation.net/backend/public/api/campaign/create',
    'marketing-campaign-store'=>'https://e-nnovation.net/backend/public/api/campaign/store',
    'marketing-campaign-edit'=>'https://e-nnovation.net/backend/public/api/campaign/edit',
    'marketing-campaign-update'=>'https://e-nnovation.net/backend/public/api/campaign/update',
    'marketing-campaign-status'=>'https://e-nnovation.net/backend/public/api/campaign/change-status',
    'marketing-campaign-delete'=>'https://e-nnovation.net/backend/public/api/campaign/delete',
    'apipath.marketing-campaign-view'=>'https://e-nnovation.net/backend/public/api/campaign/view',


    'apipath.marketing-group-import'=>'https://e-nnovation.net/backend/public/api/contact-group/contact-import',

];