<?php
return [
    'lead' => 'https://e-nnovation.net/backend/public/api/lead',
    'lead-create' => 'https://e-nnovation.net/backend/public/api/lead/create',
    'lead-store' => 'https://e-nnovation.net/backend/public/api/lead/store',
    'lead-edit' => 'https://e-nnovation.net/backend/public/api/lead/edit',
    'lead-update' => 'https://e-nnovation.net/backend/public/api/lead/update',
    'lead-changeStatus' => 'https://e-nnovation.net/backend/public/api/lead/changeStatus',
    'lead-destroy' => 'https://e-nnovation.net/backend/public/api/lead/destroy',

    //lead setting
     //industry
    'lead-setting' => 'https://e-nnovation.net/backend/public/api/lead_source',
    'lead-industry-store' => 'https://e-nnovation.net/backend/public/api/lead_industry/store',  
    'lead-industry-edit' => 'https://e-nnovation.net/backend/public/api/lead_industry/edit', 
    'lead-industry-update' => 'https://e-nnovation.net/backend/public/api/lead_industry/update',  
    'lead-industry-changeStatus' => 'https://e-nnovation.net/backend/public/api/lead_industry/changeStatus',   
     
     //status
    'lead-status-store' => 'https://e-nnovation.net/backend/public/api/lead_status/store',  
    'lead-status-edit' => 'https://e-nnovation.net/backend/public/api/lead_status/edit', 
    'lead-status-update' => 'https://e-nnovation.net/backend/public/api/lead_status/update',  
    'lead-status-changeStatus' => 'https://e-nnovation.net/backend/public/api/lead_status/changeStatus', 

     // source 
    'lead-source-store' => 'https://e-nnovation.net/backend/public/api/lead_source/store',  
    'lead-source-edit' => 'https://e-nnovation.net/backend/public/api/lead_source/edit', 
    'lead-source-update' => 'https://e-nnovation.net/backend/public/api/lead_source/update',  
    'lead-source-changeStatus' => 'https://e-nnovation.net/backend/public/api/lead_source/changeStatus', 

     //customer
     'lead-customer' => 'https://e-nnovation.net/backend/public/api/crm_customer',
     'lead-customer-create' => 'https://e-nnovation.net/backend/public/api/crm_customer/create',
     'lead-customer-store' => 'https://e-nnovation.net/backend/public/api/crm_customer/store',  
     'lead-customer-edit' => 'https://e-nnovation.net/backend/public/api/crm_customer/edit', 
     'lead-customer-update' => 'https://e-nnovation.net/backend/public/api/crm_customer/update',  
     'lead-customer-changeStatus' => 'https://e-nnovation.net/backend/public/api/crm_customer/changeStatus', 



     'lead-quotation' => 'https://e-nnovation.net/backend/public/api/crm_quotation',
     'lead-quotation-create' => 'https://e-nnovation.net/backend/public/api/crm_quotation/create',
     'lead-quotation-store' => 'https://e-nnovation.net/backend/public/api/crm_quotation/store',  
     'lead-quotation-edit' => 'https://e-nnovation.net/backend/public/api/crm_quotation/edit', 
     'lead-quotation-update' => 'https://e-nnovation.net/backend/public/api/crm_quotation/update',  
     'lead-quotation-changeStatus' => 'https://e-nnovation.net/backend/public/api/crm_quotation/changeStatus', 
 
     //enquiry

     'enquiry' => 'https://e-nnovation.net/backend/public/api/enquiry',
     'enquiry-create' => 'https://e-nnovation.net/backend/public/api/enquiry/create',
     'enquiry-store' => 'https://e-nnovation.net/backend/public/api/enquiry/store',  
     'enquiry-edit' => 'https://e-nnovation.net/backend/public/api/enquiry/edit', 
     'enquiry-update' => 'https://e-nnovation.net/backend/public/api/enquiry/update',  
     'enquiry-changeStatus' => 'https://e-nnovation.net/backend/public/api/enquiry/changeStatus', 
 







];
