
<x-app-layout>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500"> 
        <li class="breadcrumb-item"><a href="#" class="text-dark tx-16">Dashboard</a></li>
    </ol>
</nav>

    <div class="card">
        <div class="tab-content">
            <div class="card-header d-flex align-items-center justify-content-between py-2 px-3">
                <h5 class="tx-15 mb-0">{{__('crm.quotation_list')}}</h5>
                <a href="{{ route('quotation.create') }}">
                    <button class="btn btn-md  btn-primary "><i data-feather="plus" class="lead_icon mg-r-5"></i>{{__('crm.add_quotation')}}</button></a>
                </a>
            </div>
            <div class="card-body">
                <div class="row align-item-center mb-3">
                    <div class="col-lg-2 col-md-3 col-4">
                        <select class="form-control form-select" aria-label="Default select example">
                            <option>10</option>
                        </select>
                    </div>
                    <div class="col-lg-6 col-md-3 col-8"><input type="text" id="Search" class="form-control col-lg-4 fas fa-search" placeholder="Search..." aria-label="Search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table border table_wrapper rounded">
                        <thead>
                            <tr>
                                <th class="border-bottom" style="min-width:70px;">{{__('common.sl_no')}}</th>
                                <th class="border-bottom" style="min-width: 150px;">{{__('crm.date')}}</th>
                                <th class="border-bottom" style="min-width: 150px;">{{__('crm.quotation_no')}}</th>
                                <th class="border-bottom" style="min-width: 150px;">{{__('crm.customer_delails')}}</th>
                                <th class="border-bottom" style="min-width: 150px;">{{__('crm.quote_price')}}</th>
                                <th class="border-bottom" style="min-width: 100px;">{{__('common.status')}}</th>
                                <th class="text-center border-bottom" style="min-width: 70px;">{{__('common.action')}}
                                </th>
                            </tr>
                        </thead>
                        <tbody id="Search_Tr">
                           
                            <!-- Start -->
                            @if (!empty($quotation_list))
                                @foreach ($quotation_list as $key => $quotation)
                                    <tr>
                                        <td class="">{{ $key + 1 }}</td>
                                        <td class="">{{ \Carbon\Carbon::parse($quotation->created_at)->format('d/m/Y')}}</td>
                                        <td class="">{{ $quotation->quotation_no }}</td>               
                                        <td class="">
                                            @if (!empty($quotation->customer_details))
                                            {{ $quotation->customer_details->first_name }}<br>{{$quotation->customer_details->email}}
                                            @endif
                                        </td>
                                        <td class="">{{ $quotation->final_cost }}</td>
                                        
                                        <td>
                                            <div class="form-check form-switch">
                                            <input type="checkbox" class="custom-control-input toggle-class" id="customSwitch">
                                                
                                            </div>
                                        </td>
                                        <td class="d-flex align-items-center gap-2 justify-content-center">
                                        <a href="{{ url('quotation/details/' . $quotation->quotation_id) }}"
                                                value=""
                                                class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i
                                                    data-feather="eye"></i></a>
                                            <a href="{{ route('quotation.edit', $quotation->quotation_id) }}" class="btn btn-sm btn-white table_btn py-1 px-2"><i data-feather="edit-2"></i></a>
                                          

                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>         
        </div><!--end row-->
    </div>     
    <!--start delete modal-->
    <div class="modal fade effect-scale" id="delete_modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title">{{__('crm.delete_quotation')}}</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="delete_department_id" name="input_field_id">
                    <p class="mg-b-0">{{ __('common.delete_confirmation') }}</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    {{ __('common.no')}}
                    </button>
                    <button type="button" class="btn btn-primary delete_btn">{{ __('common.yes') }}</button>
                </div>
            </div>
        </div>
    </div>
       
        
    @push('scripts')
    <!-- search ajax-->
    <script>
        $(document).ready(function() {
            $("#Search").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#Search_Tr tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>

    <!-- delete ajax start -->
    <script>
        $(document).ready(function() { 
            $(document).on("click", "#delete_quotation", function() {
                var quotation_id = $(this).val();
                $('#delete_department_id').val(quotation_id);
            });
            $(document).on('click', '.delete_btn', function() {
                var quotation_id = $('#delete_department_id').val();

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                }); 
                $.ajax({
                    type: "POST",
                    url: "{{ url('quotation-delete') }}",
                    data: { quotation_id: quotation_id },
                    dataType: "json",
                    success: function(response) {
                        Toaster(response.success);
                        setTimeout(function() {
                            location.reload(true);
                        }, 300);
                    }
                }); 
            });
        });
    </script>
    <!--end delete ajax-->

    <!--end status ajax-->
    <script type="text/javascript">
        // change status in ajax code start
        // $('.toggle_status').change(function(e) {
        //     e.preventDefault();
        //     // alert('hihyu');
        //     let status = $(this).prop('checked') === true ? 1 : 0;
        //     let staff_id = $(this).data('id');
        //     $.ajaxSetup({
        //         headers: {
        //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //         }
        //     });
        //     $.ajax({
        //         type: "POST",
        //         dataType: "json",
        //         url: "{{ url('employee-status-change') }}",
        //         data: {
        //             'status': status,
        //             'staff_id': staff_id
        //         },
        //         success: function(data) {
        //             // location.reload();
        //             Toaster(' Employee Status Change Successfully');
        //         }
        //     });
        // });
        // chenge status in ajax code end  
    </script>
    @endpush 
</x-app-layout>