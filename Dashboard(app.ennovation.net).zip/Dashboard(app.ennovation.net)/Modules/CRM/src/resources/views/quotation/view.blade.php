
<x-app-layout>
<ol class="breadcrumb bg-transparent px-0 pb-0 fw-500">
        <li class="breadcrumb-item"><a href="#" class="text-dark tx-15">Dashboard</a></li>
        <li class="breadcrumb-item active" aria-current="page"><a href="{{ route('quotation.index') }}" class="text-dark tx-15">Quotation</a></li>

    </ol>
    <div class="content content-fixed bd-b">
        <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                    <h4 class="mg-b-5">Ouotation Number #{{ $response->quotation_no }}</h4>
                    <p class="mg-b-0 tx-color-03">{{ \Carbon\Carbon::parse($response->created_at)->format('Y/m/d')}}</p>
                </div>
                <div class="mg-t-20 mg-sm-t-0">
                    <button class="btn btn-white print"><svg xmlns="http://www.w3.org/2000/svg" width="24"
                            height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                            stroke-linecap="round" stroke-linejoin="round" class="feather feather-printer mg-r-5">
                            <polyline points="6 9 6 2 18 2 18 9"></polyline>
                            <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
                            <rect x="6" y="14" width="12" height="8"></rect>
                        </svg> Print</button>

              <a class="btn btn-primary mg-l-5"
              target="_BLANK"
                        href="{{$response->shareUrl }}"><svg
                            xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" class="feather feather-share-2 mg-r-5">
                            <rect x="1" y="4" width="22" height="16" rx="2"
                                ry="2"></rect>
                            <line x1="1" y1="10" x2="23" y2="10"></line>
                        </svg>SHARE</a>


                    <!-- <button class="btn btn-primary mg-l-5"> </button> -->
                    <a class="btn btn-primary mg-l-5"
                        href="{{ url('quotation-details-pdf/' . $response->quotation_no) }}"><svg
                            xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" class="feather feather-download mg-r-5">
                            <rect x="1" y="4" width="22" height="16" rx="2"
                                ry="2"></rect>
                            <line x1="1" y1="10" x2="23" y2="10"></line>
                        </svg>Download</a>
                </div>
            </div>
        </div><!-- container -->
    </div>
    <div class="content tx-13">
        <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
            <div class="row">
                <div class="col-sm-6">
                    <label class="tx-sans tx-uppercase tx-10 tx-medium tx-spacing-1 tx-color-03">Billed To</label>
                    <h6 class="tx-15 mg-b-10">  ThemePixels, Inc.</h6>
                    <p class="mg-b-0">
                    201 Something St., Something Town, YT 242, Country 6546
                    </p>
                 
                  
                </div>
                <div class="col-sm-6 tx-right d-none d-md-block">
                    <label class="tx-sans tx-uppercase tx-10 tx-medium tx-spacing-1 tx-color-03">Invoice Number</label>
                    <h1 class="tx-normal tx-color-04 mg-b-10 tx-spacing--2">#{{ $response->quotation_no }}</h1>
                </div>
                <div class="col-sm-6 col-lg-8 mg-t-40 mg-sm-t-0 mg-md-t-40">
                    <label class="tx-sans tx-uppercase tx-10 tx-medium tx-spacing-1 tx-color-03">Billed From</label>
                    <h6 class="tx-15 mg-b-10">@if(!empty($response->crm_quotation_address->company_name)){{$response->crm_quotation_customer->company_name}}@endif</h6>
                    <p class="mg-b-0">@if(!empty($response->crm_quotation_address->street_address)){{$response->crm_quotation_address->street_address}}@endif
                    @if(!empty($response->crm_quotation_address->city)){{$response->crm_quotation_address->city}}@endif
                    @if(!empty($response->crm_quotation_address->state)){{$response->crm_quotation_address->state}}@endif
                    @if(!empty($response->crm_quotation_address->countries_id)){{$response->crm_quotation_address->countries_id}}@endif
                    @if(!empty($response->crm_quotation_address->zipcode)){{$response->crm_quotation_address->zipcode}}@endif   
                    </p>
                    <p class="mg-b-0">Tel No: @if(!empty($response->crm_quotation_contact->phone)){{$response->crm_quotation_contact->phone}}@endif </p>
                    <p class="mg-b-0">Email:@if(!empty($response->crm_quotation_contact->contact_email)){{$response->crm_quotation_contact->contact_email}}@endif</p>

                </div>
                <div class="col-sm-6 col-lg-4 mg-t-40">
                    <label class="tx-sans tx-uppercase tx-10 tx-medium tx-spacing-1 tx-color-03">Invoice Information</label>
                    <ul class="list-unstyled lh-7">
                        <li class="d-flex justify-content-between">
                            <span>Invoice Number</span>
                            <span>{{$response->quotation_no}}</span>
                        </li>
                      
                        <li class="d-flex justify-content-between">
                            <span>Issue Date</span>
                            <span>{{ \Carbon\Carbon::parse($response->created_at)->format('Y/m/d')}}</span>
                        </li>
                       
                    </ul>
                </div>
            </div>

            <div class="table-responsive mg-t-40">
                <table class="table table-invoice bd-b">
                    <thead>
                        <tr>
                            <th class="wd-20p">{{ __('sales.sl_no') }}</th>
                            <th class="wd-40p d-none d-sm-table-cell">{{ __('sales.item') }}</th>
                            <th class="tx-center">{{ __('sales.qty') }}</th>
                            <th class="tx-right">{{ __('sales.unit_price') }}</th>
                            <th class="tx-right">{{ __('sales.item_cost') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                    @if (!empty($response->crm_quotation_item))
                            @foreach ($response->crm_quotation_item as $key => $item)
                                <tr>
                                    <td class="tx-nowrap">{{ $key + 1 }}</td>
                                    <td class="d-none d-sm-table-cell tx-color-03"> {{ $item->item_name }}</td>
                                    <td class="tx-center">{{ $item->quantity }}</td>
                                    <td class="tx-right">${{ $item->unit_price }}</td>
                                    <td class="tx-right">${{ $item->item_cost }}</td>
                                </tr>
                            @endforeach
                        @endif

                    </tbody>
                </table>
            </div>

            <div class="col-sm-6 col-lg-6 order-2 order-sm-0 mg-t-40 mg-sm-t-0">
            <label class="tx-sans tx-uppercase tx-10 tx-medium tx-spacing-1 tx-color-03">Notes</label>
            <p>{{$response->note}}</p>
          </div>

        </div>
    </div>


    @push('scripts')
        <script>
            $(document).ready(function() {
                $(".print").click(function() {
                    window.print();
                });
            });
        </script>
    @endpush
</x-app-layout>
