<x-app-layout>
<nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500"> 
            <li class="breadcrumb-item"><a href="{{ route('enquiry.index') }}" class="text-dark tx-16">{{ __('crm.enquiry') }}</a></li>
        </ol>
    </nav>

<!--index table start-->
<div class="card contact-content-body">
    <div class="card-header">
        <div class="d-flex align-items-center justify-content-between">
        
            <h6 class="tx-15 mg-b-0">{{ __('crm.enquiry_list') }}</h6>
           
          
        </div>
    </div>
    <div class="card-body">
        <div class="form-row">
            <div class="form-group mg-l-5">
                <input type="text" class="form-control" id="Search" placeholder="{{ __('newsletter.search_placeholder')}}">
            </div>
        </div>
        <div class="table-responsive">
            @if(!empty($enquiry_list))  
                <table class="table border table_wrapper" id="template_list_data_reload">
                    <thead>
                        <tr>
                            <th>{{ __('common.sl_no') }}</th>
                            <th>{{ __('crm.enquiry_no')}}</th>
                            <th>{{ __('crm.enquiry_customer_name')}}</th>
                            <th>{{ __('crm.enquiry_customer_email')}}</th>
                            <th>{{ __('common.status') }}</th>
                            <th class="text-center wd-10p">{{ __('common.action') }}</th>
                        </tr>
                    </thead>
                    <tbody id="Search_Tr">
                        @if (!empty($enquiry_list))
                        @foreach ($enquiry_list as $key => $enquiry)
                        <tr>  
                            <td>{{ $key + 1 }}</td>
                            <td>{{ $enquiry->enquiry_no }}</td>
                            <td>{{ $enquiry->customers_name }}</td>
                            <td>{{ $enquiry->email_address }}</td>
                            <td>
                                <div class="custom-control custom-switch">
                                <input type="checkbox" class="custom-control-input toggle-class" {{ $enquiry->status == '1' ? 'checked' : '' }} data-id="{{$enquiry->enquiry_id}}" id="customSwitch{{$enquiry->enquiry_id}}">
                                <label class="custom-control-label" for="customSwitch{{$enquiry->enquiry_id}}"></label>
                                </div>
                            </td>
                            <td class="d-flex align-items-center">
                               

                                <a href="{{ route('enquiry.show', $enquiry->enquiry_id) }}"   class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="eye"></i></i></a>
                                
                              
                            </td>
                        </tr>
                        @endforeach
                        @endif
                    </tbody>
                </table>
            @else
                <div class="table-responsive">
                    <table class="table border table_wrapper">
                        <thead>
                            <tr>
                            <th>{{ __('common.sl_no') }}</th>
                            <th>{{ __('crm.enquiry_no')}}</th>
                            <th>{{ __('crm.enquiry_customer_name')}}</th>
                            <th>{{ __('crm.enquiry_customer_email')}}</th>
                            <th>{{ __('common.status') }}</th>
                            <th class="text-center wd-10p">{{ __('common.action') }}</th>
                            </tr>
                        </thead>
                        <tbody >
                            <tr>
                                <td>1</td>
                                <td>5665dfe</td>
                                <td>Aaron</td>
                                <td>aaron@gmail.com</td>
                                <td>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input toggle-class" {{'1' == '1' ? 'checked' : '' }} data-id="1" id="customSwitch.'1'">
                                        <label class="custom-control-label" for="customSwitch.'1'"></label>
                                    </div>
                                </td>
                                <td class="d-flex align-items-center">
                                    <a href="{{ route('template-list.edit','1') }}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i data-feather="edit-2"></i></a>
                                    
                                    <button data-id="1" data-toggle="modal" data-target="#delete_modal" class="btn btn-sm btn-white d-flex align-items-center mg-r-5 del_button"><i data-feather="trash"></i></button>
                                </td>   
                            </tr>
                            <tr>
                                <td colspan="5">
                                <h5 class="text-center mb-0 py-1">No Record Found !.</h5>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>
</div>

<div class="modal fade" id="delete_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel5" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
        <div class="modal-content tx-14">
            <div class="modal-header">
                <h6 class="modal-title" id="exampleModalLabel5">{{ __('newsletter.delete_template_list')}}</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h6>{{ __('settings.deleted_data')}}</h6>
                <input type="hidden" id="delete_id" name="input_field_id">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                {{ __('common.no')}}
                </button>
                <button type="submit" class="btn btn-primary deleteBtn">{{ __('common.yes') }}</button>
            </div>
        </div>
    </div>
</div>
   
    @push('scripts') 
        <script>
            // start jquery
            $(document).ready(function() {
                $("#Search").on("keyup", function() {
                    var value = $(this).val().toLowerCase();
                    $("#Search_Tr tr").filter(function() {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });

                $(document).ready(function() {
                    setTimeout(function() {

                        $("div.alert").remove();
                    }, 3000);
                });

                $(document).ready(function() {
                    $("#addbutton").on('click', function(e) {
                        e.preventDefault();
                        $("#open_modal").modal('show');
                    });
                });
            });

            // change status in ajax code start
            $('.toggle-class').change(function(e) {
                e.preventDefault();
                let status = $(this).prop('checked') === true ? 1 : 0;
                let id = $(this).data('id');
                console.log(id);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "{{ url('enquiry-status') }}",
                    data: {
                        'status': status,
                        'enquiry_id': id
                    },
                    success: function(data) {
                        // $("#template_list_data_reload").load(location.href + " #template_list_data_reload");
                        Toaster(data.success);
                    }
                });
            });

            // chenge status in ajax code end  
            $(document).ready(function() {
                $('.del_button').on('click', function(e) {
                    e.preventDefault();
                    var id = $(this).data('id');
                    $('#delete_id').val(id);
                });

                $(document).on("click", ".deleteBtn", function() {
                    var id = $('#delete_id').val();
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "{{ url('template-list-delete') }}",
                        data: {
                            id: id,
                        },
                        dataType: "json",
                        success: function(response) {
                            Toaster('Template Deleted Successfully!');
                            setTimeout(function() {
                                location.reload(true);
                            }, 1500);
                            try {
                                ClassicEditor.delete(document.querySelector('.del_button'))
                                    .catch(error => {
                                        console.error(error);
                                    });
                            } catch (err) {

                            }
                        },
                    });
                });
            });
            // end delete modal ajax
        </script>
    @endpush
</x-app-layout>
