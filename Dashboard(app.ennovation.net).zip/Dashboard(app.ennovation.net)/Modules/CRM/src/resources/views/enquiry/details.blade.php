<x-app-layout>
<nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500"> 
            <li class="breadcrumb-item"><a href="{{ route('enquiry.index') }}" class="text-dark tx-16">{{ __('crm.enquiry') }}</a></li>
        </ol>
    </nav>
    <div class="content tx-13">
      <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
      @if(!empty($enquiry_list)) 
     
        <div class="row">
        
          <div class="col-sm-6 col-lg-8 mg-t-40 mg-sm-t-0 mg-md-t-40">
          <h6 class="tx-15 mg-b-10">{{ __('crm.enquiry_list') }}</h6>
         
            <p class="mg-b-0">{{ __('crm.enquiry_no') }}:{{$enquiry_list->enquiry_no}}</p>
            <p class="mg-b-0">{{ __('crm.enquiry_date') }}:{{ \Carbon\Carbon::parse($enquiry_list->created_at)->format('Y/m/d')}}</p>
          </div><!-- col -->
          <div class="col-sm-6 col-lg-4 mg-t-40">
          <h6 class="tx-15 mg-b-10">{{ __('crm.customer_details') }}</h6>
            <ul class="list-unstyled lh-7">
              <li class="d-flex justify-content-between">
                <span>{{ __('crm.enquiry_customer_name') }}</span>
                <span>{{$enquiry_list->customers_name}}</span>
              </li>
              <li class="d-flex justify-content-between">
                <span>{{ __('crm.enquiry_customer_email') }}</span>
                <span>{{$enquiry_list->email_address}}</span>
              </li>
              <li class="d-flex justify-content-between">
                <span>{{ __('crm.phone') }}</span>
                <span>{{$enquiry_list->phone}}</span>
              </li>
              <li class="d-flex justify-content-between">
                <span>{{ __('crm.country') }}</span>
                <span>@if(!empty($enquiry_list->country_details)){{$enquiry_list->country_details->countries_name}}@endif</span>
              </li>
              <li class="d-flex justify-content-between">
                <span>{{ __('crm.message') }}</span>
                <span>{{$enquiry_list->message}}</span>
              </li>
            </ul>
          </div><!-- col -->
        </div><!-- row -->
        @endif
   

        <form action="{{ route('enquiry.store') }}" method="POST" class="needs-validation" novalidate>
            @csrf
            <input type="hidden" name="enquiry_id" value=@if(!empty($enquiry_list->enquiry_id)){{$enquiry_list->enquiry_id}}@endif"">
            <div class="card contact-content-body">
                <div class="card-header">
                    <h6 class="tx-15 mg-b-0">{{__('crm.add_enquiry')}}</h6>
                </div>
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group col-lg-12 col-sm-12">
                            <label class="form-label">{{ __('crm.subject')}}
                            <span class="text-danger">*</span></label>
                            <input name="subject" type="text" class="form-control" placeholder="{{ __('newsletter.subject_placeholder')}}" required>
                            <div class="invalid-feedback">
                                {{ __('newsletter.subject_error')}}
                            </div>
                            <span class="text-danger">
                                @error('subject')
                                {{ $message }}
                                @enderror
                            </span>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label class="form-label">{{ __('crm.content')}}<span class="text-danger">*</span></label>
                            <textarea cols="40" rows="10" name="message" id="editor" class="form-control" required></textarea>
                            <div class="invalid-feedback">
                            {{ __('settings.template_contect_error')}}
                            </div>
                            <span class="text-danger">
                                @error('content')
                                    {{ $message }}
                                @enderror
                            </span>
                        </div>
                    </div>
                    <div class="mt-3 d-flex ">
                        <div class="col-lg-1 p-0">
                            <input type="submit" name="send" class="btn btn-primary" value="{{ __('common.submit')}}">
                        </div>
                        <div class="col-lg-1 p-0">
                        <a href="{{ route('enquiry.index')}}" class="btn btn-secondary mx-1">Cancel</a>
                        </div>
                    </div>
                </div>
            </div>
        </form><!-- form -->

      </div><!-- container -->
    </div>

    @push('scripts')
        <script type="text/javascript" src="{{asset('assets/js/ckeditor.js')}}"></script>
        <script>
            ClassicEditor
                .create(document.querySelector('#editor'))
                //ckeditor height code
                .then( editor => {
                    editor.editing.view.change( writer => {
                        writer.setStyle( 'height', '200px', editor.editing.view.document.getRoot() );
                    } );
                } )
                .catch(error => {
                    console.error(error);
                });
        </script>
        @endpush

        </x-app-layout>
