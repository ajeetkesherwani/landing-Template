<!--start add modal-->
<div class="modal fade" id="source_add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content tx-14">
            <div class="modal-header">
                <h6 class="modal-title" id="exampleModalLabel">{{
                    __('crm.add_lead_source') }}</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" id="source_add_userForm" class="needs-validation mg-b-0" novalidate>
                    @csrf
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label class="form-label">{{__('crm.source_name') }}<span
                                        class="text-danger">*</span></label>
                            <input name="source_name" id="addsource_name" type="text"
                                class="form-control"
                                placeholder="{{ __('crm.source_name_placeholder') }}"
                                required>
                            <span class="text-danger">
                                @error('source_name')
                                {{ $message }}
                                @enderror
                            </span>
                            <div class="invalid-feedback">
                                {{ __('crm.source_name_error') }}
                            </div>
                        </div>
                    </div>
                    <input type="submit" id="Add_Source_Submit" name="send" class="btn btn-primary" value="{{ __('common.submit') }}">
                </form>
            </div>
        </div>
    </div>
</div>
<!--end add modal-->







<!-- MOdal start -->
<div class="modal fade" id="status_add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content tx-14">
            <div class="modal-header">
                <h6 class="modal-title" id="exampleModalLabel">{{
                    __('crm.add_lead_status') }}</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" id="status_add_userForm" class="needs-validation mg-b-0" novalidate>
                    @csrf
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label class="form-label">{{ __('crm.status_name')}}<span class="text-danger">*</span></label>
                            <input name="status_name" id="addstatus_name"
                            type="text" class="form-control"  placeholder="{{ __('crm.status_name_placeholder') }}"  required>
                            <span class="text-danger">
                                @error('status_name')
                                {{ $message }}
                                @enderror
                            </span>
                            <div class="invalid-feedback">
                                {{ __('crm.status_name_error') }}
                            </div>
                        </div>
                    </div>
                    <input type="submit" id="Add_status_submit" name="send"
                     class="btn btn-primary"  value="{{ __('common.submit') }}">
                </form>
            </div>
        </div>
    </div>
</div>
<!-- modal store end -->


>


 <!--  start modal store -->
<div class="modal fade" id="industry_add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content tx-14">
            <div class="modal-header">
                <h6 class="modal-title" id="exampleModalLabel">{{
                    __('crm.add_lead_industry') }}</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" id="industry_add_userForm" class="needs-validation mg-b-0" novalidate>
                    @csrf
                    
                    <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label class="form-label">{{ __('crm.industry_name')
                                    }}<span class="text-danger">*</span></label>
                            <input name="industry_name" id="add_industry_name" type="text" class="form-control" placeholder="{{ __('crm.industry_name_placeholder') }}" required>
                            <span class="text-danger">
                                @error('industry_name')
                                {{ $message }}
                                @enderror
                            </span>
                            <div class="invalid-feedback">
                                {{ __('crm.industry_name_error') }}
                            </div>
                        </div>
                    </div>
                    <input type="submit" id="industry_submit" name="send"
                     class="btn btn-primary" value="{{ __('common.submit') }}">
                </form>
            </div>
        </div>
    </div>
</div>
<!-- modal store end -->



<x-app-layout>

<nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500"> 
            <li class="breadcrumb-item"><a href="#" class="text-dark tx-16">Dashboard</a></li>
        </ol>
    </nav>

<div class="contact-content">
    <div class="contact-content-header mg-b-20 mg-lg-b-25 mg-xl-b-30">
        <ul class="nav nav-line" role="tablist">
            <li class="nav-item"><a href="#lead-source" class="nav-link active" data-toggle="tab">{{ __('crm.lead_source')}}</a></li>
            <li class="nav-item"><a href="#lead-status" class="nav-link" data-toggle="tab">{{ __('crm.lead_status')}}</a></li>
            <li class="nav-item"><a href="#lead-industry" class="nav-link" data-toggle="tab">{{ __('crm.lead_industry') }}</a></li>
        </ul>

    </div>
    <div class="card contact-content-body">
        <div class="tab-content">
            <div id="lead-source" class="tab-pane active">
                <div class="card-header">
                    <div class="d-flex align-items-center justify-content-between">
                        <h6 class="tx-15 mg-b-0">{{ __('crm.lead_source_list') }}</h6>
                        <a href="#source_add" data-toggle="modal" class="btn btn-sm btn-bg d-flex align-items-center"><i data-feather="plus"></i><span class="d-none d-sm-inline mg-l-5">{{ __('crm.add_lead_source')}}</span></a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table border table_wrapper">
                            <thead>
                                <tr>
                                    <th>{{__('common.sl_no')}}</th>
                                    <th>{{__('crm.source_name') }}</th>
                                    <th>{{__('common.status') }}</th>
                                    <th class="text-center wd-10p">{{__('common.action')}}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (!empty($source_list))
                                @foreach ($source_list->data as $key => $source)
                                <tr>
                                    <td>{{ $key + 1 }}</td>
                                    <td>{{ $source->source_name }}</td>
                                    <td>
                                       

                                    <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input source_toggle_class" {{ $source->status == '1' ? 'checked' : '' }} data-id="{{$source->source_id}}" id="customSwitch{{$source->source_id}}">
                                                <label class="custom-control-label" for="customSwitch{{$source->source_id}}"></label>
                                            </div>
                                    </td>
                                    <td class="d-flex align-items-center justify-content-between">
                                       

                                        <a href="#modalEditResult" data-id="{{$source->source_id}}" data-toggle="modal" class="btn btn-sm btn-white d-flex align-items-center mg-r-5 result_edit_btn"><i data-feather="edit-2"></i><span class="d-none d-sm-inline mg-l-5"></span></a>



                                    </td>

                                </tr>
                                @endforeach
                               
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div id="lead-status" class="tab-pane">
                <div class="card-header">
                    <div class="d-flex align-items-center justify-content-between">
                        <h6 class="tx-15 mg-b-0">{{ __('crm.lead_status_list') }}</h6>
                        <a href="#status_add" data-toggle="modal" class="btn btn-sm btn-bg d-flex align-items-center"><i data-feather="plus"></i><span class="d-none d-sm-inline mg-l-5">{{ __('crm.add_lead_status') }}</span></a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table border table_wrapper">
                            <thead>
                                <tr>
                                    <th>{{ __('common.sl_no')}}</th>
                                    <th>{{__('crm.status_name') }}</th>
                                    <th>{{__('common.status')}}</th>
                                    <th class="text-center wd-10p">{{ __('common.action') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (!empty($status_list))
                                @foreach ($status_list->data as $key => $status)
                                <tr>
                                    <td>{{ $key + 1 }}</td>
                                    <td>{{ $status->status_name }}</td>
                                    <td>
                                    <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input status_toggle_class" {{ $status->status == '1' ? 'checked' : '' }} data-id="{{$status->status_id}}" id="customSwitch{{$status->status_id}}">
                                                <label class="custom-control-label" for="customSwitch{{$status->status_id}}"></label>
                                            </div>
                                    </td>
                                    <td>

                                    <a href="#modalEditStatus" data-id="{{$status->status_id}}" data-toggle="modal" class="btn btn-sm btn-white d-flex align-items-center mg-r-5 status_edit_btn"><i data-feather="edit-2"></i><span class="d-none d-sm-inline mg-l-5"></span></a>
                                    </td>
                                </tr>
                                @endforeach
                              
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div id="lead-industry" class="tab-pane">
                <div class="card-header">
                    <div class="d-flex align-items-center justify-content-between">
                        <h6 class="tx-15 mg-b-0">{{ __('crm.lead_industry_list') }}</h6>
                        <a href="#industry_add" data-toggle="modal" class="btn btn-sm btn-bg d-flex align-items-center"><i data-feather="plus"></i><span class="d-none d-sm-inline mg-l-5">{{ __('crm.add_lead_industry') }}</span></a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table border table_wrapper">
                            <thead>
                                <tr>
                                    <th>{{__('common.sl_no')}}</th>
                                    <th>{{__('crm.industry_name')}}</th>
                                    <th>{{__('common.status')}}</th>
                                    <th class="text-center wd-10p">{{__('common.action') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (!empty($industry_list))
                                @foreach ($industry_list->data as $key => $industry)
                                <tr>
                                    <td>{{ $key + 1 }}</td>
                                    <td>{{ $industry->industry_name }}</td>
                                    <td>
                                    <div class="custom-control custom-switch">
                                                <input type="checkbox" class="custom-control-input industry_toggle_class" {{ $industry->status == '1' ? 'checked' : '' }} data-id="{{$industry->industry_id}}" id="customSwitch{{$industry->industry_id}}">
                                                <label class="custom-control-label" for="customSwitch{{$industry->industry_id}}"></label>
                                            </div>
                                    </td>
                                    <td>

                                    <a href="#modalindusrtyStatus" data-id="{{$industry->industry_id}}" data-toggle="modal" class="btn btn-sm btn-white d-flex align-items-center mg-r-5 indusrty_edit_btn"><i data-feather="edit-2"></i><span class="d-none d-sm-inline mg-l-5"></span></a>


                                        
                                    </td>
                                </tr>
                                @endforeach
                             
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




     <!-------------- Edit source Modal --------------->
     <div class="modal fade" id="modalEditResult" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                  <h6 class="modal-title" id="exampleModalLabel">{{ __('crm.update_lead_source') }}</h6>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation novalidate" id="edit_result_title_form" novalidate>
                        <input type="hidden" name="input_field_id" id="edit_input_field">
                        <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label class="form-label">{{__('crm.source_name') }}<span
                                        class="text-danger">*</span></label>
                            <input name="source_name" id="editsource_name" type="text"
                            class="form-control" placeholder="{{ __('crm.source_name_placeholder') }}" required>
                            <span class="text-danger">
                                @error('source_name')
                                {{ $message }}
                                @enderror
                            </span>
                            <div class="invalid-feedback">
                                {{ __('crm.source_name_error') }}
                            </div>
                        </div>
                    </div>
                       
                        <div class="row">
                            <div class="col-sm-12 mt-4" required>
                                <input type="submit" id="add_title_submit" class="btn btn-primary" value="Update">
                            </div>
                        </div>
                    </form>
                </div>
           
            </div>
        </div>
    </div>
    <!--------------Edit source Modal end here --------------->


        <!-------------- Edit status Modal --------------->
        <div class="modal fade" id="modalEditStatus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                  <h6 class="modal-title" id="exampleModalLabel">{{ __('crm.update_lead_ststus') }}</h6>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation novalidate" id="edit_status_title_form" novalidate>
                       
                        <input name="source_id" id="hidden_status_id" type="hidden"
                        class="form-control">
                        <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label class="form-label">{{ __('crm.status_name')
                                    }}<span class="text-danger">*</span></label>
                            <input name="status_name" id="edit_status_name"
                            type="text" class="form-control" placeholder="{{ __('crm.status_name_placeholder') }}" required>
                            <span class="text-danger">
                                @error('status_name')
                                {{ $message }}
                                @enderror
                            </span>
                            <div class="invalid-feedback">
                                {{ __('crm.status_name_error') }}
                            </div>
                        </div>
                    </div>
                       
                        <div class="row">
                            <div class="col-sm-12 mt-4" required>
                                <input type="submit" id="add_title_submit" class="btn btn-primary" value="Update">
                            </div>
                        </div>
                    </form>
                </div>
           
            </div>
        </div>
    </div>
    <!--------------Edit status Modal end here --------------->



            <!-------------- Edit industry Modal --------------->
            <div class="modal fade" id="modalindusrtyStatus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                  <h6 class="modal-title" id="exampleModalLabel">{{ __('crm.update_lead_industry') }}</h6>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <form class="needs-validation novalidate" id="edit_industry_title_form" novalidate>
                       
                    <input name="industry_id" id="hidden_industry_id" type="hidden"
                        class="form-control ps-5">
                        <div class="form-row">
                        <div class="form-group col-lg-12">
                            <label class="form-label">{{ __('crm.industry_name')
                                    }}<span class="text-danger">*</span></label>
                            <input name="industry_name" id="edit_industry_name" type="text" class="form-control" placeholder="{{ __('crm.industry_name_placeholder') }}" required>
                            <span class="text-danger">
                                @error('industry_name')
                                {{ $message }}
                                @enderror
                            </span>
                            <div class="invalid-feedback">
                                {{ __('crm.industry_name_error') }}
                            </div>
                        </div>
                    </div>
                       
                        <div class="row">
                            <div class="col-sm-12 mt-4" required>
                                <input type="submit" id="add_title_submit" class="btn btn-primary" value="Update">
                            </div>
                        </div>
                    </form>
                </div>
           
            </div>
        </div>
    </div>
    <!--------------Edit industry Modal end here --------------->





@push('scripts')



<script>
    $(document).ready(function() {
            // add source ajax open
        $(document).on('click', "#Add_Source_Submit", function(e){
        e.preventDefault();
        $('#source_add_userForm').addClass('was-validated');
        if ($('#source_add_userForm')[0].checkValidity() === false) {
            event.stopPropagation();
        } else { 
            var data = {
                source_name: $("#addsource_name").val(),
            };
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "{{ route('lead-setting.store') }}",
                data: data,
                dataType: "json",

                success: function(response) {
                    // console.log(response);

                           // toaster
                           Toaster(response.success);
                    // $('#source_add').modal('hide');
                    // $('#source_add_userForm').trigger('reset')
                    // $("#source_id").load(location.href + " #source_id");
                    // $('.flash-message').fadeOut(3000, function() {
                    //     location.reload(true);
                    // });

                    $('#add_modal').trigger("reset");
                    $('#source_add').modal('hide')
                },
                error: function(response) {
                    var errors = data.responseJSON;
                    console.log(errors);
                }
            });
        }
        });
    });
       


  //Lead souce status change jquery
  $('.source_toggle_class').change(function () {
                let status = $(this).prop('checked') === true ? 1 : 0;
                let source_id = $(this).data('id');
                console.log(source_id);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "{{ url('lead-setting-source') }}",
                    data: { 'status': status, 'source_id': source_id },
                    success: function (response) {
                    // console.log(response);
                    Toaster(response.success);
                    }
                });
            });
       //end


      
</script> 




        <script>
        //modal edit source ajax
        $(document).ready(function() {
                 $('.result_edit_btn').on('click',function (e) {
                e.preventDefault();
             
                var source_id =  $(this).data('id');
               console.log(source_id);

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "GET",

                    url: "{{url('lead-source-edit')}}/"+source_id,
                    data: {source_id:source_id},
                    dataType: "json",
                    success: function (response) {
                        console.log(response);
                        var sec = response[0].source;
                        console.log(sec);

                            $("#edit_input_field").val(sec.source_id);
                            $("#editsource_name").val(sec.source_name);
                          
                     
                    },
                    error: function(data) {
                        var errors = data.responseJSON;
                        console.log(errors);
                    }
                });
            });
        });
       
    //   Edit source closed ajax
    </script>


<script>
    //source update 
        $(document).ready(function(){
           
            $(document).on("submit", "#edit_result_title_form",function(e){
                e.preventDefault();
               
                var data = {
                     id: $("#edit_input_field").val(),
                   
                     source_name: $("#editsource_name").val(),
                    
                }
                console.log(data);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{url('lead-setting-update')}}",
             
                    // url: "{{route('seo-results-update')}}",
                    data: data,
                    success: function (response) {
                        $('#modalEditResult').removeClass('show');
                        $('#modalEditResult').css('display','none');
                        Toaster(response.success);
                        setTimeout(function() {
                            location.reload(true);
                        }, 3000);
                       
                       
                    }
                });
               
            });
        });
    </script>





<!-- 1tab source closed -->

<!--  2tab status ajax open  -->
<script>
    $(document).ready(function() {
            $("#status_add_modal").on('click', function(e) {
                e.preventDefault();
                $("#status_add").modal('show');
            });
        });
</script>

<script>
    // modal add in ajax

        $(document).ready(function() {
            $(document).on("click","#Add_status_submit",function(e) {
            e.preventDefault();
            $('#status_add_userForm').addClass('was-validated');
            if ($('#status_add_userForm')[0].checkValidity() === false) {
                event.stopPropagation();
            } else { 
                var data = {
                    status_name: $("#addstatus_name").val(),
                };
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('lead-setting-store-status') }}",
                    data: data,
                    dataType: "json",
                    success: function(response) {
                      
                        // toaster
                    Toaster(response.success);
                    $('#status_add').modal('hide');
                    $('#status_add_userForm').trigger('reset')
                    $("#store_status_id").load(location.href + " #store_status_id");
                    $('.flash-message').fadeOut(3000, function() {
                        location.reload(true);
                    });
                        // location.reload();
                        // console.log(response);
                        // Toaster('Status Name Added ');

                    },
                    error: function(response) {
                        var errors = data.responseJSON;
                        console.log(errors);
                    }
                });
            }
            });
        });
        //  modal add closed ajax
      


     // change status in ajax code start
  $('.status_toggle_class').change(function () {
                let status = $(this).prop('checked') === true ? 1 : 0;
                let status_id = $(this).data('id');
                console.log(status_id);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "{{ url('lead-setting-status') }}",
                    data: { 'status': status, 'status_id': status_id },
                    success: function (response) {
                    // console.log(response);
                    Toaster(response.success);
                    }
                });
            });
       // change status in ajax code end


</script> 


<script>
        //modal edit status ajax
        $(document).ready(function() {
                 $('.status_edit_btn').on('click',function (e) {
                e.preventDefault();
             
                var status_id =  $(this).data('id');
               console.log(status_id);

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "GET",

                    url: "{{url('lead-status-edit')}}/"+status_id,
                    data: {status_id:status_id},
                    dataType: "json",
                    success: function (response) {
                        console.log(response);
                        var sec = response[0].status;
                        console.log(sec);

                            $("#hidden_status_id").val(sec.status_id);
                            $("#edit_status_name").val(sec.status_name);
                          
                     
                    },
                    error: function(data) {
                        var errors = data.responseJSON;
                        console.log(errors);
                    }
                });
            });
        });
       
    //   Edit status closed ajax
    </script>


<script>
    //status update 
        $(document).ready(function(){
           
            $(document).on("submit", "#edit_status_title_form",function(e){
                e.preventDefault();
               
                var data = {
                     id: $("#hidden_status_id").val(),
                   
                     status_name: $("#edit_status_name").val(),
                    
                }
                console.log(data);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{url('lead-setting-update-status')}}",
             
                    // url: "{{route('seo-results-update')}}",
                    data: data,
                    success: function (response) {
                        $('#modalEditStatus').removeClass('show');
                        $('#modalEditStatus').css('display','none');
                        Toaster(response.success);
                        setTimeout(function() {
                            location.reload(true);
                        }, 3000);
                       
                       
                    }
                });
               
            });
        });
    </script>





<!-- 2tab status closed -->

<!-- 3tab Industry open in jquery-->
<script>
    $(document).ready(function() {
            $("#industry_add_modal").on('click', function(e) {
                e.preventDefault();
                $("#industry_add").modal('show');
            });
        });
</script><!-- 3tab Industry closed in jquery-->

<!-- 3tab Industry openin ajax -->
<script>
    // modal add industry open ajax
        $(document).ready(function() {
            $(document).submit("#industry_submit",function(e) {
                e.preventDefault();
            $('#industry_add_userForm').addClass('was-validated');
            if ($('#industry_add_userForm')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                var data = {
                    industry_name: $("#add_industry_name").val(),
                };
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{ url('lead-setting-store-industry') }}",
                    data: data,
                    dataType: "json",
                    success: function(response) {
                        // $('#industry_add_modal').trigger("reset");
                        Toaster(response.success);
                        $('#industry_add').modal('hide');
                        $('#industry_add_userForm').trigger('reset')
                        $("#industry_table").load(location.href + " #industry_table");
                        $('.flash-message').fadeOut(3000, function() {
                            location.reload(true);
                        });



                    },
                    error: function(response) {
                        var errors = data.responseJSON;
                        console.log(errors);
                    }
                });
            }
            });
        });
        //  modal add industry closed ajax


           // change status in ajax code start
       $('.industry_toggle_class').change(function () {
                let status = $(this).prop('checked') === true ? 1 : 0;
                let industry_id = $(this).data('id');
                console.log(industry_id);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "{{ url('lead-setting-industry') }}",
                    data: { 'status': status, 'industry_id': industry_id },
                    success: function (response) {
                    // console.log(response);
                    Toaster(response.success);
                    }
                });
            });
       // change status in ajax code end

</script>




<script>
        //modal industry status ajax
        $(document).ready(function() {
                 $('.indusrty_edit_btn').on('click',function (e) {
                e.preventDefault();
             
                var industry_id =  $(this).data('id');
               console.log(industry_id);

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "GET",

                    url: "{{url('lead-industry-edit')}}/"+industry_id,
                    data: {industry_id:industry_id},
                    dataType: "json",
                    success: function (response) {
                        console.log(response);
                        var sec = response[0].industry;
                        console.log(sec);

                            $("#hidden_industry_id").val(sec.industry_id);
                            $("#edit_industry_name").val(sec.industry_name);
                          
                     
                    },
                    error: function(data) {
                        var errors = data.responseJSON;
                        console.log(errors);
                    }
                });
            });
        });
       
    //   Edit industry closed ajax
    </script>


<script>
    //industry update 
        $(document).ready(function(){
           
            $(document).on("submit", "#edit_industry_title_form",function(e){
                e.preventDefault();
               
                var data = {
                     id: $("#hidden_industry_id").val(),
                   
                     industry_name: $("#edit_industry_name").val(),
                    
                }
                console.log(data);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url: "{{url('lead-setting-update-industry')}}",
             
                    // url: "{{route('seo-results-update')}}",
                    data: data,
                    success: function (response) {
                        $('#modalindusrtyStatus').removeClass('show');
                        $('#modalindusrtyStatus').css('display','none');
                        Toaster(response.success);
                        setTimeout(function() {
                            location.reload(true);
                        }, 3000);
                       
                       
                    }
                });
               
            });
        });
    </script>







@endpush
{{-- 3tab Industry closed ajax --}}
</x-app-layout>