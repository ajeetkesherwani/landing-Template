<x-app-layout>
<div class="card contact-content-body">
    <div class="card-header">
        <div class="d-flex align-items-center justify-content-between">
            <h6 class="tx-15 mg-b-0">{{ __('crm.customer_list') }}</h6>
            <a href="{{route('customer.create')}}" class="btn btn-sm btn-bg"><i data-feather="plus"></i>{{ __('crm.add_customer') }}</a>
        </div>
    </div>
    <div class="card-body">
        <div class="form-row">
            <div class="form-group col-2 col-lg-1 col-sm-3">
                <select class="form-control">
                    <option>10</option>
                    <option>20</option>
                    <option>30</option>
                    <option>40</option>
                    <option>50</option>
                </select>
            </div>
            <div class="form-group mg-l-5">
                <input type="text" class="form-control" id="searchbar" placeholder="Search">
            </div>
        </div>
        <div class="table-responsive">
            <table class="table border table_wrapper">
                <thead>
                    <tr>
                        <th >{{__('common.sl_no')}}</th>
                     
                     
                        <th>{{__('crm.customer_name')}}</th>
                        <th>{{__('crm.email')}}</th>
                        <th>{{__('crm.contact')}}</th>
                        <th class="wd-10p text-center">{{__('common.action')}}</th>
                    </tr>
                </thead>
                <tbody>
                @if(!empty($customer_list))
                @foreach($customer_list as $key=>$customer)
                    <tr>
                        <td>{{$key+1}}</td>
                        <td>{{$customer->first_name}}</td>
                        <td>{{$customer->email}}</td>
                        <td>{{$customer->contact}}</td>
                        <td >
                            <a href="{{ route('customer.edit',$customer->customer_id) }}" class="btn btn-sm btn-white"><i data-feather="edit-2"></i></a>
                            
                        </td>
                    </tr>
                @endforeach
                @endif
              
                </tbody>
            </table> 
        </div>
    </div>
</div>


        <!--start delete modal-->
<div class="modal fade" id="delete_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Delete Customer</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
        </div>
        <div class="modal-body">
            <h5>Are you sure want to delete ?</h5>
            <input type="hidden" id="delete_department_id" name="input_field_id">
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">NO</button>
            <button type="submit" class="btn btn-primary delete_submit_btn">Yes</button>
        </div>
    </div>
</div>
</div>
<!--end delete modal-->
    @push('scripts')
    <script>
        $(document).ready(function() {

            $(document).on("click", "#delete_btn", function() {
                var customer_id = $(this).val();
                $('#delete_department_id').val(customer_id);
                $('#delete_modal').modal('show');
            });
            $(document).on('click', '.delete_submit_btn', function() {
                var customer_id = $('#delete_department_id').val();

                $('#delete_modal').modal('show');

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                 
                $.ajax({
                    type: "POST",
                    // url: "{{ url('departmentDestroy') }}/" + department_id,
                    url : "{{ url('customer')}}/"+customer_id,
                    data: {
                        customer_id: customer_id,
                        _method: 'DELETE'
                    },
                    dataType: "json",
                    success: function(response) {
                        Toaster(response.success);
                        $('#delete_modal').modal('hide');
                        $('.flash-message').html(response.success);
                        $('.flash-message').addClass('alert alert-success');
                        $('#department_edit').modal('hide');
                        $("#customer_table").load(location.href + " #customer_table");
                        
                        $('.flash-message').fadeOut(3000, function() {
                            location.reload(true);
                        });
                    }
                });

            });
        });
    </script>
    <!--end delete ajax-->

    <script>
        //searchbar ajax
    $(document).ready(function(){
      $("#searchbar").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#table tr").filter(function() {
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
      });
    });
  });

    </script>
    @endpush
</x-app-layout>