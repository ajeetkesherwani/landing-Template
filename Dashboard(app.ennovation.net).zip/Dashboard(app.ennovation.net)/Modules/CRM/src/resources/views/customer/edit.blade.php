<x-app-layout>
    <div class="contact-content">
        <div class="layout-specing">
            <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent px-0">
                    <li class="breadcrumb-item"><a href="{{ route('customer.index')}}">{{__('crm.customers')}}</a></li>
                   
                </ol>
            </nav>
            <div class="card contact-content-body">
                <form action="{{route('customer.update',$customer->customer_id)}}" id="userForm"  method="post" class="needs-validation" novalidate>
                @csrf
                    @method('PUT')
                    <div class="card-header d-flex align-items-center justify-content-between py-2 px-3">
                        <h6 class="tx-15 mg-b-0">{{ __('crm.edit_customer') }}</h6>
                        
                    </div>
                    <div class="card-body">
                        <div data-label="Example" class="df-example demo-forms">
                        <fieldset class="form-fieldset">
                         <legend>{{ __('crm.primary_contact_info') }}</legend>
                            <div class="form-row">
                            <div class="form-group col-md-4 col-4">
                        <label class="form-label">{{__('crm.lead')}}</label>
                        <select  class="form-control selectsearch @error('lead_id') is-invalid @enderror " name="lead_id" required="">
                        <option selected disabled value="" disabled>{{ __('crm.lead_select')}}</option>
                                       
                                       @foreach ($lead_list as $lead)
                               <option value="@if(!empty($lead)){{ $lead->lead_id }}@endif" {{$customer->lead_id == $lead->lead_id ? 'selected' : '' }}>{{ $lead->contact_name }}</option>
                               @endforeach
                                 
                                </select>
                          
                            <div class="invalid-feedback">
                                {{ __('crm.source_error') }}
                                </div>
                        </div>

                        <div class="form-group col-lg-4 col-md-4 col-sm-4">
                <label class="form-label">{{ __('crm.gender')}}</label>
                <select  class="form-control selectsearch @error('lead_id') is-invalid @enderror " name="gender" id="gender" >
                                    <option selected disable value="" disabled>{{ __('crm.gender_select')}}</option>
                                    <option  value="1" {{  ($customer->gender == '1') ? 'selected' : '' }}>Male</option>
                                    <option  value="2" {{  ($customer->gender == '2') ? 'selected' : '' }}>Female</option>
                                    <option  value="3" {{  ($customer->gender == '3') ? 'selected' : '' }}>Other</option>
                                   
                                </select>
                <div class="invalid-feedback">
                {{ __('crm.gender_select')}} 
                </div>
            </div>


            <div class="form-group col-lg-4 col-md-4  col-sm-4">
                <label class="form-label">Date Of Birth</label>
                <input type="date" id="datepicker1" value="{{ $customer->date_of_birth}}" name="date_of_birth" class="form-control">
            </div> 



            <div class="form-group col-md-4 col-4">
                        <label class="form-label">{{ __('crm.customer_name')}} <span class="text-danger mg-l-5">*</span></label>
                        <input type="text" class="form-control" value="@if(!empty($customer)){{$customer->first_name}}@endif" id="customer_name" name="customer_name" placeholder="{{ __('crm.customer_name_placeholder')}}"  required="">
                                
                                <div class="invalid-feedback">
                                {{ __('crm.customer_name_error')}}
                                </div>
                        </div>
                        <div class="form-group col-md-4 col-4">
                        <label class="form-label">{{ __('crm.email')}} <span class="text-danger mg-l-5">*</span></label>
                        <input type="email" class="form-control" value="@if(!empty($customer)){{$customer->email}}@endif" id="customer_email" placeholder="{{ __('crm.customer_email_placeholder')}}" name="customer_email"  required="">
                            <div class="invalid-feedback">
                            {{ __('crm.customer_emial_error')}}
                            </div>
                        </div>
                   
                    <div class="form-group col-md-4 col-4">
                        <label class="form-label">{{ __('crm.contact_phone') }} <span class="text-danger mg-l-5">*</span></label>
                        <input type="text" class="form-control" placeholder="{{ __('crm.phone_placeholder')}}" name="contact"  value="@if(!empty($customer)){{$customer->contact}}@endif" required>
                            <div class="invalid-feedback">
                            {{ __('crm.contact_name_error') }}
                            </div>
                        </div>
                 

                
                        <div class="form-group col-md-4 col-4">
                <label class="form-label">{{ __('crm.website')}}</label>
                <input type="text" class="form-control" value="@if(!empty($customer)){{$customer->website}}@endif" id="website" name="website" placeholder="{{ __('crm.website_placeholder')}}" >
                <div class="invalid-feedback">
                {{ __('crm.website_error')}}
                </div>
            </div>
            <div class="form-group col-md-4 col-4">
                <label class="form-label">{{ __('crm.company_name')}}</label>
                <input type="text" class="form-control" value="@if(!empty($customer)){{$customer->company_name}}@endif" id="company_name" name="company_name" placeholder="{{ __('crm.company_name_placeholder')}}" value="" >
                <div class="invalid-feedback">
                {{ __('crm.company_name_error')}} 
                </div>
            </div>

                              
                            </div>
                            </fieldset>

                        </div>
                    </div>
                       
                    <div class="card-body">
                        <div data-label="Example" class="df-example demo-forms">
                        <fieldset class="form-fieldset">
                         <legend>{{ __('crm.address_info') }}</legend>
                            <div class="form-row">
                            @if(!empty($customer->crm_customer_address))
                                    @foreach ($customer->crm_customer_address as $iData)
                                    @php
                                                $address =$iData ;
                                             
                                                @endphp
                                                @endforeach
                                @endif


                            <div class="form-group col-lg-4 col-md-4 col-sm-4">
                    <label class="form-label">{{ __('crm.street_address')}}</label>
                    <input type="text" class="form-control" value="@if(!empty($address->street_address)){{$address->street_address}}@endif" id="street_address" name="street_address" placeholder="{{ __('crm.street_address_placeholder')}}" value="" required>
                    <div class="invalid-feedback">
                    {{ __('crm.street_address_error')}}
                    </div> 
                </div>

                <div class="form-group col-lg-4 col-md-4 col-sm-4">
                    <label class="form-label">{{ __('crm.city')}}</label>
                    <input type="text" class="form-control" id="city" value="@if(!empty($address->city)){{$address->city}}@endif" name="city" placeholder="{{ __('crm.city_placeholder')}}" required>
                    <div class="invalid-feedback">
                    {{ __('crm.city_error')}} 
                    </div>
                </div> 

                <div class="form-group col-lg-4 col-md-4 col-sm-4">
                     <label class="form-label">{{ __('crm.state')}}</label>
                     <input type="text" class="form-control" value="@if(!empty($address->state)){{$address->state}}@endif" id="state" name="state" placeholder="{{ __('crm.state_placeholder')}}" required>
                    <div class="invalid-feedback">
                    {{ __('crm.state_error')}}
                    </div> 
                </div> 



                <div class="form-group col-lg-4 col-md-4 col-sm-4">
                    <label class="form-label">{{ __('crm.country')}}<span class="text-danger mg-l-5">*</span></label>
                    <select name="countries_id" class="form-control selectsearch @error('countries_id') is-invalid @enderror " name="countries_id" required>
                    <option selected disable value="" disabled>{{ __('crm.country_select')}}</option>
                                    @foreach ($country_list as $countries)
                                    <option value="{{ $countries->countries_id }}" @if(!empty($address->countries_id)){{$address->countries_id == $countries->countries_id ? 'selected' : ''}}
                                    @endif >{{ $countries->countries_name }}</option>
                                    @endforeach
                      </select>

                    
                    <div class="invalid-feedback">
                    {{ __('crm.country_select')}}
                    </div>
                </div>

                        <div class="form-group col-lg-4 col-md-4 col-sm-4">
                    <label class="form-label">{{ __('crm.zip')}}<span class="text-danger mg-l-5">*</span></label>
                    <input type="text" class="form-control" value="@if(!empty($address->zipcode)){{$address->zipcode}}@endif" id="zip_code" name="zip_code" placeholder="{{ __('crm.zip_placeholder')}}" required>
                    <div class="invalid-feedback">
                    {{ __('crm.zip_error')}}
                    </div>
                </div>     
                 

                
                        <div class="form-group col-lg-4 col-md-4 col-sm-4">
                    <label class="form-label">Phone</label>
                    <input type="number" class="form-control"  value="@if(!empty($address->phone)){{$address->phone}}@endif " name="phone" placeholder="Phone">
                   
                </div>

                              
                            </div>
                            </fieldset>

                        </div>
                    </div>
                    
                    <div class="">
                        <div class="col-sm-12 mb-3 mx-3 p-0">
                            <input type="submit" id="submit" name="send" class="btn btn-primary" value="Update">
                            <a href="{{ route('customer.index')}}" class="btn btn-secondary mx-1">Cancel</a>
                        </div><!--end col-->
                    </div><!--end row-->
                </form>
            </div>
        </div>
    </div>
    @push('scripts')
    <script>
        $( function() {
            $('.datepicker1').datepicker({
                dateFormat: 'dd-mm-yy',
                onSelect: function(){
            var selected = $(this).datepicker("getDate");
        }
            });
             
        } );
    </script>  


    <script type="text/javascript">
       $('.selectsearch').select2({
          searchInputPlaceholder: 'Search options'
        });
        </script>

    @endpush
</x-app-layout>