<x-app-layout>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500"> 
            <li class="breadcrumb-item"><a href="#" class="text-dark tx-16">Dashboard</a></li>
        </ol>
    </nav>
   
    <div class="row px-2">
   
    @if (!empty($lead_list))
    @foreach ($lead_list as $key => $tab)
        <div class="col-lg-3 col-6 col-md-4 p-2">
            <div class="border rounded px-3 p-2">
                <a href="" class="align-items-center">
                
                    <h6>{{$tab->statusName}}</h6>
                    <h4 class="text-dark fw-bold">{{ $tab->total}}</h4>
                    <span class="text-dark">{{ __('crm.total') }}</span>
                </a> 
            </div>
        </div>  
        @endforeach
     @endif 
    </div>


    <div class="card mt-3">
        <div class="tab-content">
            <div class="card-header d-flex align-items-center justify-content-between py-2 px-3">
                <h5 class="tx-15 mb-0">{{ __('crm.lead_list') }}</h5>
                <div class="d-flex gap-1">
                    <a href="{{route('leads.create')}}">
                        <button class="btn btn-md  btn-primary "><i data-feather="plus" class="lead_icon mg-r-5"></i>{{__('user-manager.add_user')}}</button>
                    </a>
                    <a href="#">
                        <button class="btn btn-md  btn-primary "><i data-feather="plus" class="lead_icon mg-r-5"></i>{{ __('crm.import_modal') }}</button>
                    </a>
                    <!-- <a href="#">
                        <button class="btn btn-md  btn-primary "><i data-feather="plus" class="lead_icon mg-r-5"></i>{{ __('crm.send_mail') }}</button>
                    </a> -->
                </div>
            </div>
            <div class="card-body">
                <div class="row align-item-center mb-3">
                    <div class="col-lg-2 col-md-3 col-4">
                        <select class="form-control form-select" aria-label="Default select example">
                            <option>10</option>
                        </select>
                    </div>
                    <div class="col-6 col-md-4 col-md-3 col-8"><input type="text" id="Search" class="form-control col-lg-4 fas fa-search" placeholder="Search..." name="search" aria-label="Search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table border table_wrapper rounded px-3">
                        <thead>
                            <tr>
                                <th class="border-bottom" style="min-width:70px;">{{__('common.sl_no')}}</th>
                                <th class="border-bottom" style="min-width: 150px;">{{
                                    __('crm.industry_type') }}</th>

                              <th class="border-bottom" style="min-width: 150px;">{{
                                    __('crm.contact_details') }}</th>    
                                <th class="border-bottom" style="min-width: 150px;">{{
                                    __('crm.priority') }}</th>
                                <th class="border-bottom" style="min-width: 150px;">{{
                                    __('crm.follow_up') }}</th>
                                <th class="border-bottom" style="min-width: 150px;">{{
                                    __('crm.follow_date') }}</th>
                                <th class="border-bottom" style="min-width: 100px;">{{
                                    __('crm.follow_up_status') }}</th>
                                <th class="text-center border-bottom" style="min-width: 70px;">{{__('common.action')}}
                                </th>
                            </tr>
                        </thead>
                        <tbody id="Search_Tr">
                        @if (!empty($lead_list))
                      
                                @foreach ($lead_list as $key => $leads)
                            <tr>
                                <td>{{ $key + 1 }}</td>
                                <td>{{$leads->industry_id}}</td>
                                <td><p>{{$leads->contact_name}}</p>
                                <p>{{$leads->contact_email}}</p>
                                <p>{{$leads->phone}}</p>
                                 </td>
                                <td>{{$leads->priority}}</td>
                                <td>{{$leads->folllow_up}}</td>
                                <td>{{$leads->folloup_date}}</td>
                                <td>
                                <div class="custom-control custom-switch">

                                <select class="form-select form-control follow_status" id="customSwitch" name="status_name" data-id="{{$leads->lead_id}}>
                                 @if(!empty($leadstatus))
                                    @foreach ($leadstatus as $status)
                                        <option value="{{ $status->status_id }}">
                                            {{ $status->status_name }}</option>
                                    @endforeach
                                @endif
                            </select>


                                    <!-- <input type="checkbox" class="custom-control-input toggle-class" id="customSwitch">
                                    <label class="custom-control-label" for="customSwitch"></label>
                                     -->
                                </div>
                                </td>
                                <td class="d-flex align-items-center gap-2 justify-content-center">
                                    <a href="{{ route('leads.edit',$leads->lead_id)}}" class="btn btn-sm btn-white table_btn py-1 px-2"><i data-feather="edit-2"></i></a>
                                    <a href="#delete_modal" id="deleteBtn" data-id=" "  data-toggle="modal" class="btn btn-sm btn-white py-1 px-2"><i data-feather="trash"></i></a>
                                </td>
                            </tr>
                            @endforeach
                            @endif
                           
                        </tbody>
                    </table>
                </div>
            </div>         
        </div><!--end row-->
    </div>
    <!--Lead delete modal start here-->
    <div class="modal fade effect-scale" id="delete_modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title">Delete Lead</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="deleteLeadId" name="input_field_id">
                    <p class="mg-b-0">{{ __('common.delete_confirmation') }}</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                    {{ __('common.no')}}
                    </button>
                    <button type="button" class="btn btn-primary deleteConfirmBtn">{{ __('common.yes') }}</button>
                </div>
            </div>
        </div>
    </div>
    <!--Lead delete modal end here-->
    @push('scripts')
    <script type="text/javascript">
        $(function(){
        $(".alert").delay(2000).fadeOut("slow");
        });
        
    </script>
    <script>
        $('.lead_id').on('keyup',function(){
            var data = $('.lead_id').val();
            alert(data);
});
$(".lead_id").keyup(function(){  
       alert("g");
    });
    </script>

    <script type="text/javascript">
        // change status in ajax code start
        $('.follow_status').change(function() {
            let status = $(this).val();
          //  var lead_id = $('.lead_id').val();
            var lead_id =  $(this).data('id');
            console.log(lead_id);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "{{ url('lead-followup') }}",
                data: {
                    status: status,
                    lead_id : lead_id
                },
                success: function(data) {
                    Toaster(' User Status Changed ');
                }
            });
        });
        // chenge status in ajax code end  
    </script>
    <script>
        $(document).ready(function() {

            $(document).on("click", "#deleteBtn", function() {
                var lead_id = $(this).val();
                $('#deleteLeadId').val(lead_id);
            });
            $(document).on('click', '.deleteConfirmBtn', function() {
                var lead_id = $('#deleteLeadId').val();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    url : "{{ url('leads')}}/"+lead_id,
                    data: {
                        lead_id: lead_id,
                        _method: 'DELETE'
                    },
                    dataType: "json",
                    success: function(response) {
                        Toaster(response.success);
                        $('.flash-message').html(response.success);
                        $('.flash-message').addClass('alert alert-success');
                        $('#department_edit').modal('hide');
                        $("#department").load(location.href + " #department");
                        
                        $('.flash-message').fadeOut(3000, function() {
                            location.reload(true);
                        });
                    }
                });

            });
        });
    </script>

    @endpush

</x-app-layout>