<?php

namespace Modules\CRM\Http\Controllers;
use App\Http\Controllers\Controller;


use Illuminate\Http\Request;

use App\Services\ApiService;
use App\Helper\Helper;




class EnquiryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      
        $parameters =array(
           
            "perPage" => "",
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",
        );

      //  $apiurl = config('apipath.lead-customer');
        $apiurl =  "https://e-nnovation.net/backend/public/api/enquiry";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
     //    dd( $responseData->data);

      return view('CRM::enquiry.index', collect($responseData->data));

      

       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
  

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        

        $parameters =array(
            "enquiry_id"=>$request->enquiry_id,
            
            "message"=>$request->message,
          
            
             
              );

          //    $apiurl = config('apipath.enquiry-store');
              $apiurl =  "https://e-nnovation.net/backend/public/api/enquiry/store";

              $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
             
          //  dd( $responseData);

         if ($responseData) {
            return redirect()->route('enquiry.index')->with('success',$responseData->message);
        } else {
            return redirect()->route('enquiry.index')->with('error',$responseData->message);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $parameters =array(
           
            "enquiry_id"=>$id,
           
        );

      //  $apiurl = config('apipath.lead-customer');
        $apiurl =  "https://e-nnovation.net/backend/public/api/enquiry/enquiry_details";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
      //   dd( $responseData->data);

      return view('CRM::enquiry.details', collect($responseData->data));

        

      //  return view('CRM::enquiry.details');

        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      



     
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         
      
     
    }

     /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        // if (Customer::find($id)->exists()) {
        // Customer::find($id)->delete();
        //     return response()->json(['success' => 'Customer Deleted Successfully']);
        // }else{
        //     return response()->json(['error' => 'Customer already deleted!']);
        // }
    }

    public function changeStatus(Request $request)
    {


        $parameters =array(
            "enquiry_id" =>$request->enquiry_id,
            "status" =>$request->status
         
          
           );
    
         //   $apiurl = config('apipath.enquiry-changeStatus');
            $apiurl =  "https://e-nnovation.net/backend/public/api/enquiry/changeStatus";
            $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
            // dd( $responseData->data);


            if (isset($responseData->message)) {
                return response()->json(['success' => $responseData->message]);
            } else {
                return response()->json(['success' => $responseData['message']]); 
            } 
          

          
    }

}

