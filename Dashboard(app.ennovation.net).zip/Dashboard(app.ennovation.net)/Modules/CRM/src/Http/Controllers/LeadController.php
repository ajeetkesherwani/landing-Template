<?php

namespace Modules\CRM\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;


use App\Services\ApiService;
use App\Helper\Helper;


class LeadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $parameters =array(
            "page" => '1',
            "perPage" => "2",
            "search" => $request->search,
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",
        );

        $apiurl = config('apipath.lead');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
        // dd( $responseData->data);
        return view('CRM::lead.index', collect($responseData->data));
      //  return view('CRM::lead.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
   
          $parameters =array(
                    "page" => '1',
                    "language" => "1",
                );

        $apiurl = config('apipath.lead-create');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
            //   dd( $responseData);

          return view('CRM::lead.create', collect($responseData->data));

       //   return view('CRM::lead.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


          $parameters =array(
              "source_id"=>$request->source_id,
              "contact_name"=>$request->contact_name,
              "contact_email"=>$request->contact_email,
              "phone"=>$request->phone,
              "industry_id"=>$request->industry_id,
              "company_name"=>$request->company,
              "website"=>$request->website,
              "street_address"=>$request->street_address,
              "city"=>$request->city,
              "state"=>$request->state,
              "zipcode"=>$request->zipcode,
              "countries_id"=>$request->countries_id,
               "social_link" =>$request->social_link,
               "social_type" =>$request->social_type,
               
                );

                $apiurl = config('apipath.lead-store');
                $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
            //   dd( $responseData);
            if ($responseData) {
                return redirect()->route('leads.index')->with('success',$responseData->message);
            } else {
                return redirect()->route('leads.index')->with('error',$responseData->message);
            }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($lead_id)
    {   
        // $lead          = Lead::find($lead_id);
        // $leadSource    = LeadSource::where('status',1)->get();
        // $industry      = Industry::where('status',1)->get();
        // $country       = MasCountry::where('status',1)->get();
        // $socialLink    = LeadSocialLink::where('lead_id',$lead->lead_id)->get();

        // return view('CRM::lead.edit',compact('lead','industry','leadSource','country','socialLink'));

           $parameters =array(
                    "lead_id" => $lead_id,
               
                    "language" => "1",
                );

                $apiurl = config('apipath.lead-edit');
                $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
            //   dd( $responseData);
            return view('CRM::lead.edit', collect($responseData->data));
              
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $lead_id)
    { 
        
        $parameters =array(
            "lead_id"=> $lead_id,
            "source_id"=>$request->source_id,
            "contact_name"=>$request->contact_name,
            "contact_email"=>$request->contact_email,
            "phone"=>$request->phone,
            "industry_id"=>$request->industry_id,
            "company_name"=>$request->company,
            "website"=>$request->website,
            "street_address"=>$request->street_address,
            "city"=>$request->city,
            "state"=>$request->state,
            "zipcode"=>$request->zipcode,
            "countries_id"=>$request->countries_id,
             "social_link" =>$request->social_link,
             "social_type" =>$request->social_type,
             
              );

              $apiurl = config('apipath.lead-update');
              $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
          //   dd( $responseData)
          if ($responseData) {
            return redirect()->route('leads.index')->with('success',$responseData->message);
        } else {
            return redirect()->route('leads.index')->with('error',$responseData->message);
        }
    
      
        
        }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $parameters =array(
                    "id" => $id,
               
                   
                );

                $apiurl = config('apipath.lead-destroy');
                $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
               dd( $responseData);



         return response()->json([$responseData->message]);



    }

    public function addmoredelete(Request $request)
    {
        $social_link_delete = LeadSocialLink::where('social_link_id',$request->social_link_id)->delete();
        return response()->json(['status'=>1, 'message'=>'Data deleted successfully']);
    }

    public function followStatus(Request $request)
    {
         $parameters =array(
                    "quoteId" => $request->lead_id,
               
                    "statusId" => $request->status,
                );

                $apiurl = config('apipath.lead-changeStatus');
                $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
                // dd( $responseData);

    
        return response()->json(['status' => 1, 'message' => $responseData->message]);
    }

    public function status_tab()
    {
        $parameters =array(
            "page" => '1',
            "language" => "1",
        );

        $apiurl = config('apipath.lead-status-tab');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
      //   dd( $responseData->data);
        return view('CRM::lead.index', collect($responseData->data));
      //  return view('CRM::lead.index');

    }
      


}
 