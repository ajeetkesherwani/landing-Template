<?php

namespace Modules\CRM\Http\Controllers;
use App\Http\Controllers\Controller;
use Modules\CRM\Models\Currencies;
use Illuminate\Http\Request;
use Modules\CRM\Models\Customer;
use Modules\CRM\Models\Quotation;
use Modules\CRM\Models\QuotationItem;
use App\Services\ApiService;
use App\Helper\Helper;
use Barryvdh\DomPDF\Facade\Pdf;

class QuotationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $parameters =array(
           
            "perPage" => "",
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",
        );

        //$apiurl = config('apipath.lead-quotation');
        $apiurl =  "https://e-nnovation.net/backend/public/api/crm_quotation";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
       //  dd( $responseData->data);
        return view('CRM::quotation.index', collect($responseData->data));

       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       
        $parameters =array(
           
            "perPage" => "",
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",
        );

        //$apiurl = config('apipath.lead-quotation');
        $apiurl =  "https://e-nnovation.net/backend/public/api/crm_quotation/create";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
      //  dd( $responseData->data);
        return view('CRM::quotation.create', collect($responseData->data));



       
    }








    public function SearchSuggestion(Request $request)
    {
       
        $parameters =array(
           
            "search" =>$request->search,
            "language" => "1",
        );

        //$apiurl = config('apipath.lead-quotation');
        $apiurl =  "https://e-nnovation.net/backend/public/api/crm_quotation/SearchSuggestion";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

      //  dd( $responseData->data);
      //  return response()->json([$responseData->data]);

        return response()->json([$responseData->data]);

       
    }


 



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function generateUniqueCode()
    {
        do {
            $code = random_int(100000, 999999);
        } while (quotation::where("quotation_no", "=", $code)->first());
  
        return $code;
        // return view('CRM::quotation.create',compact('code'));

    }
    public function store(Request $request)
    {
      
        // $quotation = new Quotation();
        // $quotation->customer_id = $request->customer_id;
        // $quotation->currency = $request->currencies_id;
        // $quotation->quotation_no = $this->generateUniqueCode();
        // $quotation->sub_total = $request->total;
        // $quotation->total_discount = $request->total_discount;
        // $quotation->shipping_cost = $request->shipping;     
        // $quotation->total_tax =$request->total; 
        // $quotation->status = 1;
        // $quotation->save();

        // $current_quotation_id = $quotation->quotation_id;
       
        // if(!empty($request->all())); 
        // {
        //     $item_name  = $request->item_name;
        //     $quantity  = $request->quantity;
        //     $unit_price = $request->unit_price;
        //     $discount   = $request->discount;
        //     $amount = $request->amount;

        //     foreach($item_name as $key => $value ){
        //         $data = QuotationItem::create([
        //             'item_name'  =>  $value,
        //             'quantity' => $quantity[$key],
        //             'unit_price' => $unit_price[$key],
        //             'discount' => $discount[$key],
        //             'item_cost' => $amount[$key],
        //             'quotation_id'   => $current_quotation_id,
        //         ]);
        //     }
        // }


        $parameters =array(
            "currency"=> $request->currency,
            "customer_id"=>$request->customer_id,
          //  "item_discount"=>$request->discount,
            "quote_discount"=>$request->total_discount,
            "total_item_cost"=>$request->sub_total,
            "shipping_cost"=>$request->shipping_cost,
            "discount"=>$request->discount,
            "final_cost"=>$request->final_cost,
            "note"=>$request->note,
            "payment_term"=>$request->payment_term,
            "item_name"=>$request->item_name,
            "quantity"=>$request->quantity,
           // "discount"=>$request->discount,
            "item_cost"=>$request->item_cost,
            "unit_price"=>$request->unit_price,


             
              );

              //$apiurl = config('apipath.lead-update');
              $apiurl =  "https://e-nnovation.net/backend/public/api/crm_quotation/store";
              $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

         //   dd( $responseData);
          if ($responseData) {
            return redirect()->route('quotation.index')->with('success',$responseData->message);
        } else {
            return redirect()->route('quotation.index')->with('error',$responseData->message);
        }
    


       // return redirect()->route('quotation.index')->with('success', 'Quotation Added successfully');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    
    { 
       
        $parameters =array(
           
            "quotation_id" => $id,
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",
        );

        //$apiurl = config('apipath.lead-quotation');
        $apiurl =  "https://e-nnovation.net/backend/public/api/crm_quotation/edit";
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
      //  dd( $responseData->data);
        return view('CRM::quotation.edit', collect($responseData->data));




    //     $customer_list = Customer::all();     
    //     $currencies_list= Currencies::all();
    //     $quotation = Quotation::find($id);
    //     $quotation_items = QuotationItem::where('quotation_id', $quotation->quotation_id)->get();

    // //    dd($quotation_items);
    //     return view('CRM::quotation.edit', );

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $parameters =array(
            "currency"=> $request->currency,
            "customer_id"=>$request->customer_id,
            "quotation_id"=>$id,
            "quote_discount"=>$request->total_discount,
            "total_item_cost"=>$request->sub_total,
            "shipping_cost"=>$request->shipping_cost,
            "discount"=>$request->discount,
            "final_cost"=>$request->final_cost,
            "note"=>$request->note,
            "payment_term"=>$request->payment_term,
            "item_name"=>$request->item_name,
            "quantity"=>$request->quantity,
           // "discount"=>$request->discount,
            "item_cost"=>$request->item_cost,
            "unit_price"=>$request->unit_price,


             
              );

              //$apiurl = config('apipath.lead-update');
              $apiurl =  "https://e-nnovation.net/backend/public/api/crm_quotation/update";
              $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

         //   dd( $responseData);
          if ($responseData) {
            return redirect()->route('quotation.index')->with('success',$responseData->message);
        } else {
            return redirect()->route('quotation.index')->with('error',$responseData->message);
        }
   

       
    }

     /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
         //    
    }
    public function DeleteQuotation(Request $request)
    {
        if (Quotation::where('quotation_id',$request->quotation_id)->exists()) {
        $quotation = Quotation::where('quotation_id',$request->quotation_id)->delete();
        $quotationitem = Quotationitem::where('quotation_id', $request->quotation_id)->delete(); 
            return response()->json(['quotation','quotationitem' => $quotation, $quotationitem, 'success' => 'Quotation Deleted Successfully']);
        }else{
            return response()->json(['success' => "Quotation can't beDeleted"]);
        }
    }


    
    public function details(Request $request , $id) 
    {

        $parameters =array(
        
            "quotation_id" => $id,

        );

        if ($id) {
            $apiurl = "https://e-nnovation.net/backend/public/api/crm_quotation/edit";

            $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
      //  dd($responseData);
            return view('CRM::quotation.view' , collect($responseData->data));
        }
    }


    public function quotationDetailspdf(Request $request ,$id){



       
        $parameters =array(
        
            "quotation_no" => $id,

        );

        if ($id) {
            $apiurl = "https://e-nnovation.net/backend/public/api/crm_quotation/quotationdetailspdf";
            
            $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
      
            $quotation = collect($responseData->data);
            $pdf = Pdf::loadView('CRM::quotation.quotation-details-pdf.pdf', compact('quotation') );

            $pdf->setOption(['dpi' => 150, 'defaultFont' => 'sans-serif']);
         
           
            return $pdf->stream();
        }
    }



    
}
