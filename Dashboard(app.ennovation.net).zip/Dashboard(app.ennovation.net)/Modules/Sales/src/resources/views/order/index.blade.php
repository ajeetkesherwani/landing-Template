<x-app-layout>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0 pb-0 fw-500">
            <li class="breadcrumb-item"><a href="#" class="text-dark tx-16">Dashboard</a></li>
        </ol>
    </nav>
    <div class="card">
        <div class="tab-content">
            <div class="card-header d-flex align-items-center justify-content-between py-2 px-3">
                <h5 class="tx-15 mb-0">{{ __('sales.order_list') }}</h5>

            </div>
            <div class="card-body">
                <div class="row align-item-center mb-3">
                    <div class="col-lg-2 col-md-3 col-4">
                        <select class="form-control form-select" aria-label="Default select example">
                            <option>10</option>
                        </select>
                    </div>
                    <div class="col-lg-6 col-md-3 col-8"><input type="text" id="Search"
                            class="form-control col-lg-4 fas fa-search" placeholder="Search..." aria-label="Search">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table border table_wrapper rounded">
                        <thead>
                            <tr>
                                <th class="border-bottom" style="min-width:70px;">{{ __('sales.sl_no') }}</th>
                                <th class="border-bottom" style="min-width: 150px;">{{ __('sales.date') }}</th>
                                <th class="border-bottom" style="min-width: 150px;">{{ __('sales.customer_name') }}</th>
                                <th class="border-bottom" style="min-width: 150px;">{{ __('sales.order_number') }}
                                </th>
                                <th class="border-bottom" style="min-width: 150px;">{{ __('sales.grand_total') }}</th>
                                <th class="border-bottom" style="min-width: 100px;">{{ __('sales.payment_status') }}

                                <th class="border-bottom" style="min-width: 100px;">{{ __('sales.order_status') }}
                                </th>
                                <th class="text-center border-bottom" style="min-width: 70px;">{{ __('sales.action') }}
                                </th>
                            </tr>
                        </thead>
                        <tbody id="Search_Tr">

                            <!-- Start -->
                            @if (!empty($order_list))
                                @foreach ($order_list as $key => $order)
                                    <tr>
                                        <td class="">{{ $key + 1 }}</td>
                                        @if (!empty($date_format))
                                            @foreach ($date_format as $date)
                                                <td class=""> {{ $date->date_example }} </td>
                                            @endforeach
                                        @endif
                                        <td class="">{{ $order->user->first_name }}{{ $order->user->last_name }}
                                        </td>
                                        <td class=""> {{ $order->order_number }}</td>
                                        <td class="">{{ $order->grand_total }}</td>

                                        <td class=""> </td>

                                        <td> </td>
                                        <td class="d-flex align-items-center gap-2 justify-content-center">
                                            <a href="{{ url('orders-details/' . $order->order_number) }}"
                                                value=""
                                                class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><i
                                                    data-feather="eye"></i></a>

                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--end row-->
    </div>
    <!--start delete modal-->
    <div class="modal fade effect-scale" id="delete_modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title">{{ __('crm.delete_quotation') }}</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="delete_department_id" name="input_field_id">
                    <p class="mg-b-0">{{ __('common.delete_confirmation') }}</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        {{ __('common.no') }}
                    </button>
                    <button type="button" class="btn btn-primary delete_btn">{{ __('common.yes') }}</button>
                </div>
            </div>
        </div>
    </div>


    @push('scripts')
        <!-- search ajax-->
        <script>
            $(document).ready(function() {
                $("#Search").on("keyup", function() {
                    var value = $(this).val().toLowerCase();
                    $("#Search_Tr tr").filter(function() {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
        </script>

        <!-- delete ajax start -->
        <script>
            $(document).ready(function() {
                $(document).on("click", "#delete_quotation", function() {
                    var quotation_id = $(this).val();
                    $('#delete_department_id').val(quotation_id);
                });
                $(document).on('click', '.delete_btn', function() {
                    var quotation_id = $('#delete_department_id').val();

                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "{{ url('quotation-delete') }}",
                        data: {
                            quotation_id: quotation_id
                        },
                        dataType: "json",
                        success: function(response) {
                            Toaster(response.success);
                            setTimeout(function() {
                                location.reload(true);
                            }, 300);
                        }
                    });
                });
            });
        </script>
        <!--end delete ajax-->

        <!--end status ajax-->
        <script type="text/javascript">
            // change status in ajax code start
            // $('.toggle_status').change(function(e) {
            //     e.preventDefault();
            //     // alert('hihyu');
            //     let status = $(this).prop('checked') === true ? 1 : 0;
            //     let staff_id = $(this).data('id');
            //     $.ajaxSetup({
            //         headers: {
            //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            //         }
            //     });
            //     $.ajax({
            //         type: "POST",
            //         dataType: "json",
            //         url: "{{ url('employee-status-change') }}",
            //         data: {
            //             'status': status,
            //             'staff_id': staff_id
            //         },
            //         success: function(data) {
            //             // location.reload();
            //             Toaster(' Employee Status Change Successfully');
            //         }
            //     });
            // });
            // chenge status in ajax code end  
        </script>
    @endpush
</x-app-layout>
