<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>

    <style>
        table,
        td {
            border: none;
        }
    </style>
</head>

<body>
    <div class="content content-fixed bd-b">
        <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
            <div class="d-sm-flex align-items-center justify-content-between">
                <div>
                    <h4 class="mg-b-5">Order Number #{{ $order['order_details']->order_number }}</h4>
                    <p class="mg-b-0 tx-color-03">13th January 2023</p>
                </div>

            </div>
        </div><!-- container -->
    </div>
    <div class="content tx-13">
        <div class="container pd-x-0 pd-lg-x-10 pd-xl-x-0">
            <div class="row">
                <div class="col-sm-4 col-6">
                    <label class="tx-sans tx-uppercase tx-10 tx-medium tx-spacing-1 tx-color-03">Billed To</label>
                    <h6 class="tx-15 mg-b-10">{{ $order['order_details']->user->first_name }}</h6>
                    <p class="mg-b-0">201 Something St., Something Town, YT 242, Country 6546</p>
                    <p class="mg-b-0">Tel No: {{ $order['order_details']->user->contact }}</p>
                    <p class="mg-b-0">Email: {{ $order['order_details']->user->email }}</p>
                </div><!-- col -->
                <div class="col-sm-4 tx-right d-md-inline">
                    <label class="tx-sans tx-uppercase tx-10 tx-medium tx-spacing-1 tx-color-03">Invoice Number</label>
                    <h1 class="tx-normal tx-color-04 mg-b-10 tx-spacing--2">#{{ $order['order_details']->order_number }}
                    </h1>
                </div><!-- col -->
            </div>
            <div class="row">
                <div class="col-sm-6 col-lg-8 mg-t-40 mg-sm-t-0 mg-md-t-40">
                    <label class="tx-sans tx-uppercase tx-10 tx-medium tx-spacing-1 tx-color-03">Billed From</label>
                    <h6 class="tx-15 mg-b-10">Juan Dela Cruz</h6>
                    <p class="mg-b-0">4033 Patterson Road, Staten Island, NY 10301</p>
                    <p class="mg-b-0">Tel No: 324 445-4544</p>
                    <p class="mg-b-0">Email: youremail@companyname.com</p>
                </div><!-- col -->
                <div class="col-sm-6 col-lg-4 mg-t-40">
                    <label class="tx-sans tx-uppercase tx-10 tx-medium tx-spacing-1 tx-color-03">Shipp To</label>
                    <ul class="list-unstyled lh-7">
                        <li class="d-flex justify-content-between">
                            <span>Invoice Number</span>
                            <span>DF032AZ00022</span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <span>Product ID</span>
                            <span>32334300</span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <span>Issue Date</span>
                            <span>January 20, 2019</span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <span>Due Date</span>
                            <span>April 21, 2019</span>
                        </li>
                    </ul>
                </div><!-- col -->
            </div><!-- row -->

            <div class="table-responsive mg-t-40">
                <table class="table table-invoice bd-b">
                    <thead>
                        <tr>
                            <th class="wd-20p">{{ __('sales.sl_no') }}</th>
                            <th class="wd-40p d-none d-sm-table-cell">{{ __('sales.item') }}</th>
                            <th class="tx-center">{{ __('sales.qty') }}</th>
                            <th class="tx-right">{{ __('sales.unit_price') }}</th>
                            <th class="tx-right">{{ __('sales.item_cost') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if (!empty($order['order_details']->item))
                            @foreach ($order['order_details']->item as $key => $item)
                                <tr>
                                    <td class="tx-nowrap">{{ $key + 1 }}</td>
                                    <td class="d-none d-sm-table-cell tx-color-03"> {{ $item->product_name }}</td>
                                    <td class="tx-center">{{ $item->qty }}</td>
                                    <td class="tx-right">${{ $item->unit_price }}</td>
                                    <td class="tx-right">${{ $item->total_price }}</td>
                                </tr>
                            @endforeach
                        @endif

                    </tbody>
                </table>
            </div>


        </div><!-- container -->
    </div>
</body>

</html>
