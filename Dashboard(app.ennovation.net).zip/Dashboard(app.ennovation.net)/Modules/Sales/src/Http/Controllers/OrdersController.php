<?php

namespace Modules\Sales\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Hash;
use Auth;
use App\Helper\Helper;
use Barryvdh\DomPDF\Facade\Pdf;

class OrdersController extends Controller
{
   

    public function index() 
    {
        $parameters =array(
        
            "page" => '1',
            "perPage" => "2",
            "search" => "",
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",

        );
    
        $apiurl = "https://e-nnovation.net/backend/public/api/orders";

        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
        
        // dd($responseData);
        
        return view('Sales::order.index', collect($responseData->data)  );

    }


     public function details(Request $request , $id) 
    {

        $parameters =array(
        
            "order_number" => $id,

        );

        if ($id) {
            $apiurl = "https://e-nnovation.net/backend/public/api/orders/detail";

            $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
        //dd($responseData);
            return view('Sales::order.view' , collect($responseData->data));
        }
    }

    public function orderDetailspdf(Request $request ,$id){
        $parameters =array(
        
            "order_number" => $id,

        );

        if ($id) {
            $apiurl = "https://e-nnovation.net/backend/public/api/orders/order-details-pdf";

            $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
        //dd($responseData);
            $order = collect($responseData->data);
            $pdf = Pdf::loadView('Sales::order.order-details-pdf.pdf', compact('order') );

            $pdf->setOption(['dpi' => 150, 'defaultFont' => 'sans-serif']);
            // $pdf->setMargins(0, 0, 0, 0);

            return $pdf->download();
        }
    }

}