<?php
use Illuminate\Support\Facades\Route;
use Modules\Sales\Http\Controllers\OrdersController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your aaplication. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


// Route::group(['middleware' => 'auth'], function () {
    // Route::get('category', [PcApiController::class, 'index'])->name('category');
    Route::resource('orders', OrdersController::class);

    Route::get('/orders-details/{id}' , [OrdersController::class , 'details']);

    Route::get('/orders-details-pdf/{id}' , [OrdersController::class , 'orderDetailspdf'])->name('download-pdf');
    
  