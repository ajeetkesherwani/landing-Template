<?php
namespace Modules\SEO\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use DB;
use App\Helper\Helper;

use App\Services\ApiService;

class SeoResultController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $parameters =array(
                
            "page" => '1',
            "perPage" => "2",
            "search" => "",
            "sortBy"=> "",
            "orderBY" => "", 
            "language" => "1", 
        );
    
        $apiurl = config('apipath.seo-monthlyResult');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
        
     //   dd( $responseData);
        return view('SEO::seo-monthly-result.index' ,collect($responseData->data));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $parameters = array(
            "website_id" => $request->website_id,
            "title_id" => $request->title_id,
            "month" => $request->month,
            "year" => $request->year,
            "result_value" => $request->result_value,
        );

        

        $apiurl = config('apipath.seo-monthlyResult-store');
      
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
      

        if ($responseData) {
            return response()->json(['success'=>$responseData->message]);
        } else {
            return response()->json(['error'=>$responseData->message]);
        }

    }



    public function getMonthlyResult(Request $request)
    {

        $parameters =array(
                
            "page" => '1',
            "perPage" => "2",
            "search" => "",
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",
            "website_id" => $request->website_id,
            "month" => $request->month,
            "year" => $request->year,
        );
    
        $apiurl = config('apipath.seo-monthlyResult-show');
                

        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        // dd($responseData);

        return response()->json(collect($responseData->data));
    }


    public function exportMonthlyResult(Request $request){

        //  dd($request->all());

        $parameters =array(
            "website" => $request->website_id,
            "month" => $request->month,
            "year"=>$request->year
        );

       


        $apiurl = config('apipath.seo-exportMonthlyResult');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters); 

         return response()->download($responseData->data);
      
    }

}