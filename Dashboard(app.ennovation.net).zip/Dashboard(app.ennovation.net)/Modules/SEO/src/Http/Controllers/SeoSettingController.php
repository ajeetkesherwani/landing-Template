<?php
namespace Modules\SEO\Http\Controllers;

use App\Helper\Helper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Cache;
use App\Services\ApiService;

class SeoSettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $parameters = array(
            "page" => '1',
            "perPage" => "2",
            "search" => "",
            "sortBy" => "",
            "orderBY" => "",
            "language" => "1",
            'api_token' => Cache::get('api_token'),
        );
        
       
        
        $apiurl = config('apipath.seo-setting');
        
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);


        return view('SEO::seo-settings.index', collect($responseData->data));

    }


    public function changeWebsiteStatus(Request $request)
    {

        $parameters = array(
            "id" => $request->website_id,
            "status" => $request->status,
        );

        $apiurl = config('apipath.seo-setting-website-changeStatus');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return response()->json(['status' => 1, 'success' => $responseData->message]);

    }

    public function create()
    {

        $parameters = array(
            "page" => '1',
            "orderBY" => "",
            "language" => "1",
        );

        $apiurl = config('apipath.seo-setting-website-create');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return view('SEO::seo-settings.seo-website.create', collect($responseData->data));

    }

    public function store(Request $request)
    {
        $parameters = array(
            "website_name" => $request->website_name,
            "website_url" => $request->website_url,
            "countries_id" => $request->countries_id,
            "subscription_id" => $request->subscription_id,
            "start_date" => $request->start_date,
            'api_token' => Cache::get('api_token'),
        );

         $apiurl = config('apipath.seo-setting-website-store');

        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

       

        if ($responseData) {
            return redirect()->route('seo.workReport' ,['tab=website'])->with('success', $responseData->message);
        } else {
            return redirect()->route('seo.workReport' ,['tab=website'])->with('error', $responseData->message);
        }
    }

    public function edit($id)
    {
        $parameters = array(
            "id" => $id,

        );
        $apiurl = "https://e-nnovation.net/backend/public/api/seoSetting/website_edit";

        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return view('SEO::seo-settings.seo-website.edit', collect($responseData->data));

    }

    public function update(Request $request, $id)
    {

        $parameters = array(
            "id" => $id,
            "website_name" => $request->website_name,
            "website_url" => $request->website_url,
            "countries_id" => $request->countries_id,
            "subscription_id" => $request->subscription_id,
            "start_date" => $request->start_date,
            "end_date" =>$request->end_date,
            'status' =>$request->status,
            'api_token' => Cache::get('api_token'),
        );

         $apiurl = config('apipath.seo-setting-website-update');

        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        if ($responseData) {
            return redirect()->route('seo.workReport' ,['tab=website'])->with('success', $responseData->message);
        } else {
            return redirect()->route('seo.workReport' ,['tab=website'])->with('error', $responseData->message);
        }
    }

    public function task_manage($id)
    {
        $parameters = array(
            "id" => $id,
        );

        $apiurl = config('apipath.seo-setting-manage-task-list');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return view('SEO::seo-settings.seo-website.managetask', collect($responseData->data));
    }

    public function task_manage_update(Request $request, $id)
    {

        if ($id) {
         
            $apiurl = config('apipath.seo-setting-manage-task-update');
            $responseData = Helper::ApiServiceResponse($apiurl, $request->all());

         
            return response()->json(['success' => $responseData->message]);
        } else {
            return response()->json(['error' => $responseData->message]);
        }
    }

    public function changeTaskManageStatus(Request $request)
    {
        $parameters = array(
            "id" => $request->id,
            "status" => $request->status,
        );
        
        

        $apiurl = config('apipath.seo-setting-manage-task-status');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return response()->json(['status' => 1, 'success' => $responseData->message]);

    }

    public function task_create()
    {

        $apiurl = config('apipath.seo-setting-task-create');
        $responseData = Helper::ApiServiceResponse($apiurl, []);
        
        return view('SEO::seo-settings.seo-task.create', collect($responseData->data));
    }

    public function task_store(Request $request)
    {
        $parameters = array(
            "seo_task_title" => $request->seo_task_title,
            "task_priority" => $request->task_priority,
            "task_frequency" => $request->task_frequency,
            "no_of_submission" => $request->no_of_submission,
            'api_token' => Cache::get('api_token'),
        );

        $apiurl = config('apipath.seo-setting-task-store');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        
        
        if ($responseData) {
            return redirect()->route('seo.workReport' , ["tab=task"])->with('success', $responseData->message);
        } else {
            return redirect()->route('seo.workReport', ["tab=task"])->with('error', $responseData->message);
        }

    }

    public function task_edit($id)
    {
        $parameters = array(
            "id" => $id,
        );

        $apiurl = config('apipath.seo-setting-task-edit');

        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);


        return view('SEO::seo-settings.seo-task.edit', collect($responseData->data));

    }

    public function task_update(Request $request, $id)
    {
        $parameters = array(
            "id" => $id,
            "seo_task_title" => $request->seo_task_title,
            "task_priority" => $request->task_priority,
            "task_frequency" => $request->task_frequency,
            "no_of_submission" => $request->no_of_submission,
            'status'=>$request->status,
            'api_token' => Cache::get('api_token'),
        );

        $apiurl = config('apipath.seo-setting-task-update');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        if ($responseData->status == true) {
           
            return redirect()->route('seo.workReport', ["tab=task"])->with('success', $responseData->message);
        } else {
            return redirect()->route('seo.workReport', ["tab=task"])->with('error', $responseData->message);
        }

    }

    public function task_destroy($id)
    {
        //  dd($id);
        $parameters = array(
            "id" => $id,

        );

        $apiurl = config('apipath.seo-setting-task-destroy');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return response()->json(['success' => $responseData->message]);

    }

    public function changeTaskStatus(Request $request)
    {
        $parameters = array(
            "id" => $request->task_id,
            "status" => $request->status,
        );

        $apiurl = config('apipath.seo-setting-task-changeStatus');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return response()->json(['status' => 1, 'success' => $responseData->message]);

    }

    public function result_create()
    {

        $parameters = array(
            "page" => '1',
            "orderBY" => "",
            "language" => "1",
        );

        $apiurl = config('apipath.seo-setting-result-create');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return response()->json(['seoresult' => collect($responseData->data)]);
    }

    public function result_store(Request $request)
    {
        $parameters = array(
            "title_name" => $request->title,
            "parent_id" => $request->parent_section_id,
            'api_token' => Cache::get('api_token'),
        );

        $apiurl = config('apipath.seo-setting-result-store');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
//    dd($responseData->message);

        if ($responseData->status == true) {
          return response()->json(['status' => 1, 'success' => $responseData->message]);
        } else {
            return response()->json(['status' => 0, 'error' => $responseData->message]);
          
        }

    }

    public function result_edit($id)
    {
        $parameters = array(
            "id" => $id,
        );

        $apiurl = config('apipath.seo-setting-result-edit');

        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return json_encode($responseData->data);
    }

    public function resultUpdate(Request $request)
    {

        $parameters = array(
            "id" => $request->id,
            "title_name" => $request->title,
            "parent_id" => $request->section_type,
            'status'=>$request->status,
            'api_token' => Cache::get('api_token'),
        );

        $apiurl = config('apipath.seo-setting-result-update');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

      //  dd( $responseData);

        if ($responseData->status == true) {
            return response()->json(['status' => 1, 'success' => $responseData->message]);
          
        } else {
            return response()->json(['status' => 0, 'error' => $responseData->message]);
           
        }

    }

    public function result_destroy($id)
    {
        $parameters = array(
            "id" => $id,

        );

        $apiurl = config('apipath.seo-setting-result-destroy');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return response()->json(['success' => $responseData->message]);



    }

    public function changeResultStatus(Request $request)
    {

        $parameters = array(
            "result_id" => $request->result_id,
            "status" => $request->status,
        );

        $apiurl = config('apipath.seo-setting-result-changeStatus');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return response()->json(['status' => 1, 'success' => $responseData->message]);

    }



    public function changeResultSortOrder(Request $request)
    {

        $parameters = array(
            "result_id" => $request->result_id,
            "sort_order" => $request->sort_order,
        );

       $apiurl = config('apipath.seo-setting-result-changeSortOrder');
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

        return response()->json(['status' => 1, 'success' => $responseData->message]);

    }



    

}