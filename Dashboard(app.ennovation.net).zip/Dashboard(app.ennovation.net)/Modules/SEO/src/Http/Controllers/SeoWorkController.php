<?php

namespace Modules\SEO\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Auth;
use Carbon\Carbon;

use Validator;
use App\Services\ApiService;
use App\Helper\Helper;
class SeoWorkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $parameters =array(
            
            "page" => '1',
            "perPage" => "2",
            "search" => "",
            "sortBy"=> "",
            "orderBY" => "",
            "language" => "1",
        );
    
        $apiurl = config('apipath.seo-dailyWork');
            
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
        // dd($responseData);
        return view('SEO::seo-daily-report.index',collect($responseData->data));
           
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if($id){

            $parameters =array(
                "id" => $id,
            );
        
            $apiurl = config('apipath.seo-dailyWork-edit');
                
            $responseData = Helper::ApiServiceResponse($apiurl, $parameters);

           // dd($responseData);
            
            return view('SEO::seo-daily-report.edit',collect($responseData->data));
           
        }else{
            return redirect()->route('daily-work')->with('error','Something Error!');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function work_report_update(Request $request, $id)
    {

        
        if($id){
            $apiurl = config('apipath.seo-dailyWork-update');
            
            $responseData = Helper::ApiServiceResponse($apiurl, $request->all());
            
            return response()->json(['success'=>$responseData->message]);
        } else{
            return response()->json(['error'=>$responseData->message]);
        }

      
        
    }
    public function dailyWorkStatus(Request $request)
    {
        
        $parameters =array(
                
            "website_id" =>$request->website_id,
            "status"=>$request->status,
           
        );
    
        $apiurl = config('apipath.seo-dailyWork-changeStatus');
            
        $responseData = Helper::ApiServiceResponse($apiurl, $parameters);
           
        return response()->json(['work_report' => collect($responseData->message)]);

    }

}
