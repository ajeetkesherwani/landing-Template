<?php

use Illuminate\Support\Facades\Route;

use Modules\SEO\Http\Controllers\SeoWorkController;

use Modules\SEO\Http\Controllers\SeoResultController;

use Modules\SEO\Http\Controllers\SeoSettingController;
use Modules\SEO\Http\Controllers\SeoReportController;
use Modules\SEO\Http\Controllers\SeoSubmissionController;



/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your aaplication. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/




// Route::get('/', function () {
//     return view('auth/login');
// });

// Route::get('/dashboard', function () {
//     return view('dashboard');
// })->middleware(['auth'])->name('dashboard');


// Route::group(['middleware' => 'auth'], function () {

Route::group(['as'=> 'seo.', 'prefix' => 'seo'], function(){
   
    Route::resource('daily-work', SeoWorkController::class);
    Route::post('work-report-update/{id}', [SeoWorkController::class, 'work_report_update'])->name('work-report-update');
    Route::post('daily-work-status', [SeoWorkController::class, 'dailyWorkStatus'])->name('dailyWorkStatus');
    

    
    
    Route::resource('work-report', SeoReportController::class);
    Route::get('import', [SeoReportController::class, 'importData'])->name('work-report.import');
    Route::post('export', [SeoReportController::class, 'exportData'])->name('work-report.export');
    Route::post('work-report-url', [SeoReportController::class, 'workReportUrl'])->name('work-report-url');
    Route::post('work-report/import', [SeoReportController::class, 'importStore'])->name('work-report.import.store');


 
     //Seo task
    Route::post('task/change-task-status', [SeoSettingController::class,'changeTaskStatus'])->name('changeTaskStatus');
    Route::post('task/{id}', [SeoSettingController::class, 'task_destroy'])->name('seo_task');
    Route::get('task-edit/{id}', [SeoSettingController::class,'task_edit'])->name('seo-task-edit');
    Route::post('task-update/{id}', [SeoSettingController::class,'task_update'])->name('seo-task-update');
    Route::get('task-create', [SeoSettingController::class,'task_create'])->name('seo-task-create');
    Route::post('task-store', [SeoSettingController::class,'task_store'])->name('seo-task-store');
   //end seo task

    //Seo result route
    Route::post('child-delete/{id}', [SeoSettingController::class, 'result_destroy'])->name('child-delete');
    Route::post('results-update', [SeoSettingController::class,'resultUpdate'])->name('seo-results-update');
    Route::post('results-store', [SeoSettingController::class,'result_store'])->name('seo-results-store');
    Route::get('results-edit/{id}', [SeoSettingController::class,'result_edit'])->name('seo-results-edit');
    Route::post('results-create', [SeoSettingController::class,'result_create'])->name('seo-results-create');
    Route::post('change-result-status', [SeoSettingController::class,'changeResultStatus'])->name('changeResultStatus');
    //end result


    //start website
    Route::get('/general-setting', [SeoSettingController::class, 'index'])->name('workReport');
    Route::resource('website', SeoSettingController::class);
    Route::post('website/change-website-status', [SeoSettingController::class,'changeWebsiteStatus'])->name('changeWebsiteStatus');
    Route::get('manage-task/{id}', [SeoSettingController::class,'task_manage'])->name('manage-task');
    Route::post('task_manage_update/{id}', [SeoSettingController::class, 'task_manage_update'])->name('task_manage_update');
    Route::post('manage-task/change-task-manage-status', [SeoSettingController::class,'changeTaskManageStatus'])->name('changeTaskManageStatus');
    //end website
 
    Route::resource('monthly-result', SeoResultController::class);
    Route::post('get-monthly-result', [SeoResultController::class, 'getMonthlyResult'])->name('get-monthly-result');
    Route::get('export-monthly-result', [SeoResultController::class, 'exportMonthlyResult'])->name('export-monthly-result');
    Route::post('store', [SeoResultController::class, 'store'])->name('save-website-update');
    Route::resource('submission-url', SeoSubmissionController::class);
    Route::post('getsubmissionurl',[SeoSubmissionController::class,'getsubmissionurl'])->name('get-subission-url');
    Route::post('submission-status',[SeoSubmissionController::class, 'ChangeSubmissionStatus'])->name('submission-status-chenge');

    Route::post('sort-order',[SeoSettingController::class, 'changeResultSortOrder'])->name('change_short_order');
    
// });
});