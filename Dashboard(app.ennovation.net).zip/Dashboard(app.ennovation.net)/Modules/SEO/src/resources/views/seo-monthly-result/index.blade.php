@php
    $indexurl = Request::segment(1);
    $role = App\Helper\Helper::role_slug();
    $userdata = Cache::get('userdata');
    
@endphp

<x-app-layout>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-transparent px-0">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Library</li>
        </ol>
    </nav>
    <div class="card seo_wrapper">
        <div class="tab-content">
            <form id="save-website-data" class="g-3 needs-validation" novalidate>
                <div class="card-header">
                    @if ($userdata->userType != 'subscriber')
                        <div class="col-lg-3 ">
                            <div class="d-flex align-items-center">
                                <label class="mb-0">{{ __('seo.website') }}</label>
                                <select class=" form-control mx-3" name="website_id" id="website_id" required>
                                    <option selected="" value="" disabled>{{ __('seo.select') }}</option>
                                    @foreach ($web_setting as $web)
                                        <option data-content="{{ ucfirst($web->website_name) }}"
                                            value="{{ $web->id }}">{{ ucfirst($web->website_name) }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    @else
                        <input type="hidden" name="website_id" id="website_id"
                            value="@if (!empty($web_setting_list->id)) {{ $web_setting_list->id }} @endif" />

                    @endif


                    <div class="col-lg-3">
                        <div class="d-flex align-items-center">
                            <label class="mb-0">{{ __('seo.month') }}</label>
                            <select class="form-select form-control mx-3" name="month" id="month" required>
                                <option selected="" value="" disabled>select</option>
                                <option @if ($month == '1') selected @endif value="1">
                                    {{ __('seo.january') }}</option>
                                <option @if ($month == '2') selected @endif value="2">
                                    {{ __('seo.february') }}</option>
                                <option @if ($month == '3') selected @endif value="3">
                                    {{ __('seo.march') }}</option>
                                <option @if ($month == '4') selected @endif value="4">
                                    {{ __('seo.april') }}</option>
                                <option @if ($month == '5') selected @endif value="5">
                                    {{ __('seo.may') }}</option>
                                <option @if ($month == '6') selected @endif value="6">
                                    {{ __('seo.june') }}</option>
                                <option @if ($month == '7') selected @endif value="7">
                                    {{ __('seo.july') }}</option>
                                <option @if ($month == '8') selected @endif value="8">
                                    {{ __('seo.august') }}</option>
                                <option @if ($month == '9') selected @endif value="9">
                                    {{ __('seo.september') }}</option>
                                <option @if ($month == '10') selected @endif value="10">
                                    {{ __('seo.october') }}</option>
                                <option @if ($month == '11') selected @endif value="11">
                                    {{ __('seo.november') }}</option>
                                <option @if ($month == '12') selected @endif value="12">
                                    {{ __('seo.december') }}</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="d-flex align-items-center">
                            <label class="mb-0">{{ __('seo.year') }}</label>
                            <select class="form-select form-control mx-3" name="year" id="year" required>
                                <option selected="" value="" disabled>{{ __('seo.select') }}</option>
                                @for ($i = 2021; $i <= $year; $i++)
                                    <option {{ $year == $i ? 'selected' : '' }}>{{ $i }}</option>
                                @endfor
                            </select>
                        </div>
                    </div>

                    <div class="col-lg-3 d-flex ">
                        <div class="align-items-center mr-2">
                            <input type="submit" id="get_details" class="btn btn-primary get_details"
                                value="Get Details">
                        </div>

                        <div class="align-items-center">
                            {{-- 
                            <form action="{{ route('seo.export-monthly-result') }}" method="POST">
                                @csrf

                                <input type="hidden" name="web_site" id="website_monthly"
                                    value="@if (!empty($web_setting_list->id)) {{ $web_setting_list->id }} @endif" />
                                <input type="hidden" name="monthly" id="monthly" />
                                <input type="hidden" name="yearly" id="yearly" /> --}}

                            <input type="submit" id="export_monthly" class="btn btn-primary"
                                value="{{ __('seo.export') }}">
                            {{-- </form> --}}

                        </div>

                    </div>

                </div>
                <div class="card-body">
                    <div class="table-responsive" id="table_bind">
                        <table class="table border table_wrapper">
                            <thead>
                                <tr>
                                    <th class="  border-bottom p-3 col-sm-4">{{ __('seo.title') }}</th>
                                    <th class=" text-centerborder-bottom p-3 col-sm-4">{{ __('seo.sub_title') }}</th>
                                    <th class=" text-centerborder-bottom p-3 col-sm-2">
                                        {{ __('seo.result') }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="3">
                                        <h5 class="text-center mb-0 py-1">{{ __('seo.record_not_found') }}</h4>
                                    </td>

                                </tr>
                            </tbody>
                        </table>

                    </div>
                    <div class="mt-2 text-center d-none" id="date-hide">
                        <input type="button" id="get_details" class="btn btn-primary website-form" value="Update">
                    </div>
                </div>

            </form>

          

        </div>
    </div>
    <!--end container-->

    @push('scripts')
        <script>
            $(document).ready(function() {
                $('.get_details').on('click', function(e) {
                    e.preventDefault();
                    var data = {
                        website_id: $("#website_id").val(),
                        month: $("#month").val(),
                        year: $("#year").val(),
                    };
                    if (data.website_id != null) {
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });
                        $.ajax({
                            type: "POST",
                            url: "{{ route('seo.get-monthly-result') }}",
                            data: data,
                            dataType: "json",
                            success: function(response) {
                                var html = `<div class="table-responsive">
                                    <table class="border table mb-0">
                                    <thead>
                                        <tr>
                                            <th class="  border-bottom p-3 col-sm-4">{{ __('seo.title') }}</th>
                                            <th class=" text-centerborder-bottom p-3 col-sm-4">{{ __('seo.sub_title') }}</th>
                                            <th class=" text-centerborder-bottom p-3 col-sm-2">{{ __('common.result') }}</th>
                                        </tr>
                                    </thead><tbody>`;
                                //if(response.seo_title.length >0){
                                $.each(response.seo_title, function(key, parentData) {
                                    console.log(parentData);
                                    html += `<tr>
                                            <td>${parentData.title_name}</td>
                                            <td></td>
                                            <td></td>
                                        </tr>`;
                                    if (parentData.child != '') {
                                        $.each(parentData.child, function(childKey, child) {
                                            if (parentData.id == child.parent_id) {

                                                var result_value = '';
                                                if (response.seo_result[child.id] !=
                                                    null)

                                                    var result_value = response
                                                        .seo_result[child.id];

                                                html += `<tr>
                                                        <td></td>
                                                        <td>${child.title_name} </td>
                                                        <td><input type="text" class="form-control height-35 f-14" name="result_value[]" value="${result_value}">
                                                        <input type="hidden" name="title_id[]" value="${child.id}">
                                                        </td>
                                                </tr>`;
                                            }

                                        });
                                    }
                                });
                                html += `</tbody>
                                </table>
                                </div>`;
                                $('#date-hide').removeClass("d-none");
                                $("#table_bind").html(html);
                                //}else{
                                //   html+=`<tr>
                        //          <td colspan="3">
                        //              <h5 class="text-center mb-0 py-1">{{ __('seo.record_not_found') }}</h4>
                        //          </td>
                        //    </tr>
                        //     </tbody>
                        //    </table>
                        //    </div>`;
                                //$('#date-hide').removeClass("d-none");
                                // $("#table_bind").html(html);
                                //}
                            }
                        });

                    } else {
                        toastr.error('Please Select Website');
                    }
                });
            });
        </script>

        <script>
            $('.website-form').on('click', function(e) {
                e.preventDefault();
                const url = "{{ route('seo.save-website-update') }}";
                $.ajax({
                    url: url,
                    container: '#save-website-data',
                    type: "POST",
                    data: $('#save-website-data').serialize(),
                    success: function(response) {
                        //Toaster(response.success);
                        if (response.success) {
                            Toaster(response.success);
                        } else {
                            Toaster(response.error);
                        }
                        location.reload();
                    }
                })
            });


            $("#export_monthly").click(function() {

            if (data.website_id != null) {

                $('#save-website-data').attr('action', '{{ route('seo.export-monthly-result') }}');

                $('#save-website-data').RemoveAttr('id', 'none');

                $('.needs-validation').RemoveAttr('class', 'none');

                var website = $("#website_id").val();
                var year = $("#year").val();
                var month = $("#month").val();


                $("#monthly").val(month);
                $("#yearly").val(year);
                $("#website_monthly").val(website);
             } else {
                        toastr.error('Please Select Website');
                    }

            });
        </script>
    @endpush
</x-app-layout>
