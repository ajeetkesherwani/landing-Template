<x-app-layout>
    <div class="card">
        <div class="tab-content">

            <div class="card-header">
                <div class="d-flex align-items-center justify-content-between ">
                    <h6 class="tx-15 mg-b-0">{{ __('seo.submission_list') }}</h6>
                    <a href="{{ route('seo.submission-url.create') }}"
                        class="btn btn-sm btn-bg d-flex align-items-center mg-r-5"><i data-feather="plus"></i><span
                            class="d-none d-sm-inline mg-l-5">{{ __('seo.add_submission') }}</span></a>
                </div>
            </div>

            <div class="card-body">
                <div class="form-row">
                    <div class="form-group col-md-2">
                        <div class="form-icon position-relative">
                            <select class="form-select form-control" name="website_name" id="website_name">
                                <option value="0">{{ __('seo.select_website') }}</option>
                                @foreach ($websitelist as $website => $websitename)
                                    <option value="{{ $websitename->id }}"
                                        {{ request()->website == $websitename->id ? 'selected' : '' }}>
                                        {{ ucfirst($websitename->website_name) }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group col-md-2">
                        <div class="form-icon position-relative">
                            <select class="form-select form-control" name="seolist" id="seolist">
                                <option value="0">{{ __('seo.select_task') }}</option>
                                @foreach ($seotasklist as $seotask)
                                    <option data-content="{{ ucfirst($seotask->seo_task_title) }}"
                                        value="{{ $seotask->id }}"
                                        {{ request()->task == $seotask->id ? 'selected' : '' }}>
                                        {{ ucfirst($seotask->seo_task_title) }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table border table_wrapper" id="seo_title">
                        <thead>
                            <tr>
                                <th class="">{{ __('seo.task_title') }}</th>

                                <th class="wd-20p">{{ __('seo.website_url') }}</th>
                                <th class=" wd-20p">{{ __('seo.username') }}</th>
                                <th class="">{{ __('seo.password') }}</th>
                                <th class="">{{ __('common.status') }}</th>
                                <th class="">{{ __('common.action') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td colspan="5">
                                    <h5 class="text-center mb-0 py-1">{{ __('seo.record_not_found') }}</h4>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!--start delete modal-->
    <div class="modal fade effect-scale" id="delete_modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title">{{ __('seo.delete_submission') }}</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="delete_department_id" name="input_field_id">
                    <p class="mg-b-0">{{ __('common.delete_confirmation') }}</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        {{ __('common.no') }}
                    </button>
                    <button type="button" class="btn btn-primary "
                        id="delete_submit_btn">{{ __('common.yes') }}</button>
                </div>
            </div>
        </div>
    </div>

    <!--End delete modal-->


    @push('scripts')
        <script type="text/javascript">
            //  website status ajax start
            $(document).on("change", ".toggle-class", function() {
                let status = $(this).prop('checked') === true ? 1 : 0;
                let id = $(this).data('id');
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "{{ route('seo.submission-status-chenge') }}",
                    data: {
                        'status': status,
                        'id': id
                    },
                    success: function(response) {
                        console.log(response);
                        Toaster(response.success);
                    }
                });
            });
        </script>


        <script>
            $(document).ready(function() {
                $(document).on("click", "#delete_btn", function() {
                    var submission_id = $(this).data('id');
                    $('#delete_department_id').val(submission_id);
                });
                $(document).on('click', '#delete_submit_btn', function() {
                    var submission_id = $('#delete_department_id').val();
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        type: "POST",
                        url: "{{ url('submission') }}/" + submission_id,
                        data: {
                            submission_id: submission_id,
                            _method: 'DELETE'
                        },
                        dataType: "json",
                        success: function(response) {
                            console.log(response);
                            Toaster(response);
                            $('#delete_modal').fadeOut(2000, function() {
                                location.reload(true);
                            });
                        }
                    });
                });
            });
        </script>
        <!--end delete ajax-->

        <script type="text/javascript">
            $(document).ready(function() {

                @php
                    if (request()->website) {
                        echo 'ajaxSubsmisstionData()';
                    }
                @endphp

                $('#website_name, #seolist').on('change', function() {
                    ajaxSubsmisstionData();
                });
            });

            function ajaxSubsmisstionData() {
                var website_id = $('#website_name').val();
                var seo_task_id = $('#seolist').val();
                $("#seo_title").html('');
                tableContent(website_id, seo_task_id);
            }

            function tableContent(website_id, seo_task_id) {
                const url = "{{ route('seo.get-subission-url') }}";
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: url,
                    type: "POST",
                    data: {
                        website_id: website_id,
                        seo_task_id: seo_task_id,
                    },
                    dataType: "json",
                    beforeSend: function() {
                        var html = `<div class="preloader-container d-flex justify-content-center align-items-center">
                                <div class="spinner-border" role="status" aria-hidden="true"></div>
                            </div>`;
                        $("#seo_title").append(html);
                    },
                    success: function(result) {
                        console.log(result);
                        var html = `<table id="example1" class="table border table_wrapper">
                                    <thead>
                                <th class="wd-20p">{{ __('seo.task_title') }}</th>
                                
                                <th class="wd-25p">{{ __('seo.website_url') }}</th>                                  
                                <th class=" wd-15p">{{ __('seo.username') }}</th>
                                <th class=" wd-15p">{{ __('seo.password') }}</th>
                                <th class=" wd-15p">{{ __('common.status') }}</th>
                                <th class="wd-10p" >{{ __('common.action') }}</th>
                                    <thead>`;

                        $.each(result.seotasklist, function(key, value) {
                            if (value.id == seo_task_id || seo_task_id == '0') {
                                html += `<tr>
                                        <td>${value.seo_task_title}</td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>`;
                                $.each(result.seosubmissionwebsites, function(seosubmissionlist,
                                    seosubmission) {
                                    if (value.id == seosubmission.seo_task_id) {
                                        var id = [seosubmission.id];
                                        //, seosubmission.website_id, seosubmission.seo_task_id
                                        var editUrl = 'submission/' + id + '/edit';
                                        var deleteUrl = seosubmission.id;
                                        html += `<tr>
                                                <td><input type="hidden" value="${seosubmission.website_id}">
                                                <input type="hidden" value="${seosubmission.seo_task_id}"></td>
                                                <td class="text-break">${seosubmission.website_url}</td>
                                                <td>${seosubmission.username}</td>
                                                <td>${seosubmission.password}</td>
                                                <td>
                                                    <div class="custom-control custom-switch">
                                                        <input data-id="${seosubmission.id}"
                                                        class="custom-control-input toggle-class" id="customSwitch${ seosubmission.id}" type="checkbox"
                                                        ${ seosubmission.status == 1 ? 'checked' : '' }>
                                                        <label class="custom-control-label" for="customSwitch${ seosubmission.id}"></label>
                                                    </div>
                                                </td>
                                                <td class="d-flex align-items-center">
                                                    <a href="${editUrl}" class="btn btn-sm btn-white d-flex align-items-center mg-r-5"><svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg><span class="d-sm-inline mg-l-5"></span></a>

                                                    <a href="#delete_modal" id="delete_btn" data-id="${ deleteUrl}" value="" data-toggle="modal" class="btn btn-sm btn-white d-flex align-items-center"><svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="css-i6dzq1"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg><span class="d-none d-sm-inline mg-l-5"></span></a>
                                                </td>
                                            </tr>`;
                                    }
                                });
                            }

                        });
                        html += `</table>
                        `;
                        $("#seo_title").html(html);
                    }
                });
            }
        </script>
    @endpush
</x-app-layout>
