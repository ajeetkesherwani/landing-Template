<x-app-layout>
    <div class="contact-content">
        <div class="layout-specing">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-transparent px-0">
                    <li class="breadcrumb-item"><a href="{{ route('seo.work-report.index') }}">Work Report</a></li>
                </ol>
            </nav>
            <form action="{{ route('seo.work-report.import.store') }}" id="import-work-report-data-form"
                enctype="multipart/form-data" method="POST" class="needs-validation" novalidate>
                @csrf
                <div class="card contact-content-body">

                    <div class="card-header bg-transparent">
                        <div class="d-flex align-items-center justify-content-between ">
                            <h6 class="tx-15 mg-b-0">{{ __('seo.import_work_report') }} </h6>
                        </div>
                    </div>

                    <div class="card-body">
                        <div data-label="Example" class="df-example demo-forms">
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label class="form-label">{{ __('seo.website_name') }} <span
                                            class="text-danger">*</span></label>
                                    <div class="form-icon position-relative">
                                        <select
                                            class=" form-control @error('website_id') is-invalid @enderror selectsearch"
                                            name="website_id" id="website_id" aria-label="Default select example"
                                            required>
                                            <option selected disabled value="">{{ __('common.select_website') }}
                                            </option>
                                            @foreach ($website_list as $website)
                                                <option value="{{ $website->id }}">{{ $website->website_name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <div class="invalid-feedback">
                                            <p>Please select website</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">{{ __('seo.seo_task') }} <span
                                            class="text-danger">*</span></label>
                                    <div class="form-icon position-relative">
                                        <select
                                            class="form-control @error('seo_task_id') is-invalid @enderror selectsearch"
                                            name="seo_task_id" id="seo_task_id" aria-label="Default select example"
                                            required>
                                            <option selected disabled value="">Select Task</option>
                                            @foreach ($seo_task_list as $seo_list)
                                                <option value="{{ $seo_list->id }}">{{ $seo_list->seo_task_title }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <div class="invalid-feedback">
                                            <p>Please select task</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label
                                        class="form-label">{{ __('seo.upload_file') }}({{ __('seo.field_type') }})</label>
                                    <input type="file" name="import_file"
                                        data-allowed-file-extensions="xls xlsx csv txt" id="work_report_import"
                                        class="form-control ps-5 dropify">
                                </div>
                            </div>
                        </div>
                        <!--end row-->
                    </div>


                </div>
                <div class="mt-3">
                    <div class="col-sm-12 p-0">
                        <input type="submit" id="import-work-report-form" name="send" class="btn btn-primary"
                            value="{{ __('seo.upload') }}">
                        <a href="{{ route('seo.work-report.index') }}"
                            class="btn btn-light mx-1">{{ __('common.cancel') }} </a>
                    </div>
                    <!--end col-->
                </div>
            </form>
        </div>
    </div>


    @push('scripts')
        <script>
            $('.selectsearch').select2({
                searchInputPlaceholder: 'Search options'
            });
        </script>
    @endpush

</x-app-layout>
