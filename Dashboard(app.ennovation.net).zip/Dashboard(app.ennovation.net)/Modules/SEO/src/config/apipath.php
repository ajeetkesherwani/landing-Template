<?php
return [
    'seo-setting' => 'https://e-nnovation.net/backend/public/api/seoSetting',

    //website api
    'seo-setting-website-create' => 'https://e-nnovation.net/backend/public/api/seoSetting/website_create',
    'seo-setting-website-store' => 'https://e-nnovation.net/backend/public/api/seoSetting/website_store',
    'seo-setting-website-edit' => 'https://e-nnovation.net/backend/public/api/seoSetting/website_edit',
    'seo-setting-website-update' => 'https://e-nnovation.net/backend/public/api/seoSetting/website_update',
    'seo-setting-website-destroy' => 'https://e-nnovation.net/backend/public/api/seoSetting/website_destroy',
    'seo-setting-website-changeStatus' => 'https://e-nnovation.net/backend/public/api/seoSetting/changeWebsiteStatus',
    'seo-setting-manage-task-list' => 'https://e-nnovation.net/backend/public/api/seoSetting/task_manage',
    'seo-setting-manage-task-update' => 'https://e-nnovation.net/backend/public/api/seoSetting/manage_task_update',
    'seo-setting-manage-task-status' => 'https://e-nnovation.net/backend/public/api/seoSetting/changeTaskManageStatus',
     //end website api

     //task setting api
     'seo-setting-task-create' => 'https://e-nnovation.net/backend/public/api/seoSetting/seo_task_create',
     'seo-setting-task-store' => 'https://e-nnovation.net/backend/public/api/seoSetting/seo_task_store',
     'seo-setting-task-edit' => 'https://e-nnovation.net/backend/public/api/seoSetting/seo_task_edit',
     'seo-setting-task-update' => 'https://e-nnovation.net/backend/public/api/seoSetting/seo_task_update',
     'seo-setting-task-destroy' => 'https://e-nnovation.net/backend/public/api/seoSetting/seo_task_destroy',
     'seo-setting-task-changeStatus' => 'https://e-nnovation.net/backend/public/api/seoSetting/changeTaskStatus',
    //end task setting api

    //result title api
    'seo-setting-result-create' => 'https://e-nnovation.net/backend/public/api/seoSetting/seo_result_create',
    'seo-setting-result-store' => 'https://e-nnovation.net/backend/public/api/seoSetting/seo_result_store',
    'seo-setting-result-edit' => 'https://e-nnovation.net/backend/public/api/seoSetting/seo_result_edit',
    'seo-setting-result-update' => 'https://e-nnovation.net/backend/public/api/seoSetting/seo_result_update',
    'seo-setting-result-destroy' => 'https://e-nnovation.net/backend/public/api/seoSetting/seo_result_destroy',
    'seo-setting-result-changeStatus' => 'https://e-nnovation.net/backend/public/api/seoSetting/changeResultStatus',
    'seo-setting-result-changeSortOrder' => 'https://e-nnovation.net/backend/public/api/seoSetting/result_sortOrder',
    //end result title api
    
    //seo submission api
    'seo-submission' => 'https://e-nnovation.net/backend/public/api/seoSubmission',
    'seo-submission-create' => 'https://e-nnovation.net/backend/public/api/seoSubmission/create',
    'seo-submission-store' => 'https://e-nnovation.net/backend/public/api/seoSubmission/store',
    'seo-submission-update' => 'https://e-nnovation.net/backend/public/api/seoSubmission/update',
    'seo-submission-edit' => 'https://e-nnovation.net/backend/public/api/seoSubmission/edit',
    'seo-submission-destroy' => 'https://e-nnovation.net/backend/public/api/seoSubmission/destroy',
    'seo-submission-changeStatus' => 'https://e-nnovation.net/backend/public/api/seoSubmission/    ChangeSubmissionStatus
    ',
    'seo-submission-url' => 'https://e-nnovation.net/backend/public/api/seoSubmission/      getSubmissionUrl

    ',
    //end 

     //seo daily work api
     'seo-dailyWork' =>'https://e-nnovation.net/backend/public/api/seoDailyWork',
     'seo-dailyWork-update' =>'https://e-nnovation.net/backend/public/api/seoDailyWork/work_report_update',
     'seo-dailyWork-edit' =>'https://e-nnovation.net/backend/public/api/seoDailyWork/edit',
     'seo-dailyWork-changeStatus' =>'https://e-nnovation.net/backend/public/api/seoDailyWork/dailyWorkStatus',
    
    //workReport api
    'seo-workReport' => 'https://e-nnovation.net/backend/public/api/seoWorkReport',
    'seo-workReportUrl' => 'https://e-nnovation.net/backend/public/api/seoWorkReport/work_report',
     'seo-workReport-import-add' => 'https://e-nnovation.net/backend/public/api/seoWorkReport/importAdd',
     'seo-workReport-import-store' => 'https://e-nnovation.net/backend/public/api/seoWorkReport/importStore',

     'seo-workReport-export' => 'https://e-nnovation.net/backend/public/api/seoWorkReport/exportData',


    //monthly result api
    'seo-monthlyResult' =>'https://e-nnovation.net/backend/public/api/seoMonthlyResult',
    'seo-monthlyResult-show' =>'https://e-nnovation.net/backend/public/api/seoMonthlyResult/getMonthlyResult',
    'seo-monthlyResult-store' => 'https://e-nnovation.net/backend/public/api/seoMonthlyResult/store',

    'seo-exportMonthlyResult' => 'https://e-nnovation.net/backend/public/api/seoMonthlyResult/export-monthly-result',
];