<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="{{ asset('lib/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('lib/feather-icons/feather.min.js') }}"></script>
<script src="{{ asset('lib/perfect-scrollbar/perfect-scrollbar.min.js') }}"></script>
 <script src="{{ asset('lib/parsleyjs/parsley.min.js')}}"></script>
{{-- <script src="{{ asset('lib/jquery.flot/jquery.flot.js') }}"></script>
<script src="{{ asset('lib/jquery.flot/jquery.flot.stack.js') }}"></script>
<script src="{{ asset('lib/jquery.flot/jquery.flot.resize.js') }}"></script>
<script src="{{ asset('lib/chart.js/Chart.bundle.min.js') }}"></script>
<script src="{{ asset('lib/jqvmap/jquery.vmap.min.js') }}"></script>
<script src="{{ asset('lib/jqvmap/maps/jquery.vmap.usa.js') }}"></script> --}}

<script src="{{ asset('asset/js/dashforge.js') }}"></script>
<script src="{{ asset('asset/js/dashforge.aside.js') }}"></script>
<script src="{{ asset('asset/js/dashforge.sampledata.js') }}"></script>

<script src="{{ asset('asset/js/datepicker/tpicker.js') }}"></script>

{{-- <!-- append theme customizer -->
<script src="{{ asset('lib/js-cookie/js.cookie.js') }}"></script>
<script src="{{ asset('asset/js/dashforge.settings.js') }}"></script> --}}

<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>


{{-- Toaster CDN --}}

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"
    integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

{{-- toaster massage validation  --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"
    integrity="sha512-rstIgDs0xPgmG6RX1Aba4KV5cWJbAMcvRCVmglpam9SoHZiUCyQVDdH2LPlxoHtrv17XWblE/V/PP+Tr04hbtA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
{{-- toaster massage closed --}}

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


<script>
    function Toaster(message) {
        Command: toastr["success"](message)
        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": true,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "preventDuplicates": false,
            "hideDuration": "1000",
            "timeOut": "1000",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }
    }

    //success massage strip disable
    $(function() {
        $(".alert").delay(3000).fadeOut("slow");
    });
</script>
{{-- @push('scripts') --}}
<script>
    $(document).ready(function() {
        toastr.options.timeOut = 3000;
        @if (Session::has('success'))
            toastr.success('{{ Session::get('success') }}');
        @endif
    });
</script>
<script>
    // @if ($errors->any())
    //     @foreach ($errors->all() as $error)
    //         toastr.error("{{ $error }}");
    //     @endforeach
    // @endif
</script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.js"></script>
{{-- <script>
    $(document).ready(function() {
        $('.dataTableShow').DataTable();
    });
</script> --}}
<!--data table end-->

{{-- @endpush --}}
