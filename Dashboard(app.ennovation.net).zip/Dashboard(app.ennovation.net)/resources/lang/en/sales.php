<?php
return [
    "sl_no" => "Sl No",
    "date" => "Date" ,
    "customer_name" => "Customer Name",
    "order_number" => "Order Number",
    "grand_total" => "GRAND_TOTAL",
    "payment_status" => "Payment Status",
    "order_status" => "Order Status",
    "action" =>"Action",
    "order_list" => "Order List",
    "add_orders" => "Add Orders",
    "order_status" => "Order Status",
    "item" => "Item",
    "qty" => "Qty",
    "unit_price" => "Unit Price",
    "item_cost" => "Item Caust",
];


?>