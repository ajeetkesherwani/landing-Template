<?php
return [
    'dashboard' => 'Tableau de bord',
    'welcome' => 'Bienvenue à nouveau, Cristina !';
];